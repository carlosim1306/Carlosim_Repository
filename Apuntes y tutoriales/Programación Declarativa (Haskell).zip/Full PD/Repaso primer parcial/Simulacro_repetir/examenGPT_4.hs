-- -----------------------------------------------------------------------------
-- Programación Declarativa 2024/25
-- Grado de Ingeniería Informática - Tecnologías Informáticas
-- Parcial 1 (grupo 1)                                   25 de Octubre de 2024
-- -----------------------------------------------------------------------------
-- Apellidos:
-- Nombre:
-- UVUS:
-- Laboratorio/Puesto:
-- -----------------------------------------------------------------------------

import Test.QuickCheck
import Data.Char
import Data.List

-- -----------------------------------------------------------------------------
-- Ejercicio 1 (2.5 puntos)
-- Definir el operador infijo (|+|) tal que reciba dos listas xs e ys, y devuelva 
-- el resultado de concatenarlas, pero quitando el primer y último elemento de xs 
-- y el primer y último elemento de ys. Debe tener la misma precedencia que el 
-- operador (++), el cual se puede usar para la solución de este ejercicio. Por ejemplo:
-- > [] |+| [3,4]
-- []
-- > [1] |+| []
-- []
-- > [2,3,4] |+| [5,6,7,3] |+| [8,9]
-- [6]
-- > [1,2,3] |+| [4,5,6] ++ [7,8]
-- [2,5,7,8]
-- -----------------------------------------------------------------------------
(|+|) :: [a] -> [a] -> [a]
(|+|) xs ys
            | length xs <= 2 && length ys <= 2 = []
            | length xs <= 2 && length ys >= 2 = take (length ys -2) (drop 1 ys)
            | length xs >= 2 && length ys <= 2 = take (length xs -2) (drop 1 xs)
            | otherwise = take (length xs -2) (drop 1 xs) ++ take (length ys -2) (drop 1 ys)

infixl 9 |+|
-- -----------------------------------------------------------------------------
-- Ejercicio 2.1 (1.5 puntos) Define la función (productoDeProductosR xss) tal que reciba
-- una lista de listas de números, y calcule el producto de los productos de las 
-- sublistas. No se calculará el producto para sublistas vacías, aunque sí contará
-- para el producto total; es decir, el producto de las sublistas vacías es 1.
-- Define la función empleando solo RECURSIÓN para xss. Por ejemplo,
--  > productoDeProductosR [[2,4]]
--  8
--  > productoDeProductosR [[2,4],[]]
--  8
--  > productoDeProductosR [[2,4],[2,3],[3,4,5,6]]
--  17280
-- -----------------------------------------------------------------------------

productoDeProductosR :: (Num a, Eq a) => [[a]] -> a
productoDeProductosR [] = 1
productoDeProductosR (x:xs)
                        | x == [] =  productoDeProductosR xs
                        | otherwise = product x * productoDeProductosR xs

-- -----------------------------------------------------------------------------
-- Ejercicio 2.2 (1.5 puntos) Define la función (productoDeProductosO xss) como la anterior,
-- pero usando ORDEN SUPERIOR para recorrer los elementos de xss. Por ejemplo,
--  > productoDeProductosO [[2,4]]
--  8
--  > productoDeProductosO [[2,4],[]]
--  8
--  > productoDeProductosO [[2,4],[2,3],[3,4,5,6]]
--  8640
-- -----------------------------------------------------------------------------

productoDeProductosO :: (Num a, Eq a) => [[a]] -> a
productoDeProductosO xs = product (map (\x -> product x) xs)

-- -----------------------------------------------------------------------------
-- Ejercicio 2.3 (1 punto) Comprueba con quickCheck que para cualquier lista de
-- listas no vacía y que no incluya ninguna sublista vacía, si el producto de productos
-- es igual al producto de concatenación de sus listas. Si hay un contraejemplo, 
-- copia y pégalo como un comentario.
-- -----------------------------------------------------------------------------

prop_productoDeProductos [] = True
prop_productoDeProductos xs
                            | or [ x == [] | x <- xs] = True
                            | otherwise = (productoDeProductosO xs) == (product (concat xs))

{- La comprobación es:
-}

-- -----------------------------------------------------------------------------
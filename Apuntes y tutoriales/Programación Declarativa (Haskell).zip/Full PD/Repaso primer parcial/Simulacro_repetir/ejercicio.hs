import Data.Char
import Data.Array
import Data.List 
import Test.QuickCheck
import Control.Exception (catch, SomeException)

{-
Dada una lista devuelve una lista de tuplas donde el primer elemento sea el número y la proporción

funcion [1,1,2,6,5,2,1,5,7,9] -> [(1,0.3),(2,0.2),(5,0.2),(6,0.1),(7,0.1),(9,0.1)] , sino ordenado por la frecuencia relativa
-}

funcion :: Eq a => [a] -> [(a, Float)]
funcion xs = sortBy (\(x,y) (x1,y1) -> compare y1 y) (map (\x -> (x,(frecuenciaAbsoluta xs x)/(tamaño xs))) (nub xs))
    where tamaño x = fromIntegral (length x) :: Float

frecuenciaAbsoluta :: (Num a1, Eq a2) => [a2] -> a2 -> a1
frecuenciaAbsoluta xs n = sum[1 | x <- xs, x == n]

groupR :: Eq a => [a] -> [[a]]
groupR [] = []
groupR xo@(x:xs)
            | elem x xs = [[ y | y <- xo , x == y ]] ++ groupR [y | y <- xo , x /= y ]
            | otherwise = [x] : groupR xs

funcionLC :: Eq a => [a] -> [(a, Float)]
funcionLC xs = sortBy (\(x,y) (x1,y1) -> compare y1 y) [(x,(frecuenciaAbsoluta xs x)/(tamaño xs))| x <- (nub xs)]
    where tamaño x = fromIntegral (length x) :: Float

funcionR :: Eq a => [a] -> [(a, Float)]
funcionR xs = map (\(x,y) -> (x,y/tamaño xs)) (funcionAux xs)
        where tamaño x = fromIntegral (length x) :: Float

funcionAux :: (Eq a, Num b) => [a] -> [(a, b)]
funcionAux [] = []
funcionAux xo@(x:xs)
                | elem x xs = (x,frecuenciaAbsoluta xo x) : funcionAux [y | y <- xo , x /= y ]
                | otherwise = (x,1) : funcionAux xs

funcionPL xs = sortBy (\(x,y) (x1,y1) -> compare y1 y) (nub (foldl f [] xs))
    where f rec x
                | elem x xs = (x,(frecuenciaAbsoluta xs x)/tamaño xs) : rec
                | otherwise = (x,1) : rec
                where tamaño x = fromIntegral (length x) :: Float
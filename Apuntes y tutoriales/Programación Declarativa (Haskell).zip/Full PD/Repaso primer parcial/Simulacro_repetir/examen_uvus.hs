import Data.Char
import Data.Array
import Data.List
import Test.QuickCheck
import Control.Exception (catch, SomeException)


-- -----------------------------------------------------------------------------
-- Programación Declarativa 2024/25
-- Grado de Ingeniería Informática - Tecnologías Informáticas y
-- Doble Grado en Matemáticas e Ingenigería Informática
-- 1º Parcial (Simulacro)                                  21 de Octubre de 2024
-- -----------------------------------------------------------------------------
-- Apellidos:
-- Nombre:
-- UVUS:
-- Laboratorio/Puesto:
--
-- NO OLVIDES RELLENAR CON TUS DATOS LA CABECERA ANTERIOR
-- 
-- -----------------------------------------------------------------------------
-- INSTRUCCIONES PARA LA ENTREGA
-- 1. CAMBIA EL NOMBRE de este archivo por:       <uvus>.hs
--    donde "<uvus>" es tu UVUS. 
-- 2. COMENTA LAS LÍNEAS CON ERRORES hasta que se pueda cargar el fichero:
--    sin problemas. AQUELLOS ARCHIVOS DE CÓDIGO QUE NO CARGUEN POR ERRORES
--    DE CÓDIGO NO SE CORREGIRÁN.
-- 3. RELLENA los datos de la cabecera incluido el laboratorio y puesto.
-- 4. COMPRIME ESTE archivo en un único fichero llamado EXACTAMENTE:
--      ENTREGA-<uvus>.tar.gz      (o bien)       ENTREGA-<uvus>.tar.xz
--    donde "<uvus>" es tu UVUS. No te olvides del guión después de
--    ENTREGA, y NO lo comprimas en un fichero .zip.
-- 4. REINICIA el equipo. En el menú de selección del sistema (con fondo
--    blanco), HAZ CLICK SOBRE "Enviar examen" al lado de sistema Ubuntu.
-- 5. Pregunta al profesor si ha llegado tu correo correctamente, si es
--    así, ya puedes dejar tu puesto APAGANDO EL EQUIPO (si lo consieras
--    oportuno, vuelve al escritorio y borra el examen del equipo).
-- ----------------------------------------------------------------------
-- ORIENTACIONES
-- · Escribe la solución de cada ejercicio en el hueco reservado para
--   ello. NO ESCRIBAS FUERA DE DICHO HUECO. NO MODIFIQUES NADA DE LOS 
--   ENUNCIADOS.
-- · Se valorará el uso correcto de tipados para cada función definida.
-- · Puedes añadir tantas funciones auxiliares como necesites (incluyendo su 
--   signatura adecuadamente).
-- · Puedes usar otros módulos de Haskell que estén ya importados.
-- -----------------------------------------------------------------------------

-- primosEquidistantes (!!?!!) = let (??!!??) ((??):((???):(?!?)))=((???)-(??)==(!!?!!))????(([((??),(???))]++(??!!??) ([(???)]++(?!?)))!!!!((??!!??) ([(???)]++(?!?)))) in (??!!??) primos;(!!??) _ (??) [] = (??); (!!??) (!!!) (?!?) ((??):(???)) = (!!!) (??) ((!!??) (!!!) (?!?) (???));(!?!?) = (ord 'A')-(((ord 'a')-(ord 'A'))*2+1);(!!!!) (??) (!!) = ((??), (!!)); (????) True ((??), (!!)) = (??); (????) False ((??), (!!)) = (!!);(!?!??) _ [] = [];(!?!??) 0 (??) = [];(!?!??) (!!) ((??):(???)) = (??):((!?!??) ((!!)-1) (???));(!?!?!) _ [] = [];(!?!?!) 0 (??) = (??);(!?!?!) (!!) (_:(???)) = ((!?!?!) ((!!)-1) (???));consecutivos (??) (!!) = (!!??) (??!!??) [] [(!?!?)..length (!!) - (??)] where (??!!??) (===) (=-=)=((??)>(!?!?))????(([(((!?!??) (??)).((!?!?!) (===))) (!!)] ++ (=-=))!!!!(=-=));

-- ---------------------------------------------------------------------
-- Ejercicio 1 (1.5 puntos)
-- ---------------------------------------------------------------------
-- Implementa una función para extraer de una secuencia de elementos 
-- aquellos grupos de n elementos que son pares.
--
-- > paresConsecutivos 1 [1,2,2,3,2,1,1,1,4]
-- [[2],[2],[2],[4]]
-- > paresConsecutivos 2 [1,2,2,3,2,1,1,1,4]
-- [[2,2]]
-- > paresConsecutivos 3 [1,2,2,3,2,1,1,1,4]
-- []
-- > paresConsecutivos 0 [1,2,2,3,2,1,1,1,4]
-- []
-- > paresConsecutivos 3 []
-- []
--
-- Implementa la función por 
-- a) (0.5 puntos) recursión,
-- b) (0.5 puntos) recursión con acumulador,
-- c) (0.5 punto) listas por compresión,--
-- ---------------------------------------------------------------------

-- Función utilizando recursión
paresConsecutivosR:: Int -> [Int] -> [[Int]]
paresConsecutivosR 0 xs = []
paresConsecutivosR _ [] = []
paresConsecutivosR n xo@(x:xs)
                                | length xo < n = []
                                | odd x = paresConsecutivosR n (dropWhile (odd) xs)
                                | and [ even x | x <- (take n xo)] = take n xo : paresConsecutivosR n (drop n xo)
                                | otherwise =  paresConsecutivosR n xs

-- Función utilizando recursión con acumulador
paresConsecutivosRA :: Int -> [Int] -> [[Int]]
paresConsecutivosRA n xs = auxParesConsecutivosRA n xs []

auxParesConsecutivosRA :: Int -> [Int] -> [[Int]] -> [[Int]]
auxParesConsecutivosRA 0 xs ac = ac
auxParesConsecutivosRA _ [] ac = ac
auxParesConsecutivosRA n xo@(x:xs) ac
                                | length xo < n = ac
                                | odd x = auxParesConsecutivosRA n (dropWhile (odd) xs) ac
                                | and [ even x | x <- (take n xo)] = auxParesConsecutivosRA n (drop n xo) (take n xo:ac)
                                | otherwise =  auxParesConsecutivosRA n xs  ac

-- Función utilizando listas por comprensión
paresConsecutivosLC :: Int -> [Int] -> [[Int]]
paresConsecutivosLC n xs = [ take n (drop x xs) | x <- [0..(length xs-n)], and[ even x | x <- (take n (drop x xs) )]]

-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 2 (0.5 puntos)
-- ---------------------------------------------------------------------
-- Implementa la propiedad para la función `paresConsecutivos` que has 
-- definido anteriormente. Utiliza el framework de pruebas 
-- QuickCheck para verificar la propiedad.
--
-- Propiedad a verificar: Todos los elementos en los grupos 
-- devueltos por paresConsecutivos deben ser números pares.
--
-- ---------------------------------------------------------------------

-- Propiedad: Pares confirmados
prop_pares_confirmados:: Int -> [Int] -> Bool
prop_pares_confirmados n xs = and [even x | x <- concat (paresConsecutivosLC n xs)]

-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 3 (1.0 puntos)
-- ---------------------------------------------------------------------
-- Define el operador binario (~~) que elimina del inicio de la secuencia
-- xs la secuencia ys, si ys es la cabeza de xs. Establecer al operador 
-- precedencia por la derecha y prioridad superior a la concatenación de 
-- listas.
--
-- > [1,2,3,4,5] ~~ [1,2] ++ [3,4,5]
-- [3,4,5,3,4,5]
-- > [1,2,3,4,5] ~~ [2,3] ++ [4,5]
-- [1,2,3,4,5,4,5]
-- > [1,2,3,4,5] ~~ [1,2,3]
-- [4,5]
-- > [1,2,3,4,5] ~~ []
-- [1,2,3,4,5]
--
-- ---------------------------------------------------------------------

(~~):: (Eq a) => [a] -> [a] -> [a]
(~~) xs [] = xs
(~~) [] _ = []
(~~) xo@(x:xs) (y:ys)
                    | x /= y = xo
                    | otherwise = (~~) xs ys

infixr 9 ~~
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 4 (1.5 puntos)
-- ---------------------------------------------------------------------
-- Implementa una función para extraer la subsecuencia más larga de 
-- una secuencia de elementos que cumpla una determinada propiedad.
--
-- > subsecuenciaLarga ((>10).sum) [1,2,3,4,5,6]
-- [1,2,3,4,5]
--
-- > subsecuenciaLarga ((==12).product) [1,2,2,3,2,1,1,1,4]
-- [2,3,2,1,1,1]
--
-- Notas:
--   - La propiedad debe ser cumplida por la subsecuencia completa.
--   - Si no hay subsecuencias que cumplan la propiedad, devuelve una 
--     lista vacía.
-- ---------------------------------------------------------------------

subsecuenciaLarga:: ([Int] -> Bool) -> [Int] -> [Int]
subsecuenciaLarga p xs = head [ x | x <- (subsecuencias p xs) , length x == (subsecuenciaMasLarga p xs)]

subsecuenciaMasLarga:: ([Int] -> Bool) -> [Int] -> Int
subsecuenciaMasLarga p xs = maximum [length x | x <- (subsecuencias p xs)]

subsecuencias:: ([Int] -> Bool) -> [Int] -> [[Int]]
subsecuencias p xs = [ take y (drop x xs) | x <- [0..(length xs -1)], y <-[0..(length xs -1)], p (take y (drop x xs))]
    

-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 5 (1 punto)
-- ---------------------------------------------------------------------
-- Definir la función primosConDiferenciaPrimo tal que devuelve la 
-- lista infinita de pares de primos consecutivos
-- cuya diferencia también es un número primo o uno. Por ejemplo,
--
--    take 4 primosConDiferenciaPrimo  ==  [(2,3),(3,5),(5,7),(11,13)]
--

-- ---------------------------------------------------------------------

primosConDiferenciaPrimo:: [(Int,Int)]
primosConDiferenciaPrimo = [(a,b) | (a,b) <- zip primos (tail primos), esPrimo (abs (a-b)) || (abs (a-b)) == 1]

primos::[Int]
primos = [x | x <- [1..] , esPrimo x ]

esPrimo:: Int -> Bool
esPrimo n = length (divisores n) == 2

divisores:: Int -> [Int]
divisores n = [x | x <- [1..n], mod n x == 0]

-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 5.2 (1.5 puntos) 
-- ---------------------------------------------------------------------
-- Si pensamos en los pares de primos del apartado anterior como puntos 
-- en el plano, podemos definir una distancia entre ellos. Sea la 
-- distancia Taxi d((a,b),(c,d)) = |c-a| + |d-b|.
-- ¿Cuál es la menor pareja de pares de primos a distancia 4 que estén a una
-- distancia Taxi mayor o igual que 1000? 
-- 
-- Dar la solución y el código usado para llegar hasta la misma.
--
-- Puede usar la función 'primosEquidistantes' dada.
--
-- > take 3 (primosEquidistantes 4)
-- [(7,11),(13,17),(19,23)]
--
-- ---------------------------------------------------------------------

distanciaTaxi :: (Int,Int) -> (Int,Int) -> Int
distanciaTaxi (a,b) (c,d) = abs(c-a) + abs(d-b)

primosEquidistantes:: Int -> [(Int,Int)]
primosEquidistantes n = [(a,b) | (a,b) <- zip primos (tail primos), abs(a-b) == n]

parDistanciaTaxi:: ((Int,Int),(Int,Int))
parDistanciaTaxi = head [(x,y)  | (x,y) <- zip (primosEquidistantes 4) (tail (primosEquidistantes 4)), distanciaTaxi x y >= 1000]
-- ---------------------------------------------------------------------



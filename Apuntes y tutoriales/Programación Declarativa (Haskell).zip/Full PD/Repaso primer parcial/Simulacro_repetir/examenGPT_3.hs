-- -----------------------------------------------------------------------------
-- Programación Declarativa 2024/25
-- Grado de Ingeniería Informática - Tecnologías Informáticas
-- Parcial 1 (grupo 1)                                   25 de Octubre de 2024
-- -----------------------------------------------------------------------------
-- Apellidos:
-- Nombre:
-- UVUS:
-- Laboratorio/Puesto:
-- -----------------------------------------------------------------------------

import Test.QuickCheck
import Data.Char
import Data.List

-- -----------------------------------------------------------------------------
-- Ejercicio 1 (2 puntos)
-- Definir el operador infijo (//) tal que reciba dos listas xs e ys, y devuelva 
-- el resultado de concatenarlas, pero quitando el primer elemento de xs y el 
-- último de ys. Debe tener la misma precedencia que el operador (++), el cual
-- se puede usar para la solución de este ejercicio. Por ejemplo:
-- > [] // [3,4]
-- []
-- > [1] // []
-- []
-- > [2,3] // [4,3,5] // [6,7]
-- [4,3,6]
-- > [1,2] // [3,4] ++ [5,6]
-- [2,3,5,6]
-- -----------------------------------------------------------------------------

(//) :: Eq a => [a] -> [a] -> [a]
(//) [x] [] = []
(//) [] [y] = []
(//) xs [] = tail xs
(//) [] ys = take (length ys-1) ys
(//) xs ys = tail xs ++ take (length ys-1) ys

infixl //
-- -----------------------------------------------------------------------------
-- Ejercicio 2.1 (1 punto) Define la función (sumaDeSumasR xss) tal que reciba
-- una lista de listas de números, y calcule la suma de las sumas de las 
-- sublistas. No se calculará la suma para sublistas vacías, aunque sí contará
-- para la suma total; es decir, la suma de las sublistas vacías es 0.
-- Define la función empleando solo RECURSIÓN para xss. Por ejemplo,
--  > sumaDeSumasR [[2,4]]
--  6
--  > sumaDeSumasR [[2,4],[]]
--  6
--  > sumaDeSumasR [[2,4],[2,3],[3,4,5,6]]
--  29
-- -----------------------------------------------------------------------------

sumaDeSumasR :: (Num a, Eq a) => [[a]] -> a
sumaDeSumasR [] = 0
sumaDeSumasR [x] = sum x
sumaDeSumasR (x:xs)
                    | x == [] = 0 + sumaDeSumasR xs
                    | otherwise = (sum x) + sumaDeSumasR xs

-- -----------------------------------------------------------------------------
-- Ejercicio 2.2 (1 punto) Define la función (sumaDeSumasO xss) como la anterior,
-- pero usando ORDEN SUPERIOR para recorrer los elementos de xss. Por ejemplo,
--  > sumaDeSumasO [[2,4]]
--  6
--  > sumaDeSumasO [[2,4],[]]
--  6
--  > sumaDeSumasO [[2,4],[2,3],[3,4,5,6]]
--  29
-- -----------------------------------------------------------------------------

sumaDeSumasO :: (Num a, Foldable t) => [t a] -> a
sumaDeSumasO xs = sum(map (\x -> sum x) xs)

-- -----------------------------------------------------------------------------
-- Ejercicio 2.3 (1 punto) Comprueba con quickCheck que para cualquier lista de
-- listas no vacía y que no incluya ninguna sublista vacía, si la suma de sumas
-- es igual a la suma de concatenación de sus listas. Si hay un contraejemplo, 
-- copia y pégalo como un comentario.
-- -----------------------------------------------------------------------------

prop_sumaDeSumas :: (Eq a, Num a) => [[a]] -> Bool
prop_sumaDeSumas [] = True
prop_sumaDeSumas xs
                    | or [x == [] | x <- xs] = True
                    | otherwise = sumaDeSumasR xs == sum(concat xs)

{- La comprobación es:
-}

-- -----------------------------------------------------------------------------


-- -----------------------------------------------------------------------------
-- Ejercicio 3 (2,5 puntos). El horario de clase se puede representar como una
-- lista de tuplas donde:
--   * la primera componente es el día de la semana, 
--   * la segunda componente una lista de pares, donde:
--      - la primera componente es un entero que representa la hora
--      - la segunda componente es una lista con nombres abreviados de 
--        asignaturas (es posible que se nos pise el horario, por eso pueden 
--        haber varias asignaturas a la misma hora).

horario :: [([Char], [(Int, [[Char]])])]
horario =  [ ("Lun",[(8,[]),(9,[]),(10,[]),(11,[]),(12,[]),(13,["FP"]),(14,["FP"])]),
             ("Mar",[(8,[]),(9,["ML"]),(10,["ML"]),(11,["BD"]),(12,["BD"]),(13,["FP"]),(14,["FP"])]),
             ("Mie",[(8,[]),(9,[]),(10,[]),(11,["SO"]),(12,["SO"]),(13,["PL"]),(14,["PL"])]),
             ("Jue",[(8,[]),(9,[]),(10,[]),(11,[]),(12,[]),(13,["ML"]),(14,["ML"])]),
             ("Vie",[(8,[]),(9,["BD","SO"]),(10,["BD","SO"]),(11,["BD","SO"]),(12,["BD","SO"]),(13,["PL"]),(14,["PL"])])]

-- Define la función (horarioAsignatura hss a), tal que reciba un horario hss
-- como el anterior y el nombre abreviado de una asignatura , y devuelva el
-- el horario de clases de dicha asignatura con el siguiente formato: una lista
-- de ternas donde la primera componente es el día, y la segunda y tercera
-- componente son la hora de inicio y hora de fin (en rangos de una hora).
-- Por ejemplo,
--  > horarioAsignatura horario "ML"
--  [("Mar",9,10),("Jue",13,14)]
--  > horarioAsignatura horario "PL"
--  [("Mie",13,14),("Vie",13,14)]
--  > horarioAsignatura horario "SO"
--  [("Mie",11,12),("Vie",9,12)]
-- -----------------------------------------------------------------------------

horarioAsignatura hss asignatura = map (\(x,y) -> (x, head y, last y)) 
 (filter (\(x,y) -> y /= [])[(dia,horasDia hss asignatura dia) | dia <- dias])
    where dias = ["Lun", "Mar","Mie","Jue","Vie"]

horasDia hss asignatura dia = [y | (x,y) <- auxHorarioAsignatura hss asignatura, x == dia]

auxHorarioAsignatura hss asignatura = [(dia,hora) |
 (dia,horasAsig) <- hss, (hora,asignaturas) <- horasAsig, elem asignatura asignaturas]

-- -----------------------------------------------------------------------------


-- -----------------------------------------------------------------------------
-- Ejercicio 4 (2,5 puntos) El siguiente problema está basado en el 425
-- del proyecto Euler. Dos números positivos A y B se dice que están
-- conectados (denotado por "A ↔ B"), si se cumple una de las siguientes
-- condiciones:
--   1) A y B tienen la misma cantidad de dígitos y difieren en exactamente
--      un dígito. Por ejemplo, 123 ↔ 173
--   2) Al añadir un dígito a la izquierda de A (o B) conseguimos B (o A).
--      Por ejemplo, 23 ↔ 223 y 123 ↔ 23
-- Diremos que dos primos q y p están relacionados si existe una cadena 
-- de primos conectados entre ambos y están comprendidos entre q y p. Por
-- ejemplo, si q=2 y p=127, entonces 2 ↔ 3 ↔ 13 ↔ 113 ↔ 103 ↔ 107 ↔ 127.
-- Define el predicado (cadenaPrimosConectados xs) tal que indique si la
-- lista xs es una cadena correcta de primos conectados. Por ejemplo,
--   > cadenaPrimosConectados [2,3,13,113,103,107,127]
--   True
--   > cadenaPrimosConectados [2,3,13,22,1,127]
--   False
--   > cadenaPrimosConectados [2,3,13,113,183,107,127]
--   False
-- -----------------------------------------------------------------------------

cadenaPrimosConectados :: Integral t => [t] -> Bool
cadenaPrimosConectados xs = and [ primera_propiedad x y || segunda_propiedad x y | (x,y) <- zip xs (tail xs)]

primera_propiedad :: Integral t => t -> t -> Bool
primera_propiedad a b = difierenEn a b == 1 && numDigitos a == numDigitos b 

difierenEn :: (Integral a1, Num a2) => a1 -> a1 -> a2
difierenEn 0 0 = 0
difierenEn 0 b = 1 + difierenEn 0 (div b 10)
difierenEn a 0 = 1 + difierenEn (div a 10) 0 
difierenEn a b
                | mod a 10 == mod b 10 = difierenEn (div a 10) (div b 10)
                | otherwise = 1 + difierenEn (div a 10) (div b 10)

numDigitos :: (Integral t, Num p) => t -> p
numDigitos 0 = 0
numDigitos n = 1 + numDigitos (div n 10)

segunda_propiedad a b
                        | a > b = or [ a == b + 10^ (numDigitos a) | x <- [1..9]]
                        | otherwise = or [ b == a + 10^ (numDigitos a) | x <- [1..9]]
-- -----------------------------------------------------------------------------

import Data.Char
import Data.Array
import Data.List
import Test.QuickCheck
import Control.Exception (catch, SomeException)

-- -----------------------------------------------------------------------------
-- Programación Declarativa 2024/25
-- Grado de Ingeniería Informática - Tecnologías Informáticas y
-- Doble Grado en Matemáticas e Ingeniería Informática
-- 1º Parcial (Simulacro)                                  25 de Octubre de 2024
-- -----------------------------------------------------------------------------
-- Apellidos:
-- Nombre:
-- UVUS:
-- Laboratorio/Puesto:
--
-- NO OLVIDES RELLENAR CON TUS DATOS LA CABECERA ANTERIOR
-- 
-- -----------------------------------------------------------------------------
-- INSTRUCCIONES PARA LA ENTREGA
-- 1. CAMBIA EL NOMBRE de este archivo por:       <uvus>.hs
--    donde "<uvus>" es tu UVUS. 
-- 2. COMENTA LAS LÍNEAS CON ERRORES hasta que se pueda cargar el fichero:
--    sin problemas. AQUELLOS ARCHIVOS DE CÓDIGO QUE NO CARGUEN POR ERRORES
--    DE CÓDIGO NO SE CORREGIRÁN.
-- 3. RELLENA los datos de la cabecera incluido el laboratorio y puesto.
-- 4. COMPRIME ESTE archivo en un único fichero llamado EXACTAMENTE:
--      ENTREGA-<uvus>.tar.gz      (o bien)       ENTREGA-<uvus>.tar.xz
--    donde "<uvus>" es tu UVUS. No te olvides del guión después de
--    ENTREGA, y NO lo comprimas en un fichero .zip.
-- 4. REINICIA el equipo. En el menú de selección del sistema (con fondo
--    blanco), HAZ CLICK SOBRE "Enviar examen" al lado de sistema Ubuntu.
-- 5. Pregunta al profesor si ha llegado tu correo correctamente, si es
--    así, ya puedes dejar tu puesto APAGANDO EL EQUIPO (si lo consideras
--    oportuno, vuelve al escritorio y borra el examen del equipo).
-- ----------------------------------------------------------------------
-- ORIENTACIONES
-- · Escribe la solución de cada ejercicio en el hueco reservado para
--   ello. NO ESCRIBAS FUERA DE DICHO HUECO. NO MODIFIQUES NADA DE LOS 
--   ENUNCIADOS.
-- · Se valorará el uso correcto de tipados para cada función definida.
-- · Puedes añadir tantas funciones auxiliares como necesites (incluyendo su 
--   signatura adecuadamente).
-- · Puedes usar otros módulos de Haskell que estén ya importados.
-- -----------------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 1 (1.5 puntos)
-- ---------------------------------------------------------------------
-- Implementa una función que devuelva los elementos únicos de una lista.
--
-- > elementosUnicos [1,2,2,3,4,4,5]
-- [1,2,3,4,5]
-- > elementosUnicos "abracadabra"
-- "abrcd"
--
-- Implementa la función por 
-- a) (0.5 puntos) recursión,
-- b) (0.5 puntos) recursión con acumulador,
-- c) (0.5 puntos) listas por compresión.
-- ---------------------------------------------------------------------
elementosUnicosR :: Eq a => [a] -> [a]
elementosUnicosR [] = []
elementosUnicosR (x:xs)
                        | elem x xs == False = x : elementosUnicosR xs
                        | otherwise = elementosUnicosR xs

elementosUnicosRA :: Eq a => [a] -> [a]
elementosUnicosRA xs = auxElementosUnicosRA xs []

auxElementosUnicosRA :: Eq a => [a] -> [a] -> [a]
auxElementosUnicosRA [] ac = ac
auxElementosUnicosRA (x:xs) ac
                                | elem x xs == False = auxElementosUnicosRA xs (ac ++ [x])
                                | otherwise = auxElementosUnicosRA xs ac

elementosUnicosLC :: Eq a => [a] -> [a]
elementosUnicosLC xs = [x | (x,y)<- zip xs [1..length xs] , elem x (drop y xs) == False]

elementosUnicosFL :: Eq a => [a] -> [a]
elementosUnicosFL xs = foldl f [] (zip xs [1..length xs])
    where f rec (x,y)
                | elem x (drop y xs) == False = rec ++ [x]
                | otherwise = rec

elementosUnicosFR :: Eq a => [a] -> [a]
elementosUnicosFR xs = foldr f [] (zip xs [1..length xs])
    where f (x,y) ac
                    | elem x (drop y xs) == False =  x : ac
                    | otherwise = ac
-- ---------------------------------------------------------------------
-- Ejercicio 2 (0.5 puntos)
-- ---------------------------------------------------------------------
-- Implementa la propiedad para la función `elementosUnicos` que has 
-- definido anteriormente. Utiliza el framework de pruebas 
-- QuickCheck para verificar la propiedad.
--
-- Propiedad a verificar: Todos los elementos en la lista devuelta por 
-- `elementosUnicos` deben aparecer solo una vez.
--
-- ---------------------------------------------------------------------

prop_elementosUnicos :: [Int]-> Bool
prop_elementosUnicos [] = True
prop_elementosUnicos [x] = True
prop_elementosUnicos xs = and [ elem x (drop y (elementosUnicosLC xs)) == False 
 | (x,y) <- zip (elementosUnicosLC xs) [1..length xs-1]]

-- ---------------------------------------------------------------------
-- Ejercicio 3 (1.0 puntos)
-- ---------------------------------------------------------------------
-- Define el operador binario (~~) que concatena dos listas y elimina 
-- los elementos duplicados.
--
-- > [1,2,3] ~~ [3,4,5]
-- [1,2,3,4,5]
-- > "hello" ~~ "world"
-- "helowrd"
--
-- ---------------------------------------------------------------------

(~~) :: Eq a => [a] -> [a] -> [a]
(~~) xs ys = nub (xs ++ ys)

-- ---------------------------------------------------------------------
-- Ejercicio 4 (1.5 puntos)
-- ---------------------------------------------------------------------
-- Implementa una función que devuelva la subsecuencia más larga de 
-- una secuencia de elementos que sea palíndroma.
--
-- > subsecuenciaPalindroma "babad"
-- "bab"
-- > subsecuenciaPalindroma "cbbd"
-- "bb"
--
-- Notas:
--   - La subsecuencia debe ser continua.
--   - Si hay varias subsecuencias de la misma longitud, devuelve cualquiera.
-- ---------------------------------------------------------------------

subsecuenciaPalindroma :: Eq a => [a] -> [a]
subsecuenciaPalindroma xs = fst (head (sortBy (\(_,y) (_,y1) -> compare y1 y) [(x,length x)| x <- (subsecuencias xs) , esPalindromo x]))

esPalindromo :: Eq a => [a] -> Bool
esPalindromo xs = xs == reverse xs

subsecuencias :: [a] -> [[a]]
subsecuencias xs = [ take y (drop x xs) | x <- [0..length xs -1], y <- reverse [0..length xs -1]]


-- ---------------------------------------------------------------------
-- Ejercicio 5 (1 punto)
-- ---------------------------------------------------------------------
-- Definir la función primosGemelos tal que devuelve la lista infinita 
-- de pares de primos consecutivos cuya diferencia es exactamente 2. 
-- Por ejemplo,
--
--    take 4 primosGemelos  ==  [(3,5),(5,7),(11,13),(17,19)]
--

-- ---------------------------------------------------------------------

primosGemelos :: [(Integer, Integer)]
primosGemelos = [(x,y) | (x,y) <- zip primos (tail primos), abs(x-y) == 2]

primos :: [Integer]
primos = [ x | x <- [1..], esPrimo x]

esPrimo :: Integral a => a -> Bool
esPrimo n = length (divisores n) == 2

divisores :: Integral a => a -> [a]
divisores n = [ x | x <- [1..n] , mod n x == 0]

-- ---------------------------------------------------------------------
-- Ejercicio 5.2 (1.5 puntos) 
-- ---------------------------------------------------------------------
-- Si pensamos en los pares de primos del apartado anterior como puntos 
-- en el plano, podemos definir una distancia entre ellos. Sea la 
-- distancia Euclidiana d((a,b),(c,d)) = sqrt((c-a)^2 + (d-b)^2).
-- ¿Cuál es la menor pareja de pares de primos gemelos cuya distancia 
-- Euclidiana sea mayor o igual que 1000? 
-- 
-- Dar la solución y el código usado para llegar hasta la misma.
--
-- > take 3 (primosGemelos)
-- [(3,5),(5,7),(11,13)]
--
-- ---------------------------------------------------------------------

distanciaEuclidiana :: (Integral a) => (a, a) -> (a, a) -> a
distanciaEuclidiana (a,b) (c,d) = floor (raizCuadradaEntera((c-a)^2 + (d-b)^2))
    where raizCuadradaEntera x = sqrt (fromIntegral x :: Float)
parPrimosDistanciaEuclidiana :: Integer -> ((Integer, Integer), (Integer, Integer))
parPrimosDistanciaEuclidiana n = head[(x,y) | (x,y) <- zip primosGemelos (tail primosGemelos), distanciaEuclidiana x y >= n]
-- ---------------------------------------------------------------------

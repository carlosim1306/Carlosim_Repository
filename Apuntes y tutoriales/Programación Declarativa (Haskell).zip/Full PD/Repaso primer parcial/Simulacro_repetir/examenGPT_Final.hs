import Data.Char
import Data.Array
import Data.List
import Test.QuickCheck
import Control.Exception (catch, SomeException)

-- -----------------------------------------------------------------------------
-- Programación Declarativa 2024/25
-- Grado de Ingeniería Informática - Tecnologías Informáticas y
-- Doble Grado en Matemáticas e Ingeniería Informática
-- 1º Parcial (Simulacro)                                  25 de Octubre de 2024
-- -----------------------------------------------------------------------------
-- Apellidos:
-- Nombre:
-- UVUS:
-- Laboratorio/Puesto:
--
-- NO OLVIDES RELLENAR CON TUS DATOS LA CABECERA ANTERIOR
-- 
-- -----------------------------------------------------------------------------
-- INSTRUCCIONES PARA LA ENTREGA
-- 1. CAMBIA EL NOMBRE de este archivo por:       <uvus>.hs
--    donde "<uvus>" es tu UVUS. 
-- 2. COMENTA LAS LÍNEAS CON ERRORES hasta que se pueda cargar el fichero:
--    sin problemas. AQUELLOS ARCHIVOS DE CÓDIGO QUE NO CARGUEN POR ERRORES
--    DE CÓDIGO NO SE CORREGIRÁN.
-- 3. RELLENA los datos de la cabecera incluido el laboratorio y puesto.
-- 4. COMPRIME ESTE archivo en un único fichero llamado EXACTAMENTE:
--      ENTREGA-<uvus>.tar.gz      (o bien)       ENTREGA-<uvus>.tar.xz
--    donde "<uvus>" es tu UVUS. No te olvides del guión después de
--    ENTREGA, y NO lo comprimas en un fichero .zip.
-- 4. REINICIA el equipo. En el menú de selección del sistema (con fondo
--    blanco), HAZ CLICK SOBRE "Enviar examen" al lado de sistema Ubuntu.
-- 5. Pregunta al profesor si ha llegado tu correo correctamente, si es
--    así, ya puedes dejar tu puesto APAGANDO EL EQUIPO (si lo consideras
--    oportuno, vuelve al escritorio y borra el examen del equipo).
-- ----------------------------------------------------------------------
-- ORIENTACIONES
-- · Escribe la solución de cada ejercicio en el hueco reservado para
--   ello. NO ESCRIBAS FUERA DE DICHO HUECO. NO MODIFIQUES NADA DE LOS 
--   ENUNCIADOS.
-- · Se valorará el uso correcto de tipados para cada función definida.
-- · Puedes añadir tantas funciones auxiliares como necesites (incluyendo su 
--   signatura adecuadamente).
-- · Puedes usar otros módulos de Haskell que estén ya importados.
-- -----------------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 1 (2 puntos)
-- ---------------------------------------------------------------------
-- Define una función que reciba una lista de listas de números y devuelva 
-- una lista con las sumas de cada sublista, pero excluyendo los números 
-- negativos. Implementa la función usando recursión.
--
-- > sumaPositivos [[1,2,-3],[4,-5,6],[-7,8,9]]
-- [3,10,17]
-- > sumaPositivos [[-1,-2,-3],[],[4,5,6]]
-- [0,0,15]
-- ---------------------------------------------------------------------

sumaPositivosR :: (Ord a, Num a) => [[a]] -> [a]
sumaPositivosR [] = []
sumaPositivosR (x:xs)
                    | x == [] || and [ x' <= 0 | x' <- x] = 0 : sumaPositivosR xs
                    | otherwise =  sum [ x' | x' <- x , x'>0] : sumaPositivosR xs

-- ---------------------------------------------------------------------
-- Ejercicio 2 (1.5 puntos)
-- ---------------------------------------------------------------------
-- Define una función que reciba una lista de listas de números y devuelva 
-- una lista con las medias de cada sublista. Implementa la función usando 
-- orden superior.
--
-- > mediaSublistas [[1,2,3],[4,5,6],[7,8,9]]
-- [2.0,5.0,8.0]
-- > mediaSublistas [[1,2],[3,4,5,6],[]]
-- [1.5,4.5,0.0]
-- ---------------------------------------------------------------------

mediaSublistasR :: Integral a => [[a]] -> [Float]
mediaSublistasR [] = []
mediaSublistasR (x:xs)
                    | x == [] = 0.0 : mediaSublistasR xs
                    | otherwise = mediaEnteros x : mediaSublistasR xs
                        where mediaEnteros x = (fromIntegral (sum x) ::Float) / (fromIntegral (length x) ::Float)

-- ---------------------------------------------------------------------
-- Ejercicio 4 (3 puntos)
-- ---------------------------------------------------------------------
-- Define una función que reciba una lista de números y devuelva la subsecuencia 
-- más larga de números consecutivos. La subsecuencia debe ser continua.
--
-- > subsecuenciaConsecutiva [1,2,3,5,6,7,8,10,11]
-- [5,6,7,8]
-- > subsecuenciaConsecutiva [1,3,5,7,9]
-- [1]
-- > subsecuenciaConsecutiva [4,5,6,1,2,3,4,7,8,9]
-- [1,2,3,4] 
-- ---------------------------------------------------------------------

subsecuenciaConsecutiva :: (Eq a, Num a) => [a] -> [a]
subsecuenciaConsecutiva xs = head (map (\(x,y) -> x)(sortBy (\(x,y) (x1,y1) -> compare y1 y) [(x,length x) | x <- subsecuenciasCumplen xs]))

subsecuenciasCumplen :: (Eq a, Num a) => [a] -> [[a]]
subsecuenciasCumplen xs = [ take tk (drop dr xs)| dr <- [0..length xs-1], tk <- reverse[1..length xs], propiedad (take tk (drop dr xs))]

propiedad :: (Eq a, Num a) => [a] -> Bool
propiedad xs = and [ x +1 == y | (x,y) <- zip xs (tail xs)]


-- ---------------------------------------------------------------------
-- Ejercicio 6 (3 puntos)
-- ---------------------------------------------------------------------
-- Define una función que reciba una lista de números y devuelva la subsecuencia 
-- más larga de números que formen una progresión aritmética. La subsecuencia 
-- debe ser continua.
--
-- > subsecuenciaAritmetica [1,2,5,7,9,2,4,6,8,10]
-- [2,4,6,8,10]
-- > subsecuenciaAritmetica [1,2,4,6,8,10]
-- [2,4,6,8,10]
-- > subsecuenciaAritmetica [5,10,15,20,25,30,35,40]
-- [5,10,15,20,25,30,35,40]
-- ---------------------------------------------------------------------

subsecuenciaAritmetica :: Integral a => [a] -> [a]
subsecuenciaAritmetica xs = head (map (\(x,y) -> x)(sortBy (\(x,y) (x1,y1) -> compare y1 y) [(x,length x) | x <- subsecuenciasCumplen' xs])) 

subsecuenciasCumplen' :: Integral a => [a] -> [[a]]
subsecuenciasCumplen' xs = [ take tk (drop dr xs)| dr <- [0..length xs-1], tk <- reverse[1..length xs], propiedad' (take tk (drop dr xs))]

propiedad' :: Integral a => [a] -> Bool
propiedad' xo@(x:xs) = and [z - y == x || div z y == x | (y,z) <- zip xo (tail xo)]


import Data.Char
import Data.Array
import Data.List
import Test.QuickCheck
import Control.Exception (catch, SomeException)

-- -----------------------------------------------------------------------------
-- Programación Declarativa 2024/25
-- Grado de Ingeniería Informática - Tecnologías Informáticas y
-- Doble Grado en Matemáticas e Ingeniería Informática
-- 1º Parcial (Simulacro)                                  25 de Octubre de 2024
-- -----------------------------------------------------------------------------
-- Apellidos:
-- Nombre:
-- UVUS:
-- Laboratorio/Puesto:
--
-- NO OLVIDES RELLENAR CON TUS DATOS LA CABECERA ANTERIOR
-- 
-- -----------------------------------------------------------------------------
-- INSTRUCCIONES PARA LA ENTREGA
-- 1. CAMBIA EL NOMBRE de este archivo por:       <uvus>.hs
--    donde "<uvus>" es tu UVUS. 
-- 2. COMENTA LAS LÍNEAS CON ERRORES hasta que se pueda cargar el fichero:
--    sin problemas. AQUELLOS ARCHIVOS DE CÓDIGO QUE NO CARGUEN POR ERRORES
--    DE CÓDIGO NO SE CORREGIRÁN.
-- 3. RELLENA los datos de la cabecera incluido el laboratorio y puesto.
-- 4. COMPRIME ESTE archivo en un único fichero llamado EXACTAMENTE:
--      ENTREGA-<uvus>.tar.gz      (o bien)       ENTREGA-<uvus>.tar.xz
--    donde "<uvus>" es tu UVUS. No te olvides del guión después de
--    ENTREGA, y NO lo comprimas en un fichero .zip.
-- 4. REINICIA el equipo. En el menú de selección del sistema (con fondo
--    blanco), HAZ CLICK SOBRE "Enviar examen" al lado de sistema Ubuntu.
-- 5. Pregunta al profesor si ha llegado tu correo correctamente, si es
--    así, ya puedes dejar tu puesto APAGANDO EL EQUIPO (si lo consideras
--    oportuno, vuelve al escritorio y borra el examen del equipo).
-- ----------------------------------------------------------------------
-- ORIENTACIONES
-- · Escribe la solución de cada ejercicio en el hueco reservado para
--   ello. NO ESCRIBAS FUERA DE DICHO HUECO. NO MODIFIQUES NADA DE LOS 
--   ENUNCIADOS.
-- · Se valorará el uso correcto de tipados para cada función definida.
-- · Puedes añadir tantas funciones auxiliares como necesites (incluyendo su 
--   signatura adecuadamente).
-- · Puedes usar otros módulos de Haskell que estén ya importados.
-- -----------------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 1 (2 puntos)
-- ---------------------------------------------------------------------
-- Implementa una función que devuelva todas las subsecuencias de una 
-- lista que sean números primos.
--
-- > subsecuenciasPrimas [1,2,3,4,5,6]
-- [[2,3],[2],[3],[5]]
-- > subsecuenciasPrimas [4,6,8,9]
-- []
--
-- Implementa la función por 
-- a) (1 punto) recursión,
-- b) (1 punto) listas por compresión.
-- ---------------------------------------------------------------------
subsecuenciasPrimasRec :: Integral a => [a] -> [[a]]
subsecuenciasPrimasRec [] = []
subsecuenciasPrimasRec xs = filter (\x -> x /= []) [take x xs 
 | x <- reverse[0..length xs-1], and[esPrimo y | y <- take x xs]] ++ subsecuenciasPrimasRec (tail xs)

esPrimo :: Integral a => a -> Bool
esPrimo n = length (divisores n) == 2

divisores :: Integral a => a -> [a]
divisores n = [ x | x <- [1..n], mod n x == 0]

subsecuenciasPrimasLC :: Integral a => [a] -> [[a]]
subsecuenciasPrimasLC xs = filter (\x -> x /= []) [take y (drop x xs) 
 | x <- [0..length xs-1], y <- (reverse[0..length xs-1]),and[esPrimo x | x <- take y (drop x xs)] ]
-- ---------------------------------------------------------------------
-- Ejercicio 2 (1 punto)
-- ---------------------------------------------------------------------
-- Implementa la propiedad para la función `subsecuenciasPrimas` que has 
-- definido anteriormente. Utiliza el framework de pruebas 
-- QuickCheck para verificar la propiedad.
--
-- Propiedad a verificar: Todas las subsecuencias devueltas por 
-- `subsecuenciasPrimas` deben estar compuestas únicamente por números 
-- primos.
--
-- ---------------------------------------------------------------------

prop_subsecuenciasPrimas :: Integral a => [a] -> Bool
prop_subsecuenciasPrimas xs = and[esPrimo x | x <- concat (subsecuenciasPrimasLC xs)]

-- ---------------------------------------------------------------------
-- Ejercicio 3 (1.5 puntos)
-- ---------------------------------------------------------------------
-- Define el operador binario (~~) que elimina todos los elementos de 
-- la segunda lista que aparecen en la primera lista.
--
-- > [1,2,3] ~~ [2,3,4,5]
-- [4,5]
-- > "hello" ~~ "world"
-- "wrld"
--
-- ---------------------------------------------------------------------

(~~) :: (Foldable t, Eq a) => t a -> [a] -> [a]
(~~) xs ys = [ y | y <- ys, elem y xs == False]

-- Ejercicio 1 (2 puntos)
-- ---------------------------------------------------------------------
-- Implementa una función que devuelva todas las subsecuencias de una 
-- lista que sean números primos y cuya suma sea también un número primo.
--
-- > subsecuenciasPrimasSumaPrimo [1,2,3,4,5,6]
--  [[2,3],[2],[3],[5]]
-- > subsecuenciasPrimasSumaPrimo [4,6,8,9]
--  []
--
-- Implementa la función por 
-- a) (1 punto) recursión,
-- b) (1 punto) listas por compresión.
-- ---------------------------------------------------------------------

subsecuenciasPrimasSumaPrimoRec :: Integral a => [a] -> [[a]]
subsecuenciasPrimasSumaPrimoRec [] = []
subsecuenciasPrimasSumaPrimoRec xs = [take x xs | x <- reverse[1..length xs], 
 esPrimo(sum(take x xs)) && and[ esPrimo x | x <-(take x xs)]] ++ subsecuenciasPrimasSumaPrimoRec (tail xs)

subsecuenciasPrimasSumaPrimoLC :: Integral a => [a] -> [[a]]
subsecuenciasPrimasSumaPrimoLC xs = nub [take y (drop x xs) | x <- [0..length xs-1], y <- (reverse[1..length xs]),
 esPrimo(sum (take y (drop x xs))) && and[ esPrimo x | x <- (take y (drop x xs))]]

-- ---------------------------------------------------------------------
-- Ejercicio 2 (1 punto)
-- ---------------------------------------------------------------------
-- Implementa la propiedad para la función `subsecuenciasPrimasSumaPrimo` 
-- que has definido anteriormente. Utiliza el framework de pruebas 
-- QuickCheck para verificar la propiedad.
--
-- Propiedad a verificar: Todas las subsecuencias devueltas por 
-- `subsecuenciasPrimasSumaPrimo` deben estar compuestas únicamente por 
-- números primos y su suma debe ser un número primo.
--
-- ---------------------------------------------------------------------

prop_subsecuenciasPrimasSumaPrimo :: Integral a => [a] -> Bool
prop_subsecuenciasPrimasSumaPrimo xs = and[and[esPrimo y | y <- x] && esPrimo(sum x) 
 | x <- (subsecuenciasPrimasSumaPrimoLC xs)]

-- ---------------------------------------------------------------------
-- Ejercicio 3 (1.5 puntos)
-- ---------------------------------------------------------------------
-- Define el operador binario (/~) que elimina todos los elementos de 
-- la segunda lista que aparecen en la primera lista y luego invierte 
-- el resultado.
--
-- > [1,2,3] /~ [2,3,4,5]
-- [5,4]
-- > "hello" /~ "world"
-- "dlrw"
--
-- ---------------------------------------------------------------------

(/~) :: (Foldable t, Eq a) => t a -> [a] -> [a]
(/~) xs ys = reverse([x | x <- ys, elem x xs == False])

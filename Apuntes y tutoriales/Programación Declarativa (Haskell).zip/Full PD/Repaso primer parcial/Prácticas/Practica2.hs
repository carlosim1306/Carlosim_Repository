-- PD-Practica 2
-- Definiciones con condicionales, guardas o patrones.
-- Departamento de Ciencias de la ComputaciÃ³n e I.A.
-- Universidad de Sevilla
-- =====================================================================

-- ---------------------------------------------------------------------
-- IntroducciÃ³n                                                       --
-- ---------------------------------------------------------------------

-- En esta relaciÃ³n se presentan ejercicios con definiciones elementales
-- (no recursivas) de funciones que usan condicionales, guardas o
-- patrones. 
-- 
-- Estos ejercicios se corresponden con el tema 4

-- ---------------------------------------------------------------------
-- LibrerÃ­as auxiliares                                             --
-- ---------------------------------------------------------------------

import Test.QuickCheck

-- ---------------------------------------------------------------------
-- Ejercicio 1. Definir la funciÃ³n (divisionSegura x y) tal que dados
-- los nÃºmeros x e y, calcule la devisiÃ³n exacta entre x e y si y no 
-- es cero, en caso contrario devuelve 9999. Por ejemplo,
--    divisionSegura 5.5 4 ==  1.375
--    divisionSegura 7   2 ==  3.5
--    divisionSegura 7   0 ==  9999.0
-- ---------------------------------------------------------------------

divisionSegura = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 2.1. La disyunciÃ³n excluyente xor de dos fÃ³rmulas se
-- verifica si una es verdadera y la otra es falsa. Su tabla de verdad
-- es
--    x     | y     | xor x y
--    ------+-------+---------
--    True  | True  | False 
--    True  | False | True
--    False | True  | True
--    False | False | False
--    
-- Definir la funciÃ³n (xor1 x y) que calcule la disyunciÃ³n excluyente 
-- de x e y, calculada a partir de la tabla de verdad. Usar 4 ecuaciones, 
-- una por cada lÃ­nea de la tabla. 
-- ---------------------------------------------------------------------

xor1 = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 2.2. Definir la funciÃ³n (xor2 x y) que calcule la disyunciÃ³n 
-- excluyente de x e y, calculada a partir de la tabla de verdad. Usar 2 
-- ecuaciones, una por cada valor del primer argumento. 
-- ---------------------------------------------------------------------

xor2 = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 2.3. Definir la funciÃ³n (xor3 x y) que calcule la disyunciÃ³n 
-- excluyente de x e y, calculada a partir de las funciones lÃ³gicas de
--  disyunciÃ³n (||), conjunciÃ³n (&&) y negaciÃ³n (not). Usar 1 ecuaciÃ³n. 
-- ---------------------------------------------------------------------

xor3 = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 2.4. Definir la funciÃ³n (xor4 x y) que calcule la disyunciÃ³n 
-- excluyente de x e y, calculada a partir de desigualdad (/=). 
-- Usar 1 ecuaciÃ³n.
-- ---------------------------------------------------------------------

xor4 = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 2.5. Comprobar con QuickCheck que las cuatros definiciones
-- de xor son equivalentes.
-- ---------------------------------------------------------------------

-- La propiedad es
prop_xor_equivalentes = undefined

-- La comprobaciÃ³n es

-- ---------------------------------------------------------------------
-- Ejercicio 3. Las dimensiones de los rectÃ¡ngulos puede representarse 
-- por pares; por ejemplo, (5,3) representa a un rectÃ¡ngulo de base 5 y 
-- altura 3. 
-- 
-- Definir la funciÃ³n 
--    mayorRectangulo :: (Num a, Ord a) => (a,a) -> (a,a) -> (a,a)
-- tal que (mayorRectangulo r1 r2) que devuelva cuÃ¡l es el rectÃ¡ngulo de 
-- mayor Ã¡rea ente r1 y r2. Las componentes del rectÃ¡ngulo deben ser 
-- numÃ©ricas y con un sentido de orden. Por ejemplo,  
--    mayorRectangulo (4,6) (3,7)  ==  (4,6)
--    mayorRectangulo (4,6) (3,8)  ==  (4,6)
--    mayorRectangulo (4,6) (3,9)  ==  (3,9)
-- ---------------------------------------------------------------------
mayorRectangulo :: (Num a, Ord a) => (a,a) -> (a,a) -> (a,a)
mayorRectangulo (x1,y1) (x2,y2)
  | x1 * y1 > x2 * y2 = (x1,y1)
  | otherwise = (x2,y2)

-- ---------------------------------------------------------------------
-- Ejercicio 4.1. Definir la funciÃ³n (intercambia p) es el punto obtenido 
-- intercambiando las coordenadas del punto p, representado por una tupla. 
-- Por ejemplo,
--    intercambia (2,5)  ==  (5,2)
--    intercambia (5,2)  ==  (2,5)
-- ---------------------------------------------------------------------

intercambia:: (Num a, Ord a) => (a,a) -> (a,a)
intercambia (x,y) = (y,x)

-- ---------------------------------------------------------------------
-- Ejercicio 4.2. Comprobar con QuickCheck que la funciÃ³n intercambia es
-- idempotente; es decir, si se aplica dos veces es lo mismo que no
-- aplicarla ninguna.
-- ---------------------------------------------------------------------

-- La propiedad es
prop_intercambia:: (Num a, Ord a) => (a,a) -> Bool
prop_intercambia (x,y) = intercambia(intercambia (x,y)) == (x,y)

-- La comprobaciÃ³n es

-- ---------------------------------------------------------------------
-- Ejercicio 5.1. Definir la funciÃ³n (distancia p1 p2) que calcule la 
-- distancia euclÃ­dea entre los puntos p1 y p2. Por ejemplo, 
--    distancia (0.5,2) (2.5,3.5) == 2.5 
--    distancia (1,2)   (4,6)     ==  5.0
-- ---------------------------------------------------------------------

distancia:: (Float,Float) -> (Float,Float) -> Float
distancia (x1,y1) (x2,y2) = sqrt $ (x1-x2)^2 + (y1-y2)^2

-- ---------------------------------------------------------------------
-- Ejercicio 5.2. Comprobar con QuickCheck que se verifica la propiedad
-- triangular de la distancia; es decir, dados tres puntos p1, p2 y p3,
-- la distancia de p1 a p3 es menor o igual que la suma de la distancia
-- de p1 a p2 y la de p2 a p3.
-- ---------------------------------------------------------------------

-- La propiedad es

prop_triangular:: (Float,Float) -> (Float,Float) -> (Float,Float) -> Bool
prop_triangular p1 p2 p3 = distancia p1 p3 <= distancia p1 p2  + distancia p2 p3

-- La comprobaciÃ³n es

-- ---------------------------------------------------------------------
-- Ejercicio 6.1. Definir una funciÃ³n (ciclo xs) que calcule la lista 
-- obtenida permutando cÃ­clicamente los elementos de la lista xs, pasando 
-- el Ãºltimo elemento al principio de la lista. Por ejemplo, 
--    ciclo [2,5,7,9]  == [9,2,5,7]
--    ciclo []         == []
--    ciclo [2]        == [2]
-- ---------------------------------------------------------------------

ciclo:: [a] -> [a]
ciclo [] = []
-- ciclo xs = last xs ++ take (ultimo) xs
ciclo xs = [xs !! ultimo] ++ take (ultimo) xs
  where ultimo = length xs -1

-- ---------------------------------------------------------------------
-- Ejercicio 6.2. Comprobar que la longitud es un invariante de la
-- funciÃ³n ciclo; es decir, la longitud de (ciclo xs) es la misma que la
-- de xs.
-- ---------------------------------------------------------------------

-- La propiedad es
prop_ciclo:: [a] -> Bool
prop_ciclo xs = length xs == length (ciclo xs)

-- La comprobaciÃ³n es

-- ---------------------------------------------------------------------
-- Ejercicio 7. Definir la funciÃ³n (numeroMayor x y) que calcule el mayor 
-- nÃºmero de dos cifras que puede construirse con los dÃ­gitos x e y. 
-- Por ejemplo,  
--    numeroMayor 2 5  ==  52
--    numeroMayor 5 2  ==  52
--    numeroMayor 50 3  *** Exception: Los nÃºmeros deben ser de un dÃ­gito
-- ---------------------------------------------------------------------

numeroMayor:: Int -> Int -> Int
numeroMayor x y
  | x > 9 || y > 9 = error "Los números deben ser de un dígito"
  | x > y = x*10 + y
  | otherwise = y * 10 + x

-- ---------------------------------------------------------------------
-- Ejercicio 8. Definir la funciÃ³n (numeroDeRaices a b c) que calcule el
-- nÃºmero de raÃ­ces reales de la ecuaciÃ³n a*x^2 + b*x + c = 0. Por ejemplo,
--    numeroDeRaices 2 0 3    ==  0
--    numeroDeRaices 4 4 1    ==  1
--    numeroDeRaices 5 23 12  ==  2

-- 
-- ---------------------------------------------------------------------

numeroDeRaices:: Int -> Int -> Int -> Int
numeroDeRaices 0 0 _ = 0
numeroDeRaices a b c
  | formula == 0 = 1
  | formula <0 = 0
  | otherwise = 2
    where formula = b^2 - 4 * a * c 

-- ---------------------------------------------------------------------
-- Ejercicio 9.1. Definir la funciÃ³n (raices a b c) que calcule la lista 
-- de las raÃ­ces reales de la ecuaciÃ³n ax^2 + bx + c = 0. Por ejemplo, 
--    raices 1 3 2    ==  [-1.0,-2.0]
--    raices 1 (-2) 1 ==  [1.0,1.0]
--    raices 1 0 1    ==  []
-- ---------------------------------------------------------------------

raices :: Int -> Int -> Int -> [Float]
raices a b c
  | numeroDeRaices a b c == 0 = []
  | numeroDeRaices a b c == 1 = [raizUnica]
  | otherwise = [raiz1, raiz2]
  where
    a' = fromIntegral a :: Float
    b' = fromIntegral b :: Float
    c' = fromIntegral c :: Float
    discriminante = b'^2 - 4 * a' * c'
    raiz1 = (-b' - sqrt discriminante) / (2 * a')
    raiz2 = (-b' + sqrt discriminante) / (2 * a')
    raizUnica = raiz2  -- Para una raíz única, ambas raíces son iguales

-- ---------------------------------------------------------------------
-- Ejercicio 9.2. Definir el operador (x ~= y) que verifica si x e y son 
-- "casi iguales"; es decir si el valor absoluto de su diferencia es 
-- menor que una milÃ©sima. EL tipado de la funciÃ³n debe ser lo mÃ¡s genÃ©rico
-- posible. Por ejemplo, 
--    12.3457 ~= 12.3459  ==  True
--    12.3457 ~= 12.3479  ==  False
-- ---------------------------------------------------------------------

(~=) :: (Ord a, Fractional a) => a -> a -> Bool
(~=) x y = abs(x - y) <= 0.001
infix 4 ~= 

--infixr/l [1..9] Indicamos por donde hay que asociar y la prioridad
-- Cuando no nos pidan un tipado, creamos el operador y hacemos :t

-- ---------------------------------------------------------------------
-- Ejercicio 10. En geometrÃ­a, la fÃ³rmula de HerÃ³n, descubierta por
-- HerÃ³n de AlejandrÃ­a, dice que el Ã¡rea de un triÃ¡ngulo cuyo lados
-- miden a, b y c es la raÃ­z cuadrada de s(s-a)(s-b)(s-c) donde s es el
-- semiperÃ­metro s = (a+b+c)/2
-- 
-- Definir la funciÃ³n (area a b c) que calcule el Ã¡rea del triÃ¡ngulo de 
-- lados a, b y c. Por ejemplo, 
--    area 3 4 5  ==  6.0
--    area 5 5 8  ==  12.0
--    area 5 5 11  *** Exception: El triÃ¡ngulo indicado no existe
-- ---------------------------------------------------------------------

area:: Int -> Int -> Int -> Float
area a b c
  | c' <= a' + b' = sqrt(s*(s-a')*(s-b')*(s-c'))
  | otherwise = error "No existe ese triángulo"
    where
      a' = fromIntegral a :: Float
      b' = fromIntegral b :: Float
      c' = fromIntegral c :: Float
      s = (a'+b'+c')/2
        
-- ---------------------------------------------------------------------
-- Ejercicio 11.1. Los intervalos cerrados se pueden representar mediante
-- una lista de dos nÃºmeros (el primero es el extremo inferior del
-- intervalo y el segundo el superior). 
-- 
-- Definir la funciÃ³n (interseccion i1 i2) que calcule la intersecciÃ³n de 
-- los intervalos enteros cortos i1 e i2. Por ejemplo,
--    interseccion [] [3,5]     ==  []
--    interseccion [3,5] []     ==  []
--    interseccion [2,4] [6,9]  ==  []
--    interseccion [2,6] [6,9]  ==  [6,6]
--    interseccion [2,6] [0,9]  ==  [2,6]
--    interseccion [2,6] [0,4]  ==  [2,4]
--    interseccion [4,6] [0,4]  ==  [4,4]
--    interseccion [5,6] [0,4]  ==  []
-- ---------------------------------------------------------------------

interseccion:: [Int]-> [Int] -> [Int]
interseccion _ [] = []
interseccion [] _ = []
interseccion [x1, x2] [y1, y2]
  | x2 < y1 || y2 < x1 = []
  | otherwise = [max x1 y1, min x2 y2]

-- ---------------------------------------------------------------------
-- Ejercicio 11.2. Comprobar con QuickCheck que la intersecciÃ³n de
-- intervalos es conmutativa.
-- ---------------------------------------------------------------------

-- La propiedad es

prop_interseccion:: [Int] -> [Int] -> Bool
prop_interseccion [x1, x2] [y1, y2] = interseccion [x1, x2] [y1, y2] == interseccion [y1, y2] [x1, x2]

-- La comprobaciÃ³n falla por [] pero no sé que falta

-- ---------------------------------------------------------------------
-- Ejercicio 12.1. Los nÃºmeros racionales pueden representarse mediante
-- pares de nÃºmeros enteros. Por ejemplo, el nÃºmero 2/5 puede
-- representarse mediante el par (2,5). 
-- 
-- Definir la funciÃ³n (formaReducida x) que calcule la forma reducida 
-- del nÃºmero racional x representado de la forma comentada. Por ejemplo, 
--    formaReducida (4,10)  ==  (2,5)
--    formaReducida (0,10)  ==  (0,1)
--    formaReducida (4,0)    *** Exception: No existe ese nÃºmero
-- ---------------------------------------------------------------------

formaReducida:: (Int,Int) -> (Int, Int)
formaReducida (_,0) = error "No existe ese número"
formaReducida (0,_) = (0,1)
formaReducida (x,y) = (div x divisor, div y divisor)
  where divisor = gcd x y

-- ---------------------------------------------------------------------
-- Ejercicio 12.2. Definir la funciÃ³n (sumaRacional x y) que calcule
-- la suma de los nÃºmeros racionales x e y, expresada en forma reducida. 
-- Por ejemplo, 
--    sumaRacional (2,3) (5,6)  ==  (3,2)
--    sumaRacional (3,5) (-3,5) ==  (0,1)
-- ---------------------------------------------------------------------
 
sumaRacional:: (Int,Int) -> (Int,Int) -> (Int,Int)
sumaRacional (x1,y1) (x2,y2) = formaReducida calculo
  where calculo = ((x1*y2)+(x2*y1),(y1*y2))

-- ---------------------------------------------------------------------
-- Ejercicio 12.3. Definir la funciÃ³n (productoRacional x y) es el 
-- producto de los nÃºmeros racionales x e y, expresada en forma reducida. 
-- Por ejemplo, 
--    productoRacional (2,3)  (5,6) ==  (5,9)
--    productoRacional (2,3)  (0,3) ==  (0,1)
--    productoRacional (-2,3) (1,2) ==  (-1,3)
-- ---------------------------------------------------------------------
 
productoRacional:: (Int,Int) -> (Int,Int) -> (Int,Int)
productoRacional (x1,y1) (x2,y2) = formaReducida (x1*x2,y1*y2)
 
-- ---------------------------------------------------------------------
-- Ejercicio 12.4. Definir la funciÃ³n (igualdadRacional x y) que verifica 
-- si los nÃºmeros racionales x e y son iguales. Por ejemplo, 
--    igualdadRacional (6,9) (10,15)  ==  True
--    igualdadRacional (6,9) (11,15)  ==  False
--    igualdadRacional (0,2) (0,-5)   ==  True
-- ---------------------------------------------------------------------
 
igualdadRacional:: (Int,Int) -> (Int,Int) -> Bool
igualdadRacional t1 t2 = formaReducida t1 == formaReducida t2
    
-- ---------------------------------------------------------------------
-- Ejercicio 12.5. Comprobar con QuickCheck la propiedad distributiva
-- del producto racional respecto de la suma.
-- ---------------------------------------------------------------------

-- La propiedad es
prop_distributiva = undefined

-- La comprobaciÃ³n es

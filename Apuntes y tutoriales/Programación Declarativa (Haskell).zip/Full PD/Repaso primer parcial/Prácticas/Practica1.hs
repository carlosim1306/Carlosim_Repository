-- PD-Practica 1
-- Definiciones de funciones, tipos y clases.
-- Departamento de Ciencias de la ComputaciÃ³n e I.A.
-- Universidad de Sevilla
-- =====================================================================

-- A continuaciÃ³n se importa el mÃ³dulo QuickCheck. Necesita ser instalado
-- previamente con Cabal o Stack
import Test.QuickCheck

-- ---------------------------------------------------------------------
-- Ejercicio 1. EvalÃºa las siguientes lÃ­neas para entender cÃ³mo funciona
-- el sistema de tipos que proporciona Haskell.
-- ---------------------------------------------------------------------
-- :type True
-- :t True
-- :t 1
-- :t 1.1
-- :t 'a'
-- :t "a"
-- :t [1,2]
-- :t [1,2.1]
-- :t [1,'a']
-- :t (1,'s')
-- :t [[1],[1,2]] 
-- :t not
-- :t sum
-- :t (+)
-- :t []
-- :t ()
-- :t (3+)
-- :t length
-- :t zip
-- :t take

-- ---------------------------------------------------------------------
-- Ejercicio 2. Sin evaluar las expresiones en GHC, decide quÃ© tipo es  
-- el adecuado para cada una de ellas. Intenta dar el tipo mÃ¡s general.
-- ---------------------------------------------------------------------

-- i1:: Integer  -- El primero va de regalo
-- i1 = 45

-- i2 = "123"
-- i3 = 45 <= i1
-- i4 = 'c'
-- i5 = ["abc","ok"]
-- i6 = head i5
-- i7 = tail "abc"
-- i8 = (True,4.5)
-- i9 = [i1,34]
-- i10 = sum
-- i11 x = length [1..x]

-- ---------------------------------------------------------------------
-- Ejercicio 3. Para cada una de las siguientes expresiones, reemplaza
-- undefined por una expresiÃ³n vÃ¡lida para el tipo que la declara.
-- ---------------------------------------------------------------------

j1:: (String,Integer)
j1 = ("Prueba", 2)

j2:: [Integer]
j2 = [1..10]

j3:: Char
j3 = 'c'

j4:: Double
j4 = 2

j5:: (Integer,String,Integer,Char)
j5 = (9,"prueba",7,'b')

j6:: ([Char],(Bool,String))
j6 = ("undefined",(True, "prueba"))

j7:: [[Bool]]
j7 = [[True,False],[False,True]]

j8:: [(String,Bool)]
j8 = [("undefined", True), ("prueba",False)]

j9:: Integer -> Integer
j9 x = x+x

j10:: Float -> [Bool] -> Bool
j10 x xb = True

j11:: [Char] -> [[Int]]
j11 xc = [[peso,peso], [1..30]]
  where peso = length xc


-- ---------------------------------------------------------------------
-- Ejercicio 4. Conocemos el cambio actual del euro a dÃ³lares estadounidenses: 1
-- Euro son 1.17507 dÃ³lares

--   - Definir la constante tipoCambio con dicho valor.
--   - Calcular la expresiones para el cambio a dÃ³lares de distintas cantidades 
--     de euros y viceversa

-- Ejercicio 5. Definir dos funciones, aEuros y aDolares, que dada una cantidad de
-- dÃ³lares (resp. euros) permita obtener la cantidad de euros (resp.
-- dÃ³lares) equivalente. Volver a calcular los cambios anteriores utilizando las 
-- funciones definidas.

-- Nota: No es necesario redondear el resultado.
-- ---------------------------------------------------------------------

tipoCambio:: Float
tipoCambio = 1.17507

aEuros:: Float -> Float
aEuros x = x * tipoCambio

aDolares:: Float -> Float
aDolares x = x/tipoCambio

-- ---------------------------------------------------------------------
-- Ejercicio 6. Escribir la siguiente propiedad: dada cualquier cantidad de euros,
-- si la cambiamos a dÃ³lares y los dÃ³lares obtenidos los volvemos a
-- cambiar a euros, obtenemos la cantidad de euros original.

-- Nota: una propiedad de es funciÃ³n que devuelve un booleano y su cuerpo
--       define una expresiÃ³n para comprbar una propiedad.
-- ---------------------------------------------------------------------

propiedad_cambio:: Float -> Bool
propiedad_cambio x = x == aEuros(aDolares x)
-- para hacer la prueba de una propiedad se utiliza quickCheck

-- ---------------------------------------------------------------------
-- Ejercicio 7. Si la propiedad anterior ha fallado analiza el posible problema y
-- busca una soluciÃ³n al mismo.
-- ---------------------------------------------------------------------

propiedad_cambio':: Float -> Bool
propiedad_cambio' x = abs (aEuros(aDolares x) - x) <= 0.1

-- ---------------------------------------------------------------------
-- Ejercicio 8. Definir una funciÃ³n que determinar si una cadena de 
-- caracteres es palÃ­ndromo.
--
--
-- $ es_palindromo "anilina"
-- True
-- $ es_palindromo "dÃ¡bale arroz a la zorra el abad"
-- True
-- $ es_palindromo []
-- False
-- $ es_palindromo "hola"
-- False

-- Nota: consideramos que la cadena vacÃ­a no es palÃ­ndromo.
-- ---------------------------------------------------------------------

mitad:: String -> Int
mitad xs = length xs `div` 2

es_palindromo:: String -> Bool
es_palindromo [] = False
es_palindromo xs =
  take mitadLenght xs == take mitadLenght (reverse xs)
  where mitadLenght = mitad xs

es_palindromo':: String -> Bool
es_palindromo' xs
  | xs == [] = False
  | otherwise = take mitadLenght xs == take mitadLenght (reverse xs)
  where mitadLenght = mitad xs
-- ---------------------------------------------------------------------
-- Ejercicio 9. Crear una funciÃ³n que genere la letra de DNI. 
--    Para calcular la letra del DNI o caracter de verificaciÃ³n solo debes 
--    de realizar los siguientes pasos:

--    1. Dividir la parte numÃ©rica del DNI entre el nÃºmero 23.
--    2. Tomamos el resto de dicha divisiÃ³n y buscamos la lista de 
--       letras
-- ---------------------------------------------------------------------

letrasDNI = "TRWAGMYFPDXBBJZSQVHLCKE"

letraDNI:: Int -> Char
letraDNI n = letrasDNI !! (mod n 23)

-- El operador !! sirve para hacer un get en una lista

-- ---------------------------------------------------------------------
-- Ejercicio 12. Consideremos el siguiente juego: Dado un nÃºmero mayor que 1, si es
--  par divÃ­delo entre 2 y si es impar multiplÃ­calo por 3 y sÃºmale 1.
--  Si el resultado es 1 ya has terminado, en caso contrario repite el
--  procedimiento sobre el resultado.

--  Pregunta: Dado un nÃºmero inicial cualquiera, cuÃ¡ntas veces tendrÃ¡s
--  que aplicar el procedimiento.

--  Ejemplos:

--  Si empezamos por 10 => dividimos por 2 y obtenemos 5 =>
--  multiplicamos por 3 y sumamos 1, obteniendo 16 => toca volver a
--  dividir y obtenemos 8 => repetimos y obtenemos 4 => seguimos y
--  obtenemos 2 => alcanzamos el 1.

--  los valores han sido 5, 16, 8, 4, 2, 1: lo hemos aplicado 5 veces

--  Si empezamos por 7 los valores serÃ¡n 22, 11, 34, 17, 52, 26, 13, 40, 20, 10, 5,
--  16, 8, 4, 2, 1: lo hemos aplicado 16 veces.


--  * Definir una funciÃ³n que aplique una vez el procedimiento
--    anterior. Utilizarla sucesivamente para verificar que los
--    resultados proporcionados a partir de 10 y de 7 son correctos.

--    Nota: Pueden ser de utilidad las funciones even y div

--  * Definir una funciÃ³n que dado un nÃºmero natural mayor que uno
--    calcule el nÃºmero de veces que se repite el resultado.

--  * Definir una funciÃ³n que devuelva la lista de resultados hasta
--    llegar  a 1.
-- ---------------------------------------------------------------------

-- Solución usando recursión con acumuladores (Lenght y List)

solucionAcL:: Int -> Int
solucionAcL n = aux_solucionAcL 0 n

aux_solucionAcL:: Integral a => a -> a -> a
aux_solucionAcL ac 1 = ac
aux_solucionAcL ac n
  | even n = aux_solucionAcL (ac+1) (div n 2)
  | otherwise = aux_solucionAcL (ac+1) (n*3+1)

solucionAcList:: Int -> [Int]
solucionAcList n = aux_solucionAclist [] n

aux_solucionAclist:: Integral a => [a] -> a -> [a]
aux_solucionAclist ac 1 = ac
aux_solucionAclist ac n
  | even n = aux_solucionAclist (n:ac) (div n 2)
  | otherwise = aux_solucionAclist (n:ac) (n*3+1)

-- Solución usando recursión simple (Lenght y List)

solucionL:: Integral a => a -> a
solucionL 1 = 0
solucionL n
  | even n = (solucionL (div n 2)) + 1
  | otherwise = (solucionL (n*3+1)) + 1

solucionList:: Integral a => a -> [a]
solucionList 1 = []
solucionList n
  | even n = (solucionList (div n 2)) ++ [n]
  | otherwise = (solucionList (n*3+1)) ++ [n]

-- ---------------------------------------------------------------------
-- Ejercicio 13. Defina la funciÃ³n 'al_ultimo' que toma una lista y
-- envÃ­a a su primer elemento al final de la lista.
--
-- 
-- > al_ultimo [1..3]
-- [2,3,1]
-- > al_ultimo []
-- []
--
-- ---------------------------------------------------------------------

al_ultimo:: [Int] -> [Int]
al_ultimo xs = drop 1 xs ++ take 1 xs

-- ---------------------------------------------------------------------
-- Ejercicio 14. Defina la funciÃ³n 'el_del_medio' que toma una lista y
-- devuelve el elemento central. Si el nÃºmero de elementos N es par, debe
-- devolver el elemento N/2. 
--
-- 
-- > el_del_medio [1..3]
-- 2
-- > el_del_medio []
-- *** Exception: Prelude.!!: index too large
-- > el_del_medio [1..4]
-- 3
--
-- ---------------------------------------------------------------------  

el_del_medio:: [Int] -> Int
el_del_medio xs
  | xs == [] = error "Fallo"
  | mod 2 (length xs) == 0 = xs !! (mitad'+1)
  | otherwise = xs !! mitad'
    where mitad' = div (length xs) 2

-- ---------------------------------------------------------------------
-- Ejercicio 15. Defina la funciÃ³n 'particiona' que toma una lista y 
-- una posiciÃ³n y devuelve una listas con dos listas en su interior 
-- con la particion de la lista original por la posiciÃ³n dada.
--
-- 
-- > particiona [1..10] 3
-- [[1,2,3],[4,5,6,7,8,9,10]]
--
-- > particiona [1..10] 0
-- [[],[1,2,3,4,5,6,7,8,9,10]]
--
-- > > particiona [1..10] 20
-- [[1,2,3,4,5,6,7,8,9,10],[]]

-- ---------------------------------------------------------------------  

particiona:: [Int] -> Int -> [[Int]]
particiona xs n
  | n > length xs = [xs,[]]
  | n == 0 = [[],xs]
  | otherwise = [take n xs,drop n xs]

-- ---------------------------------------------------------------------
-- Ejercicio 16. Define la funciÃ³n 'inserta' que aÃ±ade un nuevo elemento
-- a una lista dada en una posiciÃ³n indicada.
--
-- 
-- > inserta 20 [1..10] 3
-- [1,2,3,20,4,5,6,7,8,9,10]
-- 
-- > inserta 20 [1..10] 20
-- [1,2,3,4,5,6,7,8,9,10,20]
-- 
-- > inserta 20 [1..10] 0
-- [20,1,2,3,4,5,6,7,8,9,10]
-- 
-- --------------------------------------------------------------------- 

inserta:: Int -> [Int] -> Int -> [Int]
inserta a xs n
  | n > length xs = xs ++ [a]
  | otherwise = take n xs ++ [a] ++ drop n xs

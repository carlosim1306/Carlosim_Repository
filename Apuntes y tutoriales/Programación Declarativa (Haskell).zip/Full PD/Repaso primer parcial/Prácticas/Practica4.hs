-- PD-PrÃ¡ctica 4 Sol
-- Definiciones por recursiÃ³n.
-- Departamento de Ciencias de la ComputaciÃ³n e I.A.
-- Universidad de Sevilla
-- =====================================================================

-- ---------------------------------------------------------------------
-- Ejercicio 1. Definir, por recursiÃ³n, la funciÃ³n
-- (sumaCuadradosImparesR xs) que devuelve la suma de los cuadrados de 
-- los nÃºmeros impares de la lista xs. Por ejemplo,
--    sumaCuadradosImparesR [1,2,3]  ==  10
--    sumaCuadradosImparesR [1..10]  ==  165
-- ---------------------------------------------------------------------

sumaCuadradosImparesR:: [Int] -> Int
sumaCuadradosImparesR [] = 0
sumaCuadradosImparesR (x:xs)
  | even x = sumaCuadradosImparesR xs
  | otherwise = x^2 + sumaCuadradosImparesR xs 

sumaCuadradosImparesAR:: [Int] -> Int
sumaCuadradosImparesAR xs = auxSumaCuadradosImpares xs 0

auxSumaCuadradosImpares:: [Int] -> Int -> Int
auxSumaCuadradosImpares [] ac = ac
auxSumaCuadradosImpares (x:xs) ac
  | even x = auxSumaCuadradosImpares xs ac
  | otherwise = auxSumaCuadradosImpares xs (ac+x^2)

sumaCuadradosImparesLC:: [Int] -> Int
sumaCuadradosImparesLC xs = 
  sum [ x^2 | x <- xs , odd x]

-- ---------------------------------------------------------------------
-- Ejercicio 2. Definir, usando recursion, la funciÃ³n (entreL m n) es la
-- lista de los enteros entre m y n. Por ejemplo, 
--    entreL 2 5  ==  [2,3,4,5]
--    entreL 3 1  ==  []
-- ---------------------------------------------------------------------

{-
entreLClase:: Int -> Int -> [Int]
entreLClase m n 
  | m > n = []
  | m == n = [m]
  | otherwise = m: entreLClase ++ entreLClase : m
-}

entreLRA:: Int -> Int -> [Int]
entreLRA a b = auxEntreLRA a b []

auxEntreLRA:: Int -> Int -> [Int] -> [Int]
auxEntreLRA a b ac
  | a > b = ac
  | otherwise = auxEntreLRA (a+1) b (ac ++ [a])

entreLLC:: Int -> Int -> [Int]
entreLLC a b = 
  [ x | x <- [a..b]]

entreLR :: Int -> Int -> [Int]
entreLR x y 
    | x > y = []
    | otherwise = x: entreLR (x+1) y
-- ---------------------------------------------------------------------
-- Ejercicio 3. Definir, por recursiÃ³n, la funciÃ³n (sumaPositivosRec xs)
-- que devuevle la suma de los enteros positivos de xs. Por ejemplo, 
--    sumaPositivosRec [0,1,-3,-2,8,-1,6]        == 15
--    sumaPositivosRec ([1..10]++[-1,-2..(-10)]) == 55
-- ---------------------------------------------------------------------

sumaPositivosR:: [Int] -> Int
sumaPositivosR [] = 0
sumaPositivosR (x:xs)
  | x > 0 = x + sumaPositivosR xs
  | otherwise = sumaPositivosR xs

sumaPositivosRA:: [Int] -> Int
sumaPositivosRA xs = auxSumaPositivosRA xs 0

auxSumaPositivosRA:: [Int] -> Int -> Int
auxSumaPositivosRA [] ac = ac
auxSumaPositivosRA (x:xs) ac 
  | x > 0 = auxSumaPositivosRA xs (x+ac)
  | otherwise = auxSumaPositivosRA xs ac

sumaPositivosLC:: [Int] -> Int
sumaPositivosLC xs =
  sum [ x | x <- xs , x > 0]

-- ---------------------------------------------------------------------
-- Ejercicio 4. El doble factorial de un nÃºmero n se define por 
--    n!! = n*(n-2)* ... * 3 * 1, si n es impar
--    n!! = n*(n-2)* ... * 4 * 2, si n es par
--    1!! = 1
--    0!! = 1    
-- Por ejemplo,
--    8!! = 8*6*4*2   = 384
--    9!! = 9*7*5*3*1 = 945
-- Definir, por recursiÃ³n, la funciÃ³n (dobleFactorial n) que devuelva
-- el doble factorial de n. Por ejemplo,
--    dobleFactorial 8  ==  384
--    dobleFactorial 9  ==  945
-- ---------------------------------------------------------------------

dobleFactorialR:: Int -> Int
dobleFactorialR 0 = 1
dobleFactorialR 1 = 1
dobleFactorialR n = n * dobleFactorialR (n-2)

dobleFactorialRA:: Int -> Int
dobleFactorialRA n = auxDobleFactorialRA n 1

auxDobleFactorialRA::Int -> Int -> Int
auxDobleFactorialRA 0 ac = ac
auxDobleFactorialRA 1 ac = ac
auxDobleFactorialRA n ac = auxDobleFactorialRA (n-2) (ac*n)

dobleFactorialLC:: Int -> Int
dobleFactorialLC n
  | even n = product [x | x <- [2..n], even x]
  | otherwise = product [x | x <- [1..n], odd x]
-- ---------------------------------------------------------------------
-- Ejercicio 5. La distancia de Hamming entre dos listas es el
-- nÃºmero de posiciones en que los correspondientes elementos son
-- distintos. Por ejemplo, la distancia de Hamming entre "roma" y "loba"
-- es 2 (porque hay 2 posiciones en las que los elementos
-- correspondientes son distintos: la 1Åž y la 3Åž).
--    
-- Definir la funciÃ³n (distancia xs ys) que dadas dos listas comparables
-- por igualdad xs e ys, devuelva la distancia Hamming entre xs e ys. 
-- Por ejemplo,
--    distancia "romano" "comino"  ==  2
--    distancia "romano" "camino"  ==  3
--    distancia "roma"   "comino"  ==  2
--    distancia "roma"   "camino"  ==  3
--    distancia "romano" "ron"     ==  1
--    distancia "romano" "cama"    ==  2
--    distancia "romano" "rama"    ==  1
-- ---------------------------------------------------------------------

distanciaR :: (Eq a) => [a] -> [a] -> Integer 
distanciaR [] _ = 0 
distanciaR _ [] = 0
distanciaR (x:xs) (y:ys) 
    | x == y = distanciaR xs ys 
    | otherwise = 1 + distanciaR xs ys


distanciaRA:: (Eq a) => [a] -> [a] -> Int
distanciaRA xs ys = auxDistancia xs ys 0

auxDistancia:: (Eq a) => [a] -> [a] -> Int -> Int
auxDistancia [] _ ac = ac
auxDistancia _ [] ac = ac
auxDistancia (x:xs) (y:ys) ac 
  | x == y = auxDistancia xs ys ac
  | otherwise = auxDistancia xs ys (ac+1)

distanciaLC:: (Eq a) => [a] -> [a] -> Int
distanciaLC xs ys = 
  sum [ 1 | (x,y) <- zip xs ys , x /= y]
-- ---------------------------------------------------------------------
-- Ejercicio 6. Definir por recursiÃ³n la funciÃ³n (sustituyeImpar xs) que
-- devuelve la lista obtenida sustituyendo cada nÃºmero impar de xs por 
-- el siguiente nÃºmero par. Por ejemplo,
--    sustituyeImpar [2,5,7,4]  ==  [2,6,8,4]
--    sustituyeImpar [1..10]    ==  [2,2,4,4,6,6,8,8,10,10]
-- --------------------------------------------------------------------- 

sustituyeImparR:: [Int] -> [Int]
sustituyeImparR [] = []
sustituyeImparR (x:xs)
  | even x = [x] ++ sustituyeImparR xs
  | otherwise = [x+1] ++ sustituyeImparR xs

sustituyeImparRA:: [Int] -> [Int]
sustituyeImparRA xs = auxSustituyeImparRA xs []

auxSustituyeImparRA:: [Int] -> [Int] -> [Int]
auxSustituyeImparRA [] ac = ac
auxSustituyeImparRA (x:xs) ac 
  | even x = auxSustituyeImparRA xs (ac ++ [x])
  | otherwise = auxSustituyeImparRA xs (ac ++ [x+1])

sustituyeImparLC:: [Int] -> [Int]
sustituyeImparLC xs = 
  [ if even x
     then x 
     else x + 1 | x <- xs ]

-- Si hay varios casos para el tratamiento de x en la lista por comprensión se puede usar if

-- ---------------------------------------------------------------------
-- Ejercicio 7. Definir, por recursiÃ³n, la funciÃ³n (digitosR n) devuelve
--  la lista de los dÃ­gitos del entero n. Por ejemplo, 
--    digitosR 320274  == [3,2,0,2,7,4]
--    digitosR 0325    == [3,2,5]
-- ---------------------------------------------------------------------

digitosRA:: Int -> [Int]
digitosRA n = auxDigitosRA n []

auxDigitosRA:: Int -> [Int] -> [Int]
auxDigitosRA 0 ac = ac
auxDigitosRA n ac = auxDigitosRA (div n 10) ((mod n 10):ac)

digitosR:: Int -> [Int]
digitosR 0 = []
digitosR n = digitosR (x) ++ [r]
  where (x,r) = divMod n 10

-- ---------------------------------------------------------------------
-- Ejercicio 8. Definir por recursiÃ³n la funciÃ³n (potencia x n) que
-- devuelve x elevado al nÃºmero natural n. Por ejemplo,  
--    potencia 2   3 ==  8
--    potencia 2.5 2 ==  6.25
-- ---------------------------------------------------------------------

potenciaR:: (Num a, Eq a) => a -> Int -> a
potenciaR _ 0 = 1
potenciaR n e = n * potenciaR n (e-1)

potenciaRA:: (Num a, Eq a) => a -> Int -> a
potenciaRA n e = auxPotenciaRA n e 1

auxPotenciaRA:: (Num a, Eq a) => a -> Int -> a -> a
auxPotenciaRA _ 0 ac = ac
auxPotenciaRA n e ac = auxPotenciaRA n (e-1) (ac*n)

potenciaLC:: (Num a, Eq a) => a -> Int -> a
potenciaLC n e = 
  product [ n | x <- [1..e]]
-- ---------------------------------------------------------------------
-- Ejercicio 9. Definir por recursiÃ³n la funciÃ³n (replicate' n x) es la 
-- lista formado por n copias del elemento x. Por ejemplo,
--    replicate' 3 2  ==  [2,2,2]
--    replicate' 1 5  ==  [5]
-- ---------------------------------------------------------------------

replicateLC:: Int -> a -> [a]
replicateLC n a = 
  [a | x <- [1..n]]

replicateR:: Int -> a -> [a]
replicateR 0 _ = []
replicateR 1 x = [x]
replicateR n a = a : replicateR (n-1) a

replicateRA:: Int -> a -> [a]
replicateRA n a = auxReplicateRA n a []

auxReplicateRA:: Int -> a -> [a]-> [a]
auxReplicateRA 0 _ ac = ac
auxReplicateRA 1 x ac = x : ac
auxReplicateRA n a ac = auxReplicateRA (n-1) a (a : ac)

-- ---------------------------------------------------------------------
-- Ejercicio 10. Dados dos nÃºmeros naturales, a y b, es posible
-- calcular su mÃ¡ximo comÃºn divisor mediante el Algoritmo de
-- Euclides. Este algoritmo se puede resumir en la siguiente fÃ³rmula:
--    mcd(a,b) = a,                   si b = 0
--             = mcd (b, a mÃ³dulo b), si b > 0
-- 
-- Definir la funciÃ³n (mcd a b) que devuelve el mÃ¡ximo comÃºn divisor 
-- de a y b calculado mediante el algoritmo de Euclides. Por ejemplo,
--    mcd 30   45  == 15
--    mcd 1375 165 == 55
--    mcd 17   19  == 1
-- ---------------------------------------------------------------------
mcd:: Int -> Int -> Int
mcd a 0 = a
mcd 0 b = b
mcd a b = mcd b (mod a b)
  

-- ---------------------------------------------------------------------
-- Ejercicio 11. En un templo hindÃº se encuentran tres varillas de
-- platino. En una de ellas, hay 64 anillos de oro de distintos radios,
-- colocados de mayor a menor.
-- 
-- El trabajo de los monjes de ese templo consiste en pasarlos todos a
-- la tercera varilla, usando la segunda como varilla auxiliar, con las
-- siguientes condiciones: 
--   * En cada paso sÃ³lo se puede mover un anillo.
--   * Nunca puede haber un anillo de mayor diÃ¡metro encima de uno de
--     menor diÃ¡metro.
-- La leyenda dice que cuando todos los anillos se encuentren en la
-- tercera varilla, serÃ¡ el fin del mundo.  
-- 
-- Definir la funciÃ³n (numPasosHanoi n) es el nÃºmero de pasos necesarios 
-- para trasladar n anillos. Por ejemplo, 
--    numPasosHanoi 2   ==  3
--    numPasosHanoi 7   ==  127
--    numPasosHanoi 64  ==  18446744073709551615
-- ---------------------------------------------------------------------

-- Sean A, B y C las tres varillas. La estrategia recursiva es la
-- siguiente: 
-- * Caso base (N=1): Se mueve el disco de A a C.
-- * Caso inductivo (N=M+1): Se mueven M discos de A a C. Se mueve el 
--   disco de A a B. Se mueven M discos de C a B.

numPasosHanoiR:: Integer -> Integer
numPasosHanoiR 1 = 1
numPasosHanoiR n = 2^(n-1) + numPasosHanoiR (n-1)

-- ---------------------------------------------------------------------
-- Ejercicio 12. Definir por recursiÃ³n la funciÃ³n (and' xs) verifica si 
-- todos los elementos de xs son verdadero. Por ejemplo,
--    and' [1+2 < 4, 2:[3] == [2,3]]  ==  True
--    and' [1+2 < 3, 2:[3] == [2,3]]  ==  False
-- ---------------------------------------------------------------------

andR:: [Bool] ->  Bool
andR [] = True
andR (x:xs) = x == (andR xs)


-- ---------------------------------------------------------------------
-- Ejercicio 13. Definir por recursiÃ³n la funciÃ³n (elem' x xs) se 
-- verifica si x pertenece a la lista xs. Por ejemplo, 
--    elem' 3 [2,3,5]  ==  True
--    elem' 4 [2,3,5]  ==  False
-- ---------------------------------------------------------------------

elemR:: (Eq a) => a -> [a] -> Bool
elemR x [] = False
elemR x (y:ys) = x == y || elemR x ys

-- ---------------------------------------------------------------------
-- Ejercicio 14. Definir por recursiÃ³n la funciÃ³n (last xs) que devuelve
-- el Ãºltimo elemento de xs. Por ejemplo,
--    last' [2,3,5]  ==  5
--    last' []       *** Exception: Lista vacÃ­a 
-- ---------------------------------------------------------------------

lastR:: [a] -> a
lastR [] = error "Lista vacía"
lastR [x] = x
lastR (x:xs) = lastR xs

-- ---------------------------------------------------------------------
-- Ejercicio 15. Definir por recursiÃ³n la funciÃ³n (concat' xss) es la 
-- lista obtenida concatenando las listas de xss. Por ejemplo,
--    concat' [[1..3],[5..7],[8..10]]  ==  [1,2,3,5,6,7,8,9,10]
-- ---------------------------------------------------------------------

concatR:: [[a]] -> [a]
concatR [] = []
concatR (x:xxs) = x ++ concatR xxs

-- ---------------------------------------------------------------------
-- Ejercicio 16. Definir por recursiÃ³n la funciÃ³n (selecciona xs n) que
-- devuelve el n-Ã©simo elemento de xs. Por ejemplo,
--    selecciona [2,3,5,7] 2  ==  5 
--    selecciona [2,3,5,7] 7  *** Exception: Ãndice fuera de rango
-- ---------------------------------------------------------------------

seleccionaR:: [a] -> Int -> a
seleccionaR [] _ = error "La lista está vacía"
seleccionaR (x:xs) n 
  | n >= length xs = error "Selección fuera de rango"
  | n == 0 = x
  | otherwise = seleccionaR xs (n-1)

-- ---------------------------------------------------------------------
-- Ejercicio 17. Definir por recursiÃ³n la funciÃ³n (take' n xs) es la 
-- lista de los n primeros elementos de xs. Por ejemplo, 
--    take' 3  [4..12]  ==  [4,5,6]
--    take' 10 [1..5]   ==  [1,2,3,4,5]
--    take' 3  [0..]    ==  [0,1,2]
-- ---------------------------------------------------------------------

takeR:: Int -> [a] -> [a]
takeR 0 _ = []
takeR n (x:xs)
  | n >= length xs = xs
  | otherwise = x : takeR (n-1) xs


-- ---------------------------------------------------------------------
-- Ejercicio 18. Definir por recursiÃ³n la funciÃ³n (mezcla xs ys) es la 
-- lista obtenida mezclando las listas ordenadas xs e ys. Por ejemplo,  
--    mezcla [2,5,6] [1,3,4]  ==  [1,2,3,4,5,6]
-- ---------------------------------------------------------------------

mezclaR:: Ord a => [a] -> [a] -> [a]
mezclaR xs [] = xs
mezclaR [] ys = ys
mezclaR xo@(x:xs) yo@(y:ys)
  | x < y = x : mezclaR xs yo
  | x > y = y : mezclaR xo ys
  | otherwise = x : y : mezclaR xs ys

-- ---------------------------------------------------------------------
-- Ejercicio 19. Definir la funciÃ³n 
--    mitades :: [a] -> ([a],[a]) 
-- tal que (mitades xs) es el par formado por las dos mitades en que se
-- divide xs tales que sus longitudes difieren como mÃ¡ximo en uno. Por
-- ejemplo, 
--    mitades [2,3,5,7,9]  ==  ([2,3],[5,7,9])
-- ---------------------------------------------------------------------

mitades :: [a] -> ([a],[a])
mitades xs = splitAt (div (length xs) 2) xs

-- ---------------------------------------------------------------------
-- Ejercicio 20. Definir por recursiÃ³n la funciÃ³n (ordMezcla xs) que 
-- devuelve la lista obtenida ordenado xs por mezcla (es decir, 
-- considerando que la lista vacÃ­a y las listas unitarias estÃ¡n 
-- ordenadas y cualquier otra lista se ordena mezclando las dos
-- listas que resultan de ordenar sus dos mitades por separado). Por
-- ejemplo, 
--    ordMezcla [5,2,3,1,7,2,5]   == [1,2,2,3,5,5,7]
--    ordMezcla [5,3,2,1,5,10,-1] == [-1,1,2,3,5,5,10]
-- ---------------------------------------------------------------------

ordMezcla:: (Ord a) => [a] -> [a]
ordMezcla [] = []
ordMezcla [x] = [x]
ordMezcla xs = 
  mezclaR (xs1') (xs2')
  where
      (xs1,xs2) = mitades xs
      xs1' = ordMezcla xs1
      xs2' = ordMezcla xs2


-- ---------------------------------------------------------------------
-- Ejercicio 21. Definir por recursiÃ³n la funciÃ³n (borra x xs) es la 
-- lista obtenida borrando una ocurrencia de
-- x en la lista xs. Por ejemplo, 
--    borra 1 [1,2,1]  ==  [2,1]
--    borra 4 [1,2,1]  ==  [1,2,1]
-- ---------------------------------------------------------------------

borraR:: Int -> [Int] -> [Int]
borraR 1 (x:xs) = xs
borraR n xo@(x:xs)
  | n > length xs +1 = xo
  | otherwise = [x] ++ borraR (n-1) xs

-- -----------------------------------------------------------------------------
-- ProgramaciÃ³n Declarativa 2021/22
-- Grado de IngenierÃ­a InformÃ¡tica - TecnologÃ­as InformÃ¡ticas
-- Parcial 1 (grupo 1)                                   10 de Noviembre de 2021
-- -----------------------------------------------------------------------------
-- Apellidos:
-- Nombre:
-- UVUS:
-- Laboratorio/Puesto:
-- -----------------------------------------------------------------------------
-- INSTRUCCIONES PARA LA ENTREGA
-- 1. CAMBIA EL NOMBRE de este archivo por:       <uvus>.hs
--    donde "<uvus>" es tu UVUS.
-- 2. COMENTA LAS LÃNEAS CON ERRORES hasta que se pueda cargar el fichero
--    sin problemas. ESCRIBE tu nombre y apellidos en la cabecera.
-- 3. COMPRIME este archivo en un Ãºnico fichero llamado EXACTAMENTE:
--      ENTREGA-<uvus>.tar.gz      (o bien)       ENTREGA-<uvus>.tar.xz
--    donde "<uvus>" es tu UVUS. No te olvides del guiÃ³n despuÃ©s de
--    ENTREGA, y NO lo comprimas en un fichero .zip.
-- 4. REINICIA el equipo. En el menÃº de selecciÃ³n del sistema (con fondo
--    blanco), HAZ CLICK SOBRE "Enviar examen" al lado de sistema Ubuntu.
-- 5. Pregunta al profesor si ha llegado tu correo correctamente, si es
--    asÃ­, ya puedes dejar tu puesto SIN APAGAR EL EQUIPO.
-- ----------------------------------------------------------------------
-- ORIENTACIONES
-- Â· Escribe la soluciÃ³n de cada ejercicio en el hueco reservado para
--   ello.
-- Â· Se valorarÃ¡ el uso correcto de tipados para cada funciÃ³n definida.
-- Â· Puedes aÃ±adir tantas funciones auxiliares como necesites (incluyendo su 
--   signatura adecuadamente).
-- Â· Puedes usar otros mÃ³dulos de Haskell que estÃ©n ya importados.
-- -----------------------------------------------------------------------------

import Test.QuickCheck
import Data.Char
import Data.List
import Data.Array

levCheck :: (Eq a) => [a] -> [a] -> Int
levCheck (?!?!) (!?!?) = (?!?!?) ! ((?!?), (!?!))
  where (?!?!?) = array (( (**),(**)),((?!?),(!?!))) [(((????),(???!?)),(??!!) (????) (???!?))|
         (????)<-[(**)..(?!?)],(???!?)<-[(**)..(!?!)]];(f,g, (?), (?!?), (!?!), (?!!?), (!??!),
         (**), (??!!??)) = ([length], 0, (\(????) -> (f!!g) (????)), (?) (?!?!), (?) (!?!?), 
         listArray (1, (?!?)) (?!?!), listArray (1, (!?!)) (!?!?), 0, 1);(??!!) 0 (??!?) = (??!?);
         (??!!) (??!?) 0 = (??!?);(??!!) (??!?) (?!??) = (\(??!?) (?!??) -> if  (?!!?) ! (??!?) 
         == (!??!) ! (?!??) then (?!?!?) ! ((??!?)-(??!!??), (?!??)-1) else (??!!??) + (\(??) -> 
         minimum (??)) [(\(??) (???) -> (?!?!?) ! ((??),(???))) (??!?) ((?!??)-(??!!??)), (\(?) 
         (????) -> (?!?!?) ! ((?),(????))) ((??!?)-(??!!??)) (?!??), (\(?) (????) -> (?!?!?) ! 
         ((?),(????))) ((??!?)-(??!!??)) ((?!??)-(??!!??))]) (??!?) (?!??) 

lev''' :: (Eq a) => [a] -> [a] -> Int
lev''' xs ys = levMemo ! (n, m)
  where levMemo = array ((0,0),(n,m)) [((i,j),lev i j) | i <- [0..n], j <- [0..m]]
        n = length xs
        m = length ys
        xa = listArray (1, n) xs
        ya = listArray (1, m) ys
        lev 0 v = v
        lev u 0 = u
        lev u v
          | xa ! u == ya ! v = levMemo ! (u-1, v-1)
          | otherwise        = 1 + minimum [levMemo ! (u, v-1),
                                            levMemo ! (u-1, v),
                                            levMemo ! (u-1, v-1)]    

-- -----------------------------------------------------------------------------
-- Ejercicio 1 (2 puntos) La distancia de Hamming esta Ãºnicamente definida
-- para cadenas de igual tamaÃ±o. Una mejor mÃ©trica para medir la diferencia entre 
-- cadenas listas es la distancia de Levenshtein. Esta distancia mide
-- el nÃºmero de ediciones (eliminar, insertar o substituir) necesarias 
-- para transformar una cadea en otra. Su definiciÃ³n recursiva es la
-- siguiente:


-- lev (a, b) = longitud a				      ; si la longitud de b es cero
-- lev (a, b) = longitud b				      ; si la longitud de a es cero
-- lev (a, b) = lev (cola a), (cola b)    		      ; si el primer caracta de a y b coinciden

--                                | lev (cola a), b
-- lev (a, b) = lev 1 + mÃ­nimo de | lev a, (cola b)	      ; en otro caso
--                                | lev (cola a), (cola b) 
                               
-- Se pide desarrollar la funcion (lev xs ys) que implemente el algoritmo de levenshtein 
-- usando RECURSIÃ“N y PATRONES siempre que se pueda.
--
-- > lev "hola" "hola mundo"
-- 6
-- > lev "hola mundo" "hola mudo"
-- 1
-- > lev "" "hola mundo"
-- 7
-- -----------------------------------------------------------------------------
                 
lev:: Eq a => [a] -> [a] -> Int
lev [] ys = length ys
lev xs [] = length xs
lev xo@(x:xs) yo@(y:ys)
                      | x == y = lev xs ys
                      |otherwise = 1 + minimum [lev xs yo, lev xo ys, lev xs ys]
                             
-- La siguiente propiedad permite comprobar si la implementaciÃ³n es correcta:
       
-- -----------------------------------------------------------------------------
-- Ejercicio 2.1 (0.5 puntos) La funciÃ³n i2n mapea dos coordenadas (i,j) a 
-- la valor numÃ©rico. Esta funciÃ³n es Ãºltil si por ejemplo queremos aplanar una 
-- matriz y necesitamos determinar que posiciÃ³n en el array ocupara la
-- coordenada (i,j)
--    
--             -------------
--             | a | b | c |
--             -------------
--             | d | e | f |    ---> [a,b,c,d,e,f,g,h,j]
--             -------------
--             | g | h | j |
--             -------------
--
-- La coordnada de la letra e en la matriz es (1,1) y en el array 4. El valor
-- de m en la funciÃ³n (i2n i j m) corresponde al mayor Ã­ndice de las columnas
-- en la matriz. En este caso 2
--
-- > i2n 1 1 2lev 
-- 4

i2n i j m = i * (m+1) + j
                                
                            
-- SE PIDE:
--    - crear una propiedad para asegurar que dados dos nÃºmero a b, la funciÃ³n 
--       i2n siempre darÃ¡ un valor distinto para otro dos nÃºmero c d con a != c o b != d
--    - comprobar dicha propiedad con quickCheck
----------------------------------------------------------------------------------

prop_i2n :: (Num a ,Eq a) => a -> a -> a -> a -> a  -> Bool
prop_i2n a b m c d
                  | a /= c ||  b /= d = (i2n a b m) /= (i2n c d m)
                  | otherwise = (i2n a b m) == (i2n c d m)
                      
-- Con property
prop_i2n' :: (Num a, Eq a, Show a) => a -> a -> a -> a -> a -> Property
prop_i2n' a b m c d
  | a /= c ||  b /= d  = i2n a b m =/= i2n c d m
  | otherwise        = i2n a b m === i2n c d m

-- comprobar con quickCheck 
-- > quickCheck prop_i2n


-- -----------------------------------------------------------------------------
-- Ejercicio 2.2 (2 puntos). La implementacion anterior de levenstein es muy lenta 
-- ya que se estÃ¡n repitiendo cÃ¡lculos constantemente en las llamadas recursivas
-- al buscar la distancia mÃ­nima. Para optimizar el cÃ³digo anterior debemos
-- usar una estructura donde ir almacenando los cÃ¡lculos ya realizado y acceder
-- ha dicha estructura envez de volver a calcular. Esta tÃ©cnica se denomina
-- memorizaciÃ³n y estÃ¡ muy relacionado con la programaciÃ³n dinÃ¡mica.
--
-- Se pide completar la implementaciÃ³n de la version del anterior del algoritmo 
-- usando memorizaciÃ³n con una lista como estructura de memoria. Cada posiciÃ³n 
-- de la lista deberÃ¡ contener la distancia mÃ­nima considerando los i, j primeros
-- caractereres de las cadenas xs e ys. 
--
-- Nota: usa la funciÃ³n i2n para acceder a la posiciÃ³n correcta de la lista
-- en funciÃ³n de i y j
-- Nota: en este ejercicio se pone en prÃ¡ctica el acceso indexado a listas y
-- la evaluaciÃ³n perezosa.
-- Ayuda: levAux recibe como parÃ¡metro dos enteros, indicado lo primeros
-- caracteres de xs e ys que se consideran.
--
--
-- Descomenta el cÃ³digo y completa:
----------------------------------------------------------------------------------

-- lev' xs ys = <accede al Ãºltimo elemento de la lista de memoria>
--       where levMemo = <recorre todas las posiciones de xs e ys llamando a levAux y devolviendo una lista>
--             n = <longitud de xs>
--             m = <longitud de ys>
--             levAux 0 0 = <distancia considerando 0 caractres de xs y de ys>
--             levAux 0 j = <distancia considerando 0 caracteres de xs>
--             levAux i 0 = <distancia considerando 0 caracteres de ys>
--             levAux i j 
--                   | <xs[i-1] == ys[i-1]>  	     =	levMemo !! (i2n (i-1) (j-1) m)
--                   | <en otro caso>              = <aplica la definiciÃ³n recursiva para encontrar el mÃ­nimo>
                                                     
{-
lev' xs ys = last levMemo
      where levMemo = [levAux x y | x <- xs, y <-ys]
            n = length xs
            m = length ys 
            levAux 0 0 = 0
            levAux 0 j = m
            levAux i 0 = n
            levAux i j 
                  | xs[i-1] == ys[i-1] 	     =	levMemo !! (i2n (i-1) (j-1) m)
                  | otherwise              = levAux i j                                                
-}

-- La siguiente propiedad permite comprobar si la implementaciÃ³n es correcta:
     


-- ----------------------------------------------------------------------------
-- Ejercicio 3 (2.5 puntos). Se denomina cola de una lista a una sublista no vacÃ­a 
-- formada por un elemento y los siguientes hasta el final. Por ejemplo, [3,4,5] es 
-- una cola de la lista [1,2,3,4,5].
--
-- Definir por LISTA POR COMPRENSIÃ“N, RECURSIÃ“N CON ACUMULADOR, PLEGADO POR LA 
-- IZQUIERDA y ORDEN SUPERIOR (MAP) la funciÃ³n
--   colas :: [a] -> [[a]]
-- tal que '(colas xs)' es la lista de las colas de la lista 'xs'. Por ejemplo,
--   colasAR []         ==  []
--   colasAR [1,2]      ==  [[1,2],[2]]
--   colasAR [4,1,2,5]  ==  [[4,1,2,5],[1,2,5],[2,5],[5]]
-- ----------------------------------------------------------------------------

colasRA:: [a] -> [[a]]                                 
colasRA xs = auxColasRA xs []

auxColasRA:: [a] -> [[a]]  -> [[a]]  
auxColasRA [] ac = ac
auxColasRA xo@(x:xs) ac
                      | length xo == 1 = ac ++ [xo]
                      | otherwise = auxColasRA xs (ac ++ [xo])

colasLC:: [a] -> [[a]]
colasLC xs = [drop x xs | x <- [0..length xs -1]]

colasOS:: [a] -> [[a]]
colasOS xs = map (\x -> drop x xs) [0..length xs -1]

colasPL:: [a] -> [[a]]
colasPL xs = foldl f [] [0..length xs -1]
  where f rec x = rec ++ [drop x xs]
                       
-- ----------------------------------------------------------------------------
-- Ejercicio 4 (2.5 puntos). Definir por comprensiÃ³n la funciÃ³n
--   subOrdenada :: Ord a => [a] -> [a]
-- tal que '(subOrdenada xs)' es la mayor sublista ordenada que llega hasta el
-- final de la lista 'xs'.
-- Por ejemplo,
--   subOrdenada []         ==  []
--   subOrdenada [2,1]      ==  [1]
--   subOrdenada [4,1,2,5]  ==  [1,2,5]
-- ----------------------------------------------------------------------------

ordenada:: Ord a => [a] -> [a]
ordenada [x] = [x]
ordenada [] = []
ordenada (x:xs)
              | x < head xs = x : ordenada xs
              | otherwise = []

subOrdenada :: Ord a => [a] -> [a]
subOrdenada xs =  head [ordenada (drop x xs) | x <- [0..length xs] ,length (ordenada (drop x xs)) == maximo ]
  where maximo = maximum [ length (ordenada (drop x xs)) | x <- [0..length xs]] 
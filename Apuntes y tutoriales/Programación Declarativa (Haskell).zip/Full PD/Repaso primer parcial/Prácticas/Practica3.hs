-- PD-PrÃ¡ctica 3.1 Sol
-- Definiciones por comprensiÃ³n
-- Departamento de Ciencias de la ComputaciÃ³n e I.A.
-- Universidad de Sevilla
-- =====================================================================

-- ---------------------------------------------------------------------
-- IntroducciÃ³n                                                       --
-- ---------------------------------------------------------------------

-- En esta relaciÃ³n se presentan ejercicios con definiciones de
-- funciones por comprensiÃ³n. 

-- ---------------------------------------------------------------------
-- ImportaciÃ³n de librerÃ­as auxiliares                                  
-- ---------------------------------------------------------------------
 
import Test.QuickCheck
import Data.Char
import Data.List
 
-- ---------------------------------------------------------------------
-- Ejercicio 1. Definir, por comprensiÃ³n, la funciÃ³n (sumaDeCuadrados n)
-- que devuelve la suma de los cuadrados de los primeros n nÃºmeros; 
-- es decir, 1^2 + 2^2 + ... + 100^2. Por ejemplo,
--    sumaDeCuadrados 3    ==  14
--    sumaDeCuadrados 100  ==  338350
-- ---------------------------------------------------------------------

sumaDeCuadrados:: Int -> Int
sumaDeCuadrados n = 
  sum [ x^2 | x <- [1..n]] 

-- ---------------------------------------------------------------------
-- Ejercicio 2. Un entero positivo es perfecto si es igual a la suma de
-- sus factores, excluyendo el propio nÃºmero. Usando una lista por
-- comprensiÃ³n y la funciÃ³n factores (del tema), definir la funciÃ³n 
-- (perfectos n) devuele la lista de todos los nÃºmeros perfectos
-- menores que n. Por ejemplo: 
--    perfectos 500 == [6,28,496]
-- ---------------------------------------------------------------------

factores:: Int -> [Int]
factores n = 
  [x | x <- [1..n-1], mod n x == 0]

perfectos:: Int -> [Int] 
perfectos n = 
  [x | x <- [1..n], sum (factores x) == x]
 
 
-- ---------------------------------------------------------------------
-- Ejercicio 3. El producto escalar de dos listas de enteros xs y ys de
-- longitud n viene dado por la suma de los productos de los elementos
-- correspondientes. Definir por comprensiÃ³n la funciÃ³n 
-- (productoEscalar xs ys) es el producto escalar de las listas xs e ys.
-- Por ejemplo,
--    productoEscalar [1,2,3] [4,5,6]  ==  32
--    productoEscalar [1..4]  [4,5,6]  ==  32
--    productoEscalar [1..]   [4]      ==  4
--
-- Usar QuickCheck para comprobar la propiedad conmutativa del producto
-- escalar.  
-- ---------------------------------------------------------------------
 
-- La definiciÃ³n es
productoEscalar:: [Int] -> [Int] -> Int
productoEscalar xs ys=
  sum [x * y | (x,y) <- zip xs ys]

-- La propiedad conmutativa es

prop_conmutativa_productoEscalar:: [Int] -> [Int] -> Bool
prop_conmutativa_productoEscalar xs ys =
  productoEscalar xs ys == productoEscalar ys xs

-- La comprobaciÃ³n es un facto


-- ---------------------------------------------------------------------
-- Ejercicio 4 (Problema 1 del proyecto Euler) Definir la funciÃ³n
-- (euler1 n) que devuelve la suma de todos los mÃºltiplos de 3 Ã³ 5 
-- menores que n. Por ejemplo,
--    euler1 10  ==  23
--    euler1 15  ==  45
--    euler1 5   ==  3
-- 
-- Calcular la suma de todos los mÃºltiplos de 3 Ã³ 5 menores que 1000.
-- ---------------------------------------------------------------------

euler1:: Int -> Int
euler1 n=
  sum [x | x <- [1..n-1] , mod x 3 == 0 || mod x 5 == 0]
 
-- Cuando vayamos a hacer un módulo el primer argumento es el número al que se lo vamos a hacer y el segundo con el que se hará el mod

-- CÃ¡lculo:
-- 

-- ---------------------------------------------------------------------
-- Ejercicio 5. Definir por comprensiÃ³n la funciÃ³n (replica n x) que 
-- devuelva la lista formada por n copias del elemento x. Por ejemplo,
--    replica 3 True == [True, True, True]
--    replica 5 1    == [1,1,1,1,1]
-- Se corresponde con la funciÃ³n replicate.
-- ---------------------------------------------------------------------
 
replica:: Int -> a -> [a]
replica n v = 
  [ v | x <- [1..n]]

-- ---------------------------------------------------------------------
-- Ejercicio 6. Un nÃºmero natural n se denomina abundante si es menor
-- que la suma de sus divisores propios. Por ejemplo, 12 y 30 son
-- abundantes pero 5 y 28 no lo son.
-- ---------------------------------------------------------------------
-- Ejercicio 6.1. Definir la funciÃ³n numeroAbundante tal que
-- (numeroAbundante n) verifica si n es un nÃºmero abundante. Por
-- ejemplo, 
--    numeroAbundante 5  == False
--    numeroAbundante 12 == True
--    numeroAbundante 28 == False
--    numeroAbundante 30 == True
-- ---------------------------------------------------------------------

numeroAbundante:: Int -> Bool
numeroAbundante n = sum (factores n) > n

-- ---------------------------------------------------------------------
-- Ejercicio 6.2. Definir la funciÃ³n numerosAbundantesMenores tal que
-- (numerosAbundantesMenores n) es la lista de nÃºmeros abundantes
-- menores o iguales que n. Por ejemplo,
--    numerosAbundantesMenores 50  ==  [12,18,20,24,30,36,40,42,48]
-- ---------------------------------------------------------------------

numerosAbundantesMenores:: Int -> [Int]
numerosAbundantesMenores n =
  [x | x <- [1..n] , numeroAbundante x]

-- ---------------------------------------------------------------------
-- Ejercicio 6.3. Definir la funciÃ³n todosPares tal que (todosPares n)
-- se verifica si todos los nÃºmeros abundantes menores o iguales que n
-- son pares. Por ejemplo,
--    todosPares 10    ==  True
--    todosPares 100   ==  True
--    todosPares 1000  ==  False
-- ---------------------------------------------------------------------

todosPares:: Int -> Bool
todosPares n = 
  and [even x | x <- [1..n] , numeroAbundante x]

-- ---------------------------------------------------------------------
-- Ejercicio 6.4. Definir la constante primerAbundanteImpar que calcule
-- el primer nÃºmero natural abundante impar. Determinar el valor de
-- dicho nÃºmero.
-- ---------------------------------------------------------------------

primerAbundanteImpar:: Int -> Int
primerAbundanteImpar n = 
  head [x | x <- numerosAbundantesMenores n, mod x 2 == 1]

valorPrimerAbundanteImpar:: Int
valorPrimerAbundanteImpar = 945

-- El primero es el 945, podemos saberlo comprobando números altos con la función anterior

-- ---------------------------------------------------------------------
-- Ejercicio 7. Definir la funciÃ³n suma tal (suma n) es la suma de los
-- n primeros nÃºmeros. Por ejemplo,
--    suma 3  ==  6
--    suma 10 == 55
-- ---------------------------------------------------------------------

suma:: Int -> Int
suma n = 
  sum [x | x <- [1..n]]

-- ---------------------------------------------------------------------
-- Ejercicio 8. Los triÃ¡ngulo aritmÃ©tico se forman como sigue
--     1
--     2  3
--     4  5  6
--     7  8  9 10
--    11 12 13 14 15
--    16 17 18 19 20 21
-- Definir la funciÃ³n linea tal que (linea n) es la lÃ­nea n-Ã©sima de los
-- triÃ¡ngulos aritmÃ©ticos. Por ejemplo, 
--    linea 1  ==  [1]
--    linea 4  ==  [7,8,9,10]
--    linea 5  ==  [11,12,13,14,15]
-- ---------------------------------------------------------------------

linea:: Int -> [Int]
linea 1 = [1]
linea n = 
  [lastLineaAnterior + x | x <- [1..n]]
  where lastLineaAnterior = linea (n-1) !! (length (linea (n-1)) -1) 

linea':: Int -> [Int]
linea' 1 = [1]
linea' n = 
  [lastLineaAnterior + x | x <- [1..n]]
  where lastLineaAnterior = maximum (linea (n-1))
-- ---------------------------------------------------------------------
-- Ejercicio 9. Definir la funciÃ³n triangulo tal que (triangulo n) es
-- el triÃ¡ngulo aritmÃ©tico de altura n. Por ejemplo,
--    triangulo 3  ==  [[1],[2,3],[4,5,6]]
--    triangulo 4  ==  [[1],[2,3],[4,5,6],[7,8,9,10]]
-- ---------------------------------------------------------------------

triangulo:: Int -> [[Int]]
triangulo n = 
  [linea x | x <- [1..n]]

-- ---------------------------------------------------------------------
-- Ejercicio 10. Definir la funciÃ³n circulo tal que (circulo n) es la
-- cantidad de pares de nÃºmeros naturales (x,y) que se encuentran dentro
-- del cÃ­rculo de radio n. Por ejemplo, 
--    circulo 3  ==  9
--    circulo 4  ==  15
--    circulo 5  ==  22
-- La ecuaciÃ³n de los puntos que estÃ¡n en la circunferencia de centro (0,0)
--  y radio n es: x^2 + y^2 = n^2. Los puntos del interior cumplen la 
-- desigualdad: x^2 + y^2 < n^2 
-- ---------------------------------------------------------------------

circulo:: Int -> Int
circulo n = 
  sum [1 | x <- [0..n], y <- [0..n], x^2 + y^2 < n^2]


circuloOptimizado:: Int -> Int
circuloOptimizado n = 
  sum [1 | x <- [0..n], y <- [0..raizEntera(n^2 - x^2)], x^2 + y^2 < n^2]

-- Por la propiedad podemos deducir que si conocemos 'x' y 'n' 'y'<raiz(n**2-x**2)

raizEntera:: Int -> Int
raizEntera a = floor $ sqrt(a')
  where a' = fromIntegral a :: Float

-- ---------------------------------------------------------------------
-- Ejercicio 11. Definir la funciÃ³n ocurrenciasDelMaximo tal que
-- (ocurrenciasDelMaximo xs) es el par formado por el mayor de los
-- nÃºmeros de xs y el nÃºmero de veces que este aparece en la lista
-- xs, si la lista es no vacÃ­a y es (0,0) si xs es la lista vacÃ­a. Por
-- ejemplo,  
--    ocurrenciasDelMaximo [1,3,2,4,2,5,3,6,3,2,1,8,7,6,5]  ==  (8,1)
--    ocurrenciasDelMaximo [1,8,2,4,8,5,3,6,3,2,1,8]        ==  (8,3)
--    ocurrenciasDelMaximo [8,8,2,4,8,5,3,6,3,2,1,8]        ==  (8,4)
-- ---------------------------------------------------------------------

ocurrenciasDelMaximo:: [Int] -> (Int,Int)
ocurrenciasDelMaximo [] = (0,0)
ocurrenciasDelMaximo xs = (maximo,contadorMaximo)
  where maximo = maximum xs
        contadorMaximo = sum [1 | x <- xs , x == maximo]

--maximum y minimum nos permite saber el máximo y el mínimo de una lista

-- ---------------------------------------------------------------------
-- Ejercicio 12. Definir, por comprensiÃ³n, la funciÃ³n tienenS tal que
-- (tienenS xss) es la lista de las longitudes de las cadenas de xss que
-- contienen el caracter 's' en mayÃºsculas o minÃºsculas. Por ejemplo, 
--    tienenS ["Este","es","un","examen","de","hoy","Suerte"]  ==  [4,2,6]
--    tienenS ["Este"]                                         ==  [4]
--    tienenS []                                               ==  []
--    tienenS [" "]                                            ==  []
-- ---------------------------------------------------------------------

tienenS:: [String] -> [Int]
tienenS xs = 
  [length x | x <- xs , elem 's' x || elem 'S' x]

-- elem nos devuelve si la lista contiene el elemento, primero se pone el elemento y después la lista

-- ---------------------------------------------------------------------
-- Ejercicio 13. Decimos que una lista estÃ¡ algo ordenada si para todo
-- par de elementos consecutivos se cumple que el primero es menor o
-- igual que el doble del segundo. Definir, por comprensiÃ³n, la funciÃ³n
-- (algoOrdenada xs) que se verifica si la lista xs estÃ¡ algo ordenada. 
-- Por ejemplo, 
--    algoOrdenada [1,3,2,5,3,8]  ==  True
--    algoOrdenada [3,1]          ==  False
-- ---------------------------------------------------------------------

algoOrdenada:: [Int] -> Bool
algoOrdenada xs = 
  and [x <= y^2 | (x,y) <- zip xs (drop 1 xs)]

--Importante zip tiene 2 argumentos por lo que si los pones entre parentesis solo lee 1

-- ---------------------------------------------------------------------
-- Ejercicio 14. Definir, por comprensiÃ³n, la funciÃ³n tripletas tal 
-- que (tripletas xs) es la listas de tripletas de elementos
-- consecutivos de la lista xs. Por ejemplo,
--    tripletas [8,7,6,5,4] == [[8,7,6],[7,6,5],[6,5,4]]
--    tripletas "abcd"      == ["abc","bcd"]
--    tripletas [2,4,3]     == [[2,3,4]]
--    tripletas [2,4]       == []
-- ---------------------------------------------------------------------

tripletas:: [a] -> [[a]]
tripletas xs = 
  [[a,b,c] | (a,(b,c)) <- zip xs (zip (drop 1 xs) (drop 2 xs))]

tripletas':: [a] -> [[a]]
tripletas' xs=
    [[x1,x2,x3] | ((x1,x2),x3) <- zip (zip xs cola) (tail cola)] 
    where cola = tail xs

 --Preguntar que forma sería más correcta

-- ---------------------------------------------------------------------
-- Ejercicio 15. Definir la funciÃ³n tresConsecutivas tal que
-- (tresConsecutivas x ys) se verifica si x ocurre tres veces seguidas
-- en la lista ys. Por ejemplo,
--    tresConsecutivas 3 [1,4,2,3,3,4,3,5,3,4,6]  ==  False
--    tresConsecutivas 'a' "abcaaadfg"            ==  True
-- ---------------------------------------------------------------------

tresConsecutivas:: Eq a => a -> [a] -> Bool
tresConsecutivas n xs= 
  or [a == n | (a,(b,c)) <- zip xs (zip (drop 1 xs) (drop 2 xs)), a == b && b == c]

-- Si se pone sin tipado "a" falla porque te dice que tipo a no te asegura la igualdad con ==

-- ---------------------------------------------------------------------
-- Ejercicio 16.1. Definir la funciÃ³n unitarios tal (unitarios n) es
-- la lista de nÃºmeros [n,nn, nnn, ....]. Por ejemplo. 
--    take 7 (unitarios 3) == [3,33,333,3333,33333,333333,3333333]
--    take 3 (unitarios 1) == [1,11,111]
-- ---------------------------------------------------------------------

unitarios :: Int -> [Int]
unitarios n = [n * (sum [10^i | i <- [0..k-1]]) | k <- [1..]]

-- Este es un fumadón

-- ---------------------------------------------------------------------
-- Ejercicio 16.2. Definir la funciÃ³n multiplosUnitarios tal que
-- (multiplosUnitarios x y n) es la lista de los n primeros mÃºltiplos de
-- x cuyo Ãºnico dÃ­gito es y. Por ejemplo,
--    multiplosUnitarios 7 1 2  == [111111,111111111111]
--    multiplosUnitarios 11 3 5 == [33,3333,333333,33333333,3333333333]
-- ---------------------------------------------------------------------

multiplosUnitarios :: Int -> Int -> Int -> [Int]
multiplosUnitarios x y n = take n [num | k <- [1..], let num = read (replicate k (head (show y))) :: Int, num `mod` x == 0]

-- Si entra esto dejo la carrera

-- ---------------------------------------------------------------------
-- Ejercicio 17. Definir la funciÃ³n primosEntre tal que (primosEntre x y)
-- es la lista de los nÃºmero primos entre x e y (ambos inclusive). Por
-- ejemplo, 
--    primosEntre 11 44  ==  [11,13,17,19,23,29,31,37,41,43]
-- ---------------------------------------------------------------------

primosEntre:: Int -> Int -> [Int]
primosEntre a b = 
  [x | x <- [a..b], esPrimo x]

esPrimo:: Int -> Bool
esPrimo 1 = True
esPrimo n = length (listaDiv n) <= 2


listaDiv:: Int -> [Int]
listaDiv n = [x | x <- [1..n], mod n x == 0]

-- ---------------------------------------------------------------------
-- Ejercicio 18. Definir la funciÃ³n cortas tal que (cortas xs) es la
-- lista de las palabras mÃ¡s cortas (es decir, de menor longitud) de la
-- lista xs. Por ejemplo,
--    cortas ["hoy", "es", "un", "buen", "dia", "de", "sol"] ==
--    ["es","un","de"]
-- ---------------------------------------------------------------------

cortas:: [String] -> [String]
cortas xs = [ x | x <- xs , length x == masCorta]
  where masCorta = minimum [length x | x <- xs ]

-- ---------------------------------------------------------------------
-- Ejercicio 19. Un entero positivo n es libre de cuadrado si no es
-- divisible por ningÃºn m^2 > 1. Por ejemplo, 10 es libre de cuadrado
-- (porque 10 = 2*5) y 12 no lo es (ya que es divisible por 2^2). 
-- Definir la funciÃ³n libresDeCuadrado tal que (libresDeCuadrado n) es
-- la lista de los primeros n nÃºmeros libres de cuadrado. Por ejemplo,
--    libresDeCuadrado 15  ==  [1,2,3,5,6,7,10,11,13,14,15,17,19,21,22]
-- ---------------------------------------------------------------------

libreDeCuadrados:: Int -> [Int]
libreDeCuadrados n = 
  take n [ x | x <- [1..] , propiedadLireDeCuadrados x]

propiedadLireDeCuadrados:: Int -> Bool
propiedadLireDeCuadrados 1 = True
propiedadLireDeCuadrados n = and [ mod n (x^2) /= 0 | x <- [2..n]]

-- ---------------------------------------------------------------------
-- Ejercicio 20. Definir la funciÃ³n masOcurrentes tal que
-- (masOcurrentes xs) es la lista de los elementos de xs que ocurren el
-- mÃ¡ximo nÃºmero de veces. Por ejemplo,
--    masOcurrentes [1,2,3,4,3,2,3,1,4] == [3,3,3]
--    masOcurrentes [1,2,3,4,5,2,3,1,4] == [1,2,3,4,2,3,1,4]
--    masOcurrentes "Salamanca"         == "aaaa"
-- ---------------------------------------------------------------------

masOcurrentes:: (Eq a) => [a] -> [a]
masOcurrentes xs = 
  [x | x <- xs , ocurrencia xs x == mayorOcurrencia xs]

ocurrencia:: (Eq a) => [a] -> a -> Int
ocurrencia xs x =  length( filter (==x) xs)

mayorOcurrencia :: (Eq a) => [a] -> Int
mayorOcurrencia xs = maximum [ocurrencia xs x | x <- nub xs]

-- nub devuelve un set de una lista, es decir, elimina los valores repetidos
-- Para los problemas de contadores tipo diccionario, primero creamos la función para contar cuantas veces se repite cada elemento,
-- después creamos la función máximo o mínimo para saber por qué valor vamos a filtrar y después se lo pasamos a la función principal
-- como filtro

-- ---------------------------------------------------------------------
-- Ejercicio 21.1. Definir la funciÃ³n numDiv tal que (numDiv x) es el
-- nÃºmero de divisores del nÃºmero natural x. Por ejemplo, 
--    numDiv 11 == 2 
--    numDiv 12 == 6 
-- ---------------------------------------------------------------------

numDiv:: Int -> Int
numDiv n = 
  length[x | x <-[1..n], mod n x == 0]

-- ---------------------------------------------------------------------
-- Ejercicio 21.2. Definir la funciÃ³n entre tal que (entre a b c) es la
-- lista de los naturales entre a y b con, al menos, c divisores. Por
-- ejemplo,  
--    entre 11 16 5 == [12, 16]
-- ---------------------------------------------------------------------

entre:: Int -> Int -> Int -> [Int]
entre a b c = 
  [x | x <- [a..b], numDiv x >= c ]

-- ---------------------------------------------------------------------
-- Ejercicio 22. Definir la funciÃ³n conPos tal que (conPos xs) es la
-- lista obtenida a partir de xs especificando las posiciones de sus
-- elementos. Por ejemplo, 
--    conPos [1,5,0,7] == [(1,0),(5,1),(0,2),(7,3)]
-- ---------------------------------------------------------------------

conPos:: [Int] -> [(Int,Int)]
conPos xs = 
  [(xs !! x,x)| x <- [0..(length xs )-1] ]

conPosRev:: [Int] -> [(Int,Int)]
conPosRev xs = 
  [(x,xs !! x)| x <- [0..(length xs )-1] ]

-- ---------------------------------------------------------------------
-- Ejercicio 23. Definir la funciÃ³n tal que (pares cs) es la cadena
-- formada por los caracteres en posiciÃ³n par de cs. Por ejemplo, 
--    pares "el cielo sobre berlin" == "e il or eln"
-- ---------------------------------------------------------------------

pares:: String -> String
pares xs= 
  [ xs !! x | x <-[0..(length xs)-1], even x ]

-- ---------------------------------------------------------------------
-- Ejercicio 24.1. Una terna (x,y,z) de enteros positivos es pitagÃ³rica
-- si x^2 + y^2 = z^2. Usando una lista por comprensiÃ³n, definir la
-- funciÃ³n (pitagoricas n) que devuelve la lista de todas las ternas 
-- pitagÃ³ricas cuyas componentes estÃ¡n entre 1 y n. Por ejemplo, 
--    pitagoricas 10  ==  [(3,4,5),(4,3,5),(6,8,10),(8,6,10)]
-- ---------------------------------------------------------------------

pitagoricas:: Int -> [(Int,Int,Int)]
pitagoricas n = 
  [(x,y,z)| x <- [1..n], y <- [1..n], z <- [1..raizEntera(x^2 + y^2)], x^2 + y^2 == z^2]   

-- ---------------------------------------------------------------------
-- Ejercicio 24.2. Definir la funciÃ³n (numeroDePares t) que devuevle
--  el nÃºmero de elementos pares de la terna t. Por ejemplo,
--    numeroDePares (3,5,7)  ==  0
--    numeroDePares (3,6,7)  ==  1
--    numeroDePares (3,6,4)  ==  2
--    numeroDePares (4,6,4)  ==  3
-- ---------------------------------------------------------------------

numeroDePares:: (Int,Int,Int) -> Int
numeroDePares (a,b,c) = contadorPar a + contadorPar b + contadorPar c

contadorPar:: Int -> Int
contadorPar n 
  | even n = 1
  | otherwise = 0

-- ---------------------------------------------------------------------
-- Ejercicio 24.3. Definir la funciÃ³n (conjetura n) se verifica si todas 
-- las ternas pitagÃ³ricas cuyas componentes estÃ¡n entre 1 y n tiene un 
-- nÃºmero impar de nÃºmeros pares. Por ejemplo,
--    conjetura 10  ==  True
-- ---------------------------------------------------------------------

conjetura:: Int -> Bool
conjetura n = 
  and[ mod (numeroDePares x) 2 /= 0 | x <- pitagoricas n]

-- ---------------------------------------------------------------------
-- Ejercicio 25. Definir, por comprensiÃ³n, la funciÃ³n 
-- (sumaConsecutivos xs) que devuelve la suma de los pares de elementos
-- consecutivos de la lista xs. Por ejemplo,
--    sumaConsecutivos [3,1,5,2]  ==  [4,6,7]
--    sumaConsecutivos [3]        ==  []
-- ---------------------------------------------------------------------

sumaConsecutivos:: [Int] -> [Int]
sumaConsecutivos xs = 
  [ x + y | (x,y) <- zip xs (drop 1 xs)]

-- ---------------------------------------------------------------------
-- Ejercicio 26. Los polinomios pueden representarse de forma dispersa o
-- densa. Por ejemplo, el polinomio 6x^4-5x^2+4x-7 se puede representar
-- de forma dispersa por [6,0,-5,4,-7] y de forma densa por
-- [(4,6),(2,-5),(1,4),(0,-7)].  
-- 
-- Dado xs la forma dispersa de un polinomio, definir la funciÃ³n 
-- (densa xs) devuelve la forma densa. Por ejemplo, 
--   densa [6,0,-5,4,-7]  ==  [(4,6),(2,-5),(1,4),(0,-7)]
--   densa [6,0,0,3,0,4]  ==  [(5,6),(2,3),(0,4)]
-- ---------------------------------------------------------------------

densa:: [Int] -> [(Int,Int)]
densa xs = filter (\a -> snd a /= 0) (reverse (conPosRev (reverse xs)))
-- densa xs = filter (\(_, y) -> y /= 0) (reverse (conPosRev (reverse xs)))

--(==n) : filtra los valores de la lista uno a uno quedándose con el que cumpla la condición x == n
--(\a -> snd a /= 0) : si ponemos (\a -> ...) denotamos el valor como una variable, para poder tratarla más fácil
--(\(_, y) -> y /= 0) : si ponemos (\(_, y) -> ...) decimos que los valores son tipo tupla e independientemente del primer valor, podemos comparar y


-- ---------------------------------------------------------------------
-- Ejercicio 27. La funciÃ³n 
--    pares2 :: [a] -> [b] -> [(a,b)]
-- definida por
--    pares2 xs ys = [(x,y) | x <- xs, y <- ys]
-- toma como argumento dos listas y devuelve la listas de los pares con
-- el primer elemento de la primera lista y el segundo de la
-- segunda. Por ejemplo,
--    ghci> pares2 [1..3] [4..6]
--    [(1,4),(1,5),(1,6),(2,4),(2,5),(2,6),(3,4),(3,5),(3,6)]
-- 
-- Definir, usando dos listas por comprensiÃ³n con un generador cada una,
-- la funciÃ³n 
--    pares2' :: [a] -> [b] -> [(a,b)]
-- tal que pares2' sea equivalente a pares.
-- 
-- IndicaciÃ³n: Utilizar la funciÃ³n predefinida concat y encajar una
-- lista por comprensiÃ³n dentro de la otra. 
-- ---------------------------------------------------------------------

-- La definiciÃ³n de pares es
pares2 :: [a] -> [b] -> [(a,b)]
pares2 xs ys = [(x,y) | x <- xs, y <- ys]

-- La redefiniciÃ³n de pares es
pares2' :: [a] -> [b] -> [(a,b)]
pares2' xs ys = concat [[(x,y)| y <- ys]| x <- xs]

-- ---------------------------------------------------------------------
-- Ejercicio 28. La bases de datos sobre actividades de personas pueden
-- representarse mediante listas de elementos de la forma (a,b,c,d),
-- donde a es el nombre de la persona, b su actividad, c su fecha de
-- nacimiento y d la de su fallecimiento. Un ejemplo es la siguiente que
-- usaremos a lo largo de este ejercicio,
-- ---------------------------------------------------------------------

personas :: [(String,String,Int,Int)]
personas = [("Cervantes","Literatura",1547,1616),
            ("Velazquez","Pintura",1599,1660),
            ("Picasso","Pintura",1881,1973),
            ("Beethoven","Musica",1770,1823),
            ("Poincare","Ciencia",1854,1912),
            ("Quevedo","Literatura",1580,1654),
            ("Goya","Pintura",1746,1828),
            ("Einstein","Ciencia",1879,1955),
            ("Mozart","Musica",1756,1791),
            ("Botticelli","Pintura",1445,1510),
            ("Borromini","Arquitectura",1599,1667),
            ("Bach","Musica",1685,1750)]

-- ---------------------------------------------------------------------
-- Ejercicio 28.1. Definir la funciÃ³n nombres tal que (nombres bd) es
-- la lista de los nombres de las personas de la base de datos bd. Por
-- ejemplo,  
--    ghci> nombres personas
--     ["Cervantes","Velazquez","Picasso","Beethoven","Poincare",
--      "Quevedo","Goya","Einstein","Mozart","Botticelli","Borromini",
--      "Bach"]
-- ---------------------------------------------------------------------

nombres:: [(String,String,Int,Int)] -> [String]
nombres xs =  [ a | (a,b,c,d) <- xs]
-- nombres xs =  [ a | (a,_,_,_) <- xs]

-- ---------------------------------------------------------------------
-- Ejercicio 28.2. Definir la funciÃ³n musicos tal que (musicos bd) es
-- la lista de los nombres de los mÃºsicos de la base de datos bd. Por
-- ejemplo,  
--    ghci> musicos personas
--    ["Beethoven","Mozart","Bach"]
-- ---------------------------------------------------------------------

musicos:: [(String,String,Int,Int)] -> [String]
musicos xs = [ a | (a,b,c,d) <- xs, b == "Musica"]

-- ---------------------------------------------------------------------
-- Ejercicio 28.3. Definir la funciÃ³n seleccion tal que (seleccion bd m) 
-- es la lista de los nombres de las personas de la base de datos bd
-- cuya actividad es m. Por ejemplo,  
--    ghci> seleccion personas "Pintura"
--    ["Velazquez","Picasso","Goya","Botticelli"]
-- ---------------------------------------------------------------------

seleccion::[(String,String,Int,Int)] -> String -> [String]
seleccion xs s = [ a | (a,b,c,d) <- xs, b == s]

-- ---------------------------------------------------------------------
-- Ejercicio 28.4. Definir, usando el apartado anterior, la funciÃ³n
-- musicos' tal que (musicos' bd) es la lista de los nombres de los
-- mÃºsicos de la base de datos bd. Por ejemplo,  
--    ghci> musicos' personas
--    ["Beethoven","Mozart","Bach"]
-- ---------------------------------------------------------------------

musicos':: [String]
musicos'= seleccion personas "Musica"

-- ---------------------------------------------------------------------
-- Ejercicio 28.5. Definir la funciÃ³n vivas tal que (vivas bd a) es la
-- lista de los nombres de las personas de la base de datos bd  que
-- estaban vivas en el aÃ±o a. Por ejemplo,  
--    ghci> vivas personas 1600
--    ["Cervantes","Velazquez","Quevedo","Borromini"]
-- ---------------------------------------------------------------------

vivas:: [(String,String,Int,Int)] -> Int -> [String]
vivas xs n = [ a | (a,b,c,d) <- xs, c < n && n < d]

-- ---------------------------------------------------------------------
-- Ejercicio 29.1. En este ejercicio se consideran listas de ternas de
-- la forma (nombre, edad, poblaciÃ³n). 
-- 
-- Definir la funciÃ³n puedenVotar tal que (puedenVotar t) es la
-- lista de las personas de t que tienen edad para votar. Por ejemplo,
--    ghci> puedenVotar [("Ana", 16, "Sevilla"), ("Juan", 21, "Coria"), ("Alba", 19, "Camas"), ("Pedro",18,"Sevilla")] ==
--    ["Juan","Alba","Pedro"]
-- ---------------------------------------------------------------------

xavalitos:: [(String,Int,String)]
xavalitos = [("Ana", 16, "Sevilla"), ("Juan", 21, "Coria"), ("Alba", 19, "Camas"), ("Pedro",18,"Sevilla")]

puedenVotar:: [(String,Int,String)] -> [String]
puedenVotar xs = [ a | (a,b,c) <- xs, b >= 18]

-- ---------------------------------------------------------------------
-- Ejercicio 29.2. Definir la funciÃ³n puedenVotarEn tal que (puedenVotar
-- t p) es la lista de las personas de t que pueden votar en la
-- poblaciÃ³n p. Por ejemplo, 
--    ghci> puedenVotarEn [("Ana", 16, "Sevilla"), ("Juan", 21, "Coria"), 
--                        ("Alba", 19, "Camas"),("Pedro",18,"Sevilla")] 
--                        "Sevilla"
--    ["Pedro"]
-- ---------------------------------------------------------------------

puedenVotarEn:: [(String,Int,String)] -> String -> [String]
puedenVotarEn xs s= [ a | (a,b,c) <- xs, b >= 18 && c == s]

-- ---------------------------------------------------------------------
-- Ejercicio 30. Dos listas xs, ys de la misma longitud son
-- perpendiculares si el producto escalar de ambas es 0, donde el
-- producto escalar de dos listas de enteros xs e ys viene
-- dado por la suma de los productos de los elementos correspondientes.
-- 
-- Definir la funciÃ³n (perpendiculares xs yss) que devuelve la lista 
-- de los elementos de yss que son perpendiculares a xs. Por ejemplo,
--    perpendiculares [1,0,1] [[0,1,0], [2,3,1], [-1,7,1],[3,1,0]] ==
--    [[0,1,0],[-1,7,1]]
-- ---------------------------------------------------------------------

perpendiculares:: [Int] -> [[Int]] -> [[Int]]
perpendiculares xs xxs = 
  [x | x <- xxs , productoEscalar x xs == 0]

-- ---------------------------------------------------------------------
-- Ejercicio 31.1. Un nÃºmero natural n es especial si para todo 
-- divisor d de n, d+n/d es primo. Definir la funciÃ³n (especial x) que 
-- verifica si x es especial. Por ejemplo,
--    especial 30  ==  True
--    especial 20  ==  False
-- ---------------------------------------------------------------------

especial:: Int -> Bool
especial n= 
  and [ esPrimo (x + div n x) | x <- [1..n], mod n x == 0 ]

-- ---------------------------------------------------------------------
-- Ejercicio 31.2. Definir la funciÃ³n (sumaEspeciales n) que devuelva
-- la suma de los nÃºmeros especiales menores o iguales que n. 
-- Por ejemplo, 
--    sumaEspeciales 100  ==  401
-- ---------------------------------------------------------------------

sumaEspeciales:: Int -> Int
sumaEspeciales n = 
  sum[x | x <- [1..n] , especial x]

-- ---------------------------------------------------------------------
-- Ejercicio 32.1. Un nÃºmero es muy compuesto si tiene mÃ¡s divisores que
-- sus anteriores. Por ejemplo, 12 es muy compuesto porque tiene 6
-- divisores (1, 2, 3, 4, 6, 12) y todos los nÃºmeros del 1 al 11 tienen
-- menos de 6 divisores.  
-- 
-- Definir la funciÃ³n (esMuyCompuesto x) que verifica si x es un nÃºmero 
-- muy compuesto. Por ejemplo,
--    esMuyCompuesto 24  ==  True
--    esMuyCompuesto 25  ==  False
-- Calcular  el menor nÃºmero muy compuesto de 4 cifras.
-- ---------------------------------------------------------------------

esMuyCompuesto:: Int -> Bool
esMuyCompuesto n = 
  and [numDiv x < numDiv n | x <- [1..n-1]]

menorMuyCompuesto4:: Int
menorMuyCompuesto4 =
  head[ x | x <- [1000..], esMuyCompuesto x]


-- ---------------------------------------------------------------------
-- Ejercicio 32.2. Definir la funciÃ³n (muyCompuesto n) que devuelve el 
-- n-Ã©simo nÃºmero muy compuesto. Por ejemplo, 
--    muyCompuesto 10  ==  180
-- ---------------------------------------------------------------------

muyCompuesto:: Int -> Int
muyCompuesto n= 
  last(take n[ x | x <- [2..], esMuyCompuesto x])

-- ---------------------------------------------------------------------
-- Ejercicio 33. Definir la funciÃ³n (todosIguales xs) que verifica si 
-- los elementos de la lista xs son todos iguales. Por ejemplo,   
--     todosIguales [1..5]    == False
--     todosIguales [2,2,2]   == True
--     todosIguales ["a","a"] == True
--     todosIguales []        == True
-- ---------------------------------------------------------------------

todosIguales:: (Eq a) => [a] -> Bool
todosIguales [] = True
todosIguales xs = 
  and [ head xs == x| x <- xs]

-- ---------------------------------------------------------------------
-- Ejercicio 34.1. Las bases de datos de alumnos matriculados por
-- provincia y por especialidad se pueden representar como sigue 
--    matriculas :: [(String,String,Int)]
--    matriculas = [("Almeria","Matematicas",27),
--                  ("Sevilla","Informatica",325),
--                  ("Granada","Informatica",296),
--                  ("Huelva","Matematicas",41),
--                  ("Sevilla","Matematicas",122),
--                  ("Granada","Matematicas",131),
--                  ("Malaga","Informatica",314)]
-- Es decir, se indica que por ejemplo en AlmerÃ­a hay 27 alumnos
-- matriculados en MatemÃ¡ticas. 
-- 
-- Definir la funciÃ³n (totalAlumnos bd) que devuelve el total de alumnos 
-- matriculados, incluyendo todas las provincias y todas las 
-- especialidades, en la base de datos bd. Por ejemplo,
--    totalAlumnos matriculas == 1256
-- ---------------------------------------------------------------------

matriculas :: [(String,String,Int)]
matriculas = [("Almeria","Matematicas",27),
              ("Sevilla","Informatica",325),
              ("Granada","Informatica",296),
              ("Huelva","Matematicas",41),
              ("Sevilla","Matematicas",122),
              ("Granada","Matematicas",131),
              ("Malaga","Informatica",314)]

totalAlumnos:: [(String,String,Int)] -> Int
totalAlumnos xs= 
  sum [c | (a,b,c) <- xs]

-- ---------------------------------------------------------------------
-- Ejercicio 34.2. Definir la funciÃ³n tal que (totalMateria bd m) es el 
-- nÃºmero de alumnos de la base de datos bd matriculados en la materia m. 
-- Por ejemplo, 
--    totalMateria matriculas "Informatica" == 935
--    totalMateria matriculas "Matematicas" == 321
--    totalMateria matriculas "Fisica"      == 0
-- ---------------------------------------------------------------------


totalMateria:: [(String,String,Int)] -> String -> Int
totalMateria xs s = sum [c | (a,b,c) <- xs, s == b ]

-- ---------------------------------------------------------------------
-- Ejercicio 35. Dada una lista de nÃºmeros enteros, definiremos el
-- mayor salto como el mayor valor de las diferencias (en valor
-- absoluto) entre nÃºmeros consecutivos de la lista. Por ejemplo, dada
-- la lista [2,5,-3] las distancias son 
--    3 (valor absoluto de la resta 2 - 5) y
--    8 (valor absoluto de la resta de 5 y (-3))
-- Por tanto, su mayor salto es 8. 
-- Nota: No estÃ¡ definido el mayor salto para listas con menos de 
--       2 elementos.
--
-- Definir la funciÃ³n tal que (mayorSalto xs) es el mayor salto de la 
-- lista xs. Por ejemplo, 
--    mayorSalto [1,5]              == 4
--    mayorSalto [10,-10,1,4,20,-2] == 22
-- ---------------------------------------------------------------------

mayorSalto:: [Int] -> Int
mayorSalto xs = 
  maximum[ abs(a - b) | (a,b) <- zip xs (drop 1 xs)]
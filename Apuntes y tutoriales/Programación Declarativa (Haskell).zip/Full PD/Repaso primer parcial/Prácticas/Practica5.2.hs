-- PD 2019-20: Practica 6.2
-- Funciones de orden superior y definiciones por plegados (II)
-- Departamento de Ciencias de la ComputaciÃ³n e Inteligencia Artificial
-- Universidad de Sevilla
-- ============================================================================

-- ============================================================================
-- LibrerÃ­as auxiliares
-- ============================================================================
import Data.Char
import Data.List
import Data.Numbers.Primes
-- ----------------------------------------------------------------------------
-- Ejercicio 1. Se considera la funciÃ³n
--      resultadoPos :: (a -> Integer) -> [a] -> [a]
-- tal que (resultadoPos f xs) es la lista de los elementos de la lista
-- xs tales que el valor de la funciÃ³n f sobre ellos es positivo. Por ejemplo,
--   resultadoPos head [[-1,2],[-9,4],[2,3]]       ==  [[2,3]]
--   resultadoPos sum [[1,2],[9],[-8,3],[],[3,5]]  ==  [[1,2],[9],[3,5]]
--
-- Define esta funciÃ³n
-- 1) por comprensiÃ³n,
-- 2) por orden superior (map, filter, ...),
-- 3) por recursiÃ³n,
-- 4) por plegado (con 'foldr').
-- -----------------------------------------------------------------------------

resultadoPosLC :: (a -> Integer) -> [a] -> [a]
resultadoPosLC p xs =
  [x | x <- xs , p x > 0]

resultadoPosOS :: (a -> Integer) -> [a] -> [a]
resultadoPosOS p xs = filter (\x -> p x > 0) xs

resultadoPosR :: (a -> Integer) -> [a] -> [a]
resultadoPosR p [] = []
resultadoPosR p (x:xs)
                      | p x > 0 = x : resultadoPosR p xs
                      | otherwise = resultadoPosR p xs

resultadoPosPR :: (a -> Integer) -> [a] -> [a]
resultadoPosPR p xs = foldr f [] xs
  where f x ac
              | p x > 0 = x : ac
              | otherwise = ac


-- ----------------------------------------------------------------------------
-- Ejercicio 2. Se considera la funciÃ³n
--     intercala :: Int -> [Int] -> [Int]
-- tal que (intercala y xs) es la lista que resulta de intercalar el elemento
-- y delante de todos los elementos de la lista xs que sean menores que y.
-- Por ejemplo,
--   intercala 5 [1,2,6,3,7,9]  ==  [5,1,5,2,6,5,3,7,9]
--   intercala 5 [6,7,9,8]      ==  [6,7,9,8]
--
-- Define esta funciÃ³n
-- 1) por comprensiÃ³n,
-- 2) por orden superior (map, filter, ...)
-- 3) por recursiÃ³n,
-- 4) por plegado (con 'foldr').
-- ----------------------------------------------------------------------------

intercalaLC:: Int -> [Int] -> [Int]
intercalaLC n xs = 
  concat [ if x < n then [n,x] else [x] | x <- xs ]

intercalaOS':: Int -> [Int] -> [Int]
intercalaOS' n xs = concat (map p xs)
  where p x
          | x < n = [n,x]
          | otherwise = [x]

intercalaOS:: Int -> [Int] -> [Int]
intercalaOS n [] = []
intercalaOS n xo@(x:xs)
                | x > n = tomados ++ intercalaOS n (drop (length tomados) xo)
                | otherwise = [n,x] ++ intercalaOS n xs
  where tomados = takeWhile (\x -> x > n) xo

intercalaRA ::  Int -> [Int] -> [Int]
intercalaRA n xs = auxIntercalaRA n xs []

auxIntercalaRA ::  Int -> [Int] -> [Int] -> [Int]
auxIntercalaRA n [] ac = ac
auxIntercalaRA n (x:xs) ac
                      | x < n = auxIntercalaRA n xs (ac ++ [n,x])
                      | otherwise = auxIntercalaRA n xs (ac ++ [x])
                
intercalaPR ::  Int -> [Int] -> [Int]
intercalaPR n xs = foldr f [] xs
  where f x ac
              | x < n = [5,x] ++ ac
              | otherwise =  x : ac

-- ----------------------------------------------------------------------------
-- Ejercicio 3. Se considera la funciÃ³n
--    dec2ent :: [Integer] -> Integer
-- tal que (dec2ent xs) es el nÃºmero entero cuyas cifras ordenadas son los
-- elementos de la lista xs. Por ejemplo,
--   dec2ent [2,3,4,5]  ==  2345
--   dec2ent [1..9]     ==  123456789
--
-- Defie esta funciÃ³n
-- 1) por comprensiÃ³n,
-- 2) por orden superior (map, filter, ...)
-- 3) por recursiÃ³n,
-- 4) por plegado (con 'foldr').
-- ----------------------------------------------------------------------------

dec2entLC :: [Int] -> Int
dec2entLC xs = sum [ x * 10 ^ y | (x,y) <- zip xs (reverse [0..(length xs -1)])]

dec2entOS :: [Int] -> Int
dec2entOS xs = sum (map (\(x,y) -> x * 10 ^ y ) (zip xs (reverse [0..(length xs -1)])))

-- ----------------------------------------------------------------------------
-- Ejercicio 4. Se considera la funciÃ³n
--     diferencia :: Eq a => [a] -> [a] -> [a]
-- tal que (diferencia xs ys) es la diferencia entre los conjuntos xs e
-- ys; es decir, el conjunto de los elementos de la lista xs que no se
-- encuentran en la lista ys. Por ejemplo,
--   diferencia [2,3,5,6] [5,2,7]  ==  [3,6]
--   diferencia [1,3,5,7] [2,4,6]  ==  [1,3,5,7]
--   diferencia [1,3] [1..9]       ==  []
--
-- Define esta funciÃ³n
-- 1) por comprensiÃ³n,
-- 2) por orden superior (map, filter, ...)
-- 3) por recursiÃ³n,
-- 4) por plegado (con 'foldr').
-- ----------------------------------------------------------------------------

diferenciaLC :: Eq a => [a] -> [a] -> [a]
diferenciaLC xs ys =
  [ x | x <- xs , elem x ys == False]

diferenciaOS :: Eq a => [a] -> [a] -> [a]
diferenciaOS xs ys = filter (\x -> elem x ys == False) xs

diferenciaR :: Eq a => [a] -> [a] -> [a]
diferenciaR [] ys = []
diferenciaR (x:xs) ys
                    | elem x ys = diferenciaR xs ys
                    | otherwise = x : diferenciaR xs ys

diferenciaPR :: Eq a => [a] -> [a] -> [a]
diferenciaPR xs ys = foldr f [] xs
  where f x ac
              | elem x ys = ac
              | otherwise = x : ac

-- ----------------------------------------------------------------------------
-- Ejercicio 5. Se considera la funciÃ³n
--   primerosYultimos :: [[a]] -> ([a],[a])
-- tal que (primerosYultimos xss) es el par formado por la lista de los
-- primeros elementos de las listas no vacÃ­as de xss y la lista de los
-- Ãºltimos elementos de las listas no vacÃ­as de xss. Por ejemplo,
--   primerosYultimos [[1,2],[5,3,4],[],[9]]  ==  ([1,5,9],[2,4,9])
--   primerosYultimos [[1,2],[1,2,3],[1..4]]  ==  ([1,1,1],[2,3,4])

--
-- Define esta funciÃ³n
-- 1) por comprensiÃ³n,
-- 2) por orden superior (map, filter, ...)
-- 3) por recursiÃ³n,
-- 4) por plegado (con 'foldr').
-- ----------------------------------------------------------------------------

primerosYultimosLC :: Eq a => [[a]] -> ([a],[a])
primerosYultimosLC xss = (primeros,ultimos)
  where primeros = [head x | x <- xss , x /= []]
        ultimos = [last x | x <- xss , x /= []]

primerosYultimosOS :: Eq a => [[a]] -> ([a],[a])
primerosYultimosOS xss = (primeros,ultimos)
  where primeros = map (\x -> head x) (filter (\x -> x /= []) xss)
        ultimos = map (\x -> last x) (filter (\x -> x /= []) xss)
-- ----------------------------------------------------------------------------
-- Ejercicio 6. Una lista hermanada es una lista de nÃºmeros estrictamente
-- positivos en la que cada elemento tiene algÃºn factor primo en comÃºn con el
-- siguiente, en caso de que exista, o alguno de los dos es un 1. Por ejemplo,
-- [2,6,3,9,1,5] es una lista hermanada.

-- Se considera la funciÃ³n
--    hermanada :: [Int] -> Bool
-- tal que (hermanada xs) comprueba que la lista xs es hermanada segÃºn la
-- definiciÃ³n anterior. Por ejemplo,
--    hermanada [2,6,3,9,1,5]  ==  True
--    hermanada [2,3,5]        ==  False
--
-- Se pide definir esta funciÃ³n
-- 1) por comprensiÃ³n,
-- 2) por orden superior (map, filter, ...)
-- 3) por recursiÃ³n,
-- 4) por plegado (con 'foldr').
-- ----------------------------------------------------------------------------
-- Nota: Usa la funciÃ³n 'gcd'
-- ----------------------------------------------------------------------------
and':: Bool -> Bool -> Bool
and' x y
      | x == False || y == False = False
      | otherwise = True

hermanadaLC :: [Int] -> Bool
hermanadaLC xs = and [gcd x y /= 1 || x == 1 || y == 1 | (x,y) <- zip xs (tail xs)]

hermanadaOS :: [Int] -> Bool
hermanadaOS xs = and (map (\(x,y) -> gcd x y /= 1 || x == 1 || y == 1 ) (zip xs (tail xs)))

hermanadaR :: [Int] -> Bool
hermanadaR [x] = True
hermanadaR (x:xs) =  and' (gcd x y /= 1 || x == 1 || y == 1) (hermanadaR xs)
  where y = head xs

hermanadaPR :: [Int] -> Bool
hermanadaPR xs =  foldr f True (zip xs (tail xs))
  where f (x,y) ac = and' (gcd x y /= 1 || x == 1 || y == 1) ac

-- ----------------------------------------------------------------------------
-- Ejercicio 7. Un elemento de una lista es permanente si ninguno de los que
-- vienen a continuaciÃ³n en la lista es mayor que Ã©l. Consideramos la funciÃ³n
--   permanentes :: [Int] -> [Int]
-- tal que (permanentes xs) es la lista de los elementos permanentes de la
-- lista xs. Por ejemplo,
--   permanentes [80,1,7,8,4]  ==  [80,8,4]

-- Se pide definir esta funciÃ³n
-- 1) por comprensiÃ³n,
-- 2) por orden superior (map, filter, ...)
-- 3) por recursiÃ³n,
-- 4) por plegado (con 'foldr').
-- ---------------------------------------------------------------------------
-- Nota: Usa la funciÃ³n 'tails' de Data.List.
-- ----------------------------------------------------------------------------

permanentesLC :: [Int] -> [Int]
permanentesLC xs = [ x | (x,y) <- zip xs [1..(length xs)], and [x > x'| x' <- (drop y xs)]]

permanentesOS :: [Int] -> [Int]
permanentesOS xs = map (fst) (filter (\(x,y) -> and (map (\x' -> x > x') (drop y xs))) (zip xs [1..(length xs)]))

permanentesR :: [Int] -> [Int]
permanentesR [] = []
permanentesR (x:xs)
                  | and [ x>y | y <- xs] = x : permanentesR xs
                  | otherwise = permanentesR xs

permanentesPR :: [Int] -> [Int]
permanentesPR xs = foldr f [] (zip xs [1..(length xs)])
  where f (x,y) ac
                  |and [ x > x' | x' <- drop y xs] = x : ac
                  | otherwise = ac

-- ---------------------------------------------------------------------
-- Ejercicio 8. Un nÃºmero entero positivo n es muy primo si es n primo
-- y todos los nÃºmeros que resultan de ir suprimimiendo la Ãºltima cifra
-- tambiÃ©n son primos. Por ejemplo, 7193 es muy primo pues los nÃºmeros
-- 7193, 719, 71 y 7 son todos primos. 
-- 
-- Define la funciÃ³n 
--    muyPrimo :: Integer -> Bool
-- que (muyPrimo n) se verifica si n es muy primo. Por ejemplo,
--    muyPrimo 7193  == True
--    muyPrimo 71932 == False
-- --------------------------------------------------------------------

esPrimo :: Integer -> Bool
esPrimo 1 = True
esPrimo n = (length (divisores n)) == 2

divisores :: Integer -> [Integer]
divisores n = [x | x <- [1..n] , mod n x == 0]

muyPrimoR :: Integer -> Bool
muyPrimoR n
          |n <= 0 = True
          |otherwise = and' (esPrimo n) (muyPrimoR (div n 10))

muyPrimo5Cifras :: Integer
muyPrimo5Cifras = sum [ 1 | x <- [100..999], muyPrimoR x]
-- ---------------------------------------------------------------------
-- Â¿CuÃ¡ntos nÃºmeros de cinco cifras son muy primos?
-- ---------------------------------------------------------------------

-- El cÃ¡lculo es no carga, mucha data

-- ---------------------------------------------------------------------



import Test.QuickCheck
import Data.Char
import Data.List
-- -----------------------------------------------------------------------------
-- Ejercicio 3 (2,5 puntos). El horario de clase se puede representar como una
-- lista de tuplas donde:
--   * la primera componente es el nombre abreviado de la asignatura, 
--   * la segunda componente una lista de ternas, donde:
--      - la primera componente es el nombre del dÃ­a abreviado
--      - la segunda componente es un par que indica hora y minuto de comienzo
--      - la tercera componente es un par que indica hora y minuto de finalizaciÃ³n

horario :: [ ( String, [(String, (Int,Int), (Int,Int))] ) ]
horario = [ ("PD",    [("Mie",(12,30),(14,30)),("Mie",(15,30),(17,30)),("Vie",(12,30),(14,30))]),
            ("IA",    [("Mar",(8,30),(10,30)), ("Jue",(12,30),(14,30))]),
            ("TAI",   [("Lun",(12,30),(14,30)),("Mar",(12,30),(14,30)),("Mar",(15,30),(17,30)), ("Mar",(17,30),(19,30))]),
            ("CIMSI", [("Mar",(10,30),(12,30)),("Vie",(8,30),(10,30)), ("Vie",(10,30),(12,30))]),
            ("GSI",   [("Mie",(10,30),(12,30)),("Vie",(8,30),(10,30)), ("Vie",(10,30),(12,30))])
          ]

-- Define la funciÃ³n (invierteHorario hss), tal que reciba un horario hss
-- como el anterior, y devuelva el calendario de maÃ±ana (de 8:00 a 13:00)
-- indicando para cada dÃ­a de la semana y cada hora, las asignaturas que tenemos
-- programadas. Si no hay asignaturas en un horario, se pone la lista vacÃ­a.
-- En concreto, se debe devolver una lista de pares, donde el primero es el dÃ­a de la
-- semana, y el segundo es una lista de pares (hora,as), siendo as la lista de las 
-- asignaturas que hay en ese momento. Por ejemplo,
-- > invierteHorario horario
--    [("Lun",[(8,[]),(9,[]),(10,[]),(11,[]),(12,[]),(13,["TAI"]),(14,["TAI"])]),
--     ("Mar",[(8,[]),(9,["IA"]),(10,["IA"]),(11,["CIMSI"]),(12,["CIMSI"]),(13,["TAI"]),(14,["TAI"])]),
--     ("Mie",[(8,[]),(9,[]),(10,[]),(11,["GSI"]),(12,["GSI"]),(13,["PD"]),(14,["PD"])]),
--     ("Jue",[(8,[]),(9,[]),(10,[]),(11,[]),(12,[]),(13,["IA"]),(14,["IA"])]),
--     ("Vie",[(8,[]),(9,["CIMSI","GSI"]),(10,["CIMSI","GSI"]),(11,["CIMSI","GSI"]),(12,["CIMSI","GSI"]),(13,["PD"]),(14,["PD"])])]
-- -----------------------------------------------------------------------------

invierteHorario :: [(String,[(String,(Int,Int),(Int,Int))])]-> [(String,[(Int,[String])])]
invierteHorario hss = [ limpiaTupla(concatenaTuplasR (asignaturaPorDiaHora  (asignaturaDiaIniFin horario) dia)) | dia <- diasSemana]
    where diasSemana = ["Lun", "Mar", "Mie", "Jue", "Vie"]

limpiaTupla:: (String,[(Int,[String])]) -> (String,[(Int,[String])])
limpiaTupla (dia,resto) = (dia,nub [if length (filter (\(x,y) -> x == hora) resto) == 1 then  (hora,asig) 
    else (hora,concat (map (\(x,y) -> y)(filter (\(x,y) -> x == hora) resto)))
    | (hora,asig) <- resto])

concatenaTuplasR:: [(String,[(Int,[String])])] -> (String,[(Int,[String])])
concatenaTuplasR [x] = x
concatenaTuplasR (x:xs) = concatenaTuplas x (concatenaTuplasR xs)

concatenaTuplas:: (String,[(Int,[String])]) -> (String,[(Int,[String])]) -> (String,[(Int,[String])])
concatenaTuplas (d1,lista) (d2,lista1) = (d1,nub (lista ++ lista1))

asignaturaPorDiaHora:: [(String,[(String,[Int])])] -> String -> [(String,[(Int,[String])])]
asignaturaPorDiaHora hss dia = [ (dia,[if elem h horas then (h,[asig]) else (h,[])
    | (asig,horas) <- asigHoras, h <- [8..14]])
    | (diaHorario,asigHoras) <- asignaturaPorDia hss dia
 ]

asignaturaPorDia:: [(String,[(String,[Int])])] -> String -> [(String,[(String,[Int])])]
asignaturaPorDia hss dia = filter (\(x,y) -> y /= []) [ (dia,[(asig,horas) | (diaHorario,horas) <- diaHoras, diaHorario == dia])
    | (asig,diaHoras) <- hss]

asignaturaDiaIniFin:: [(String,[(String,(Int,Int),(Int,Int))])] -> [(String,[(String,[Int])])]
asignaturaDiaIniFin hss = [ (asig,[(dia,[horaIni..horaFin]) 
    | (dia,(horaIni,a),(horaFin,b)) <- diaHora, horaIni >= 8 && horaFin <= 14])
    | (asig,diaHora) <- hss]

-- -----------------------------------------------------------------------------
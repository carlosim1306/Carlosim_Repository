-- PD-Practica 1.1
-- Definiciones de funciones, tipos y clases.
-- Departamento de Ciencias de la Computación e I.A.
-- Universidad de Sevilla
-- =====================================================================
import Data.Char
import Data.List

-- Definir previamente los tipos de la funciones a desarrollar.


-- ---------------------------------------------------------------------
-- Ejercicio 1. Define una función que determina si un elemento está
-- presente en una lista.
--
-- *Main> contiene "Hola mundo" 'b'
-- False
-- *Main> contiene "Hola mundo" 'a'
-- True
-- *Main> contiene "Hola mundo" 'm'
-- True
-- *Main> contiene [] 'm'
-- False
-- ---------------------------------------------------------------------

contiene :: String -> Char -> Bool
contiene [] _ = False
contiene (x:xs) c = x == c || contiene xs c

-- ---------------------------------------------------------------------
-- Ejercicio 2. Define una función que devuelva el índice de un elemento
-- dentro de una lista.
--
-- *Main> indice 'b' "Hola mundo"
-- -1
-- *Main> indice 'a' "Hola mundo"
-- 3
-- *Main> indice 'u' "Hola mundo"
-- 6
-- ---------------------------------------------------------------------

indice:: Char -> String -> Int
indice c xs
  | indice_aux c xs 0 <= length xs -1 = res
  | otherwise = -1
    where res = indice_aux c xs 0

indice_aux:: Char -> String -> Int -> Int
indice_aux _ [] ac = ac
indice_aux c (x:xs) ac 
  | x == c = indice_aux c [] ac
  | otherwise = indice_aux c xs ac+1

-- ---------------------------------------------------------------------
-- Ejercicio 3. Elimina el n-ésimo elemento de una lista
-- ---------------------------------------------------------------------

eliminaN:: [a] -> Int -> [a]
eliminaN xs n = take (n-1) xs ++ drop n xs

-- ---------------------------------------------------------------------
-- Ejercicio 4. Define funciones para determinar si un carácter es una 
-- letra mayúscula, es mínuscula o es un número.
--
-- *Main> esMayus 'A'
-- True
-- *Main> esMayus 'z'
-- False
-- *Main> esMinus 'A'
-- False
-- *Main> esMinus 'z'
-- True
-- ---------------------------------------------------------------------

esMayus:: Char -> Bool
esMayus x = elem x ['A'..'Z'] 
esMinus:: Char -> Bool
esMinus x = elem x ['a'..'z']

esNum:: Char -> Bool
esNum x= elem x ['0'..'9']

-- ---------------------------------------------------------------------
-- Ejercicio 5. Define una función para determinar si un carácter es una 
-- letra mayúscula o es mínuscula o es un número
-- ---------------------------------------------------------------------

esLetraNum:: Char -> Bool
esLetraNum x = esNum x || esMayus x || esMinus x


-- ---------------------------------------------------------------------
-- Ejercicio 6. Define una función que determine si hay n elementos 
-- consecutivos de una lista que sumen un valor dado.
--
-- sumaConsecutiva 3 5 [1,2,2,4,5,6,7]
-- True
-- ---------------------------------------------------------------------

sumaConsecutiva:: Int -> Int -> [Int] -> Bool
sumaConsecutiva a b ys@(x:xs)                               --ys@ copia xs en una variable para poder operar con esta manteniendo xs
  | a > length xs = False
  | otherwise = b == sum (take a ys) || sumaConsecutiva a b xs


-- ---------------------------------------------------------------------
-- Ejercicio 7. Convierte una frase en capital case:
--
-- capital "hola mundo"
-- "Hola Mundo"
-- capital ""
-- ""
-- ---------------------------------------------------------------------

capital:: String -> String
capital [] = []
capital (x:xs) = [toUpper x] ++ capital xs








-- PD-Practica 2
-- Definiciones con condicionales, guardas o patrones.
-- Departamento de Ciencias de la ComputaciÃ³n e I.A.
-- Universidad de Sevilla
-- =====================================================================

-- ---------------------------------------------------------------------
-- IntroducciÃ³n                                                       --
-- ---------------------------------------------------------------------

-- En esta relaciÃ³n se presentan ejercicios con definiciones elementales
-- (no recursivas) de funciones que usan condicionales, guardas o
-- patrones. 
-- 
-- Estos ejercicios se corresponden con el tema 4

-- ---------------------------------------------------------------------
-- LibrerÃ­as auxiliares                                             --
-- ---------------------------------------------------------------------

import Test.QuickCheck

-- ---------------------------------------------------------------------
-- Ejercicio 1. Definir la funciÃ³n (divisionSegura x y) tal que dados
-- los nÃºmeros x e y, calcule la devisiÃ³n exacta entre x e y si y no 
-- es cero, en caso contrario devuelve 9999. Por ejemplo,
--    divisionSegura 5.5 4 ==  1.375
--    divisionSegura 7   2 ==  3.5
--    divisionSegura 7   0 ==  9999.0
-- ---------------------------------------------------------------------

divisionSegura = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 2.1. La disyunciÃ³n excluyente xor de dos fÃ³rmulas se
-- verifica si una es verdadera y la otra es falsa. Su tabla de verdad
-- es
--    x     | y     | xor x y
--    ------+-------+---------
--    True  | True  | False 
--    True  | False | True
--    False | True  | True
--    False | False | False
--    
-- Definir la funciÃ³n (xor1 x y) que calcule la disyunciÃ³n excluyente 
-- de x e y, calculada a partir de la tabla de verdad. Usar 4 ecuaciones, 
-- una por cada lÃ­nea de la tabla. 
-- ---------------------------------------------------------------------

xor1 = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 2.2. Definir la funciÃ³n (xor2 x y) que calcule la disyunciÃ³n 
-- excluyente de x e y, calculada a partir de la tabla de verdad. Usar 2 
-- ecuaciones, una por cada valor del primer argumento. 
-- ---------------------------------------------------------------------

xor2 = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 2.3. Definir la funciÃ³n (xor3 x y) que calcule la disyunciÃ³n 
-- excluyente de x e y, calculada a partir de las funciones lÃ³gicas de
--  disyunciÃ³n (||), conjunciÃ³n (&&) y negaciÃ³n (not). Usar 1 ecuaciÃ³n. 
-- ---------------------------------------------------------------------

xor3 = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 2.4. Definir la funciÃ³n (xor4 x y) que calcule la disyunciÃ³n 
-- excluyente de x e y, calculada a partir de desigualdad (/=). 
-- Usar 1 ecuaciÃ³n.
-- ---------------------------------------------------------------------

xor4 = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 2.5. Comprobar con QuickCheck que las cuatros definiciones
-- de xor son equivalentes.
-- ---------------------------------------------------------------------

-- La propiedad es
prop_xor_equivalentes = undefined

-- La comprobaciÃ³n es

-- ---------------------------------------------------------------------
-- Ejercicio 3. Las dimensiones de los rectÃ¡ngulos puede representarse 
-- por pares; por ejemplo, (5,3) representa a un rectÃ¡ngulo de base 5 y 
-- altura 3. 
-- 
-- Definir la funciÃ³n 
--    mayorRectangulo :: (Num a, Ord a) => (a,a) -> (a,a) -> (a,a)
-- tal que (mayorRectangulo r1 r2) que devuelva cuÃ¡l es el rectÃ¡ngulo de 
-- mayor Ã¡rea ente r1 y r2. Las componentes del rectÃ¡ngulo deben ser 
-- numÃ©ricas y con un sentido de orden. Por ejemplo,
--    mayorRectangulo (4,6) (3,7)  ==  (4,6)
--    mayorRectangulo (4,6) (3,8)  ==  (4,6)
--    mayorRectangulo (4,6) (3,9)  ==  (3,9)
-- ---------------------------------------------------------------------

{-
mayorRectangulo :: (Num a, Ord a) => (a,a) -> (a,a) -> (a,a)
mayorRectangulo (x1,y1) (x2, y2) = 
    if x1y1 >= x2y2 
    then (x1,y1) 
    else (x2,y2)

mayorRectangulo2 :: (Num a, Ord a) => (a,a) -> (a,a) -> (a,a)
mayorRectangulo2 r1@(x1,y1) r2@(x2, y2) = 
    if x1y1 >= x2y2 
    then r1
    else r2


mayorRectangulo3 :: (Num a, Ord a) => (a,a) -> (a,a) -> (a,a)
mayorRectangulo3 r1 r2 
    | x1y1 >= x2y2 = r1
    | otherwise = r2
    where 
        (x1,y1) = r1
        (x2,y2) = r2


mayorRectangulo4 :: (Num a, Ord a) => (a,a) -> (a,a) -> (a,a)
mayorRectangulo4 r1 r2 
    | fst r1 * snd r1 >= fst r2 * snd r2 = r1
    -- fst nos sirve para tomar el primer valor de la tupla, snd el segundo
    | otherwise = r2
-}

-- ---------------------------------------------------------------------
-- Ejercicio 4.1. Definir la funciÃ³n (intercambia p) es el punto obtenido 
-- intercambiando las coordenadas del punto p, representado por una tupla. 
-- Por ejemplo,
--    intercambia (2,5)  ==  (5,2)
--    intercambia (5,2)  ==  (2,5)
-- ---------------------------------------------------------------------

intercambia = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 4.2. Comprobar con QuickCheck que la funciÃ³n intercambia es
-- idempotente; es decir, si se aplica dos veces es lo mismo que no
-- aplicarla ninguna.
-- ---------------------------------------------------------------------

-- La propiedad es
prop_intercambia = undefined

-- La comprobaciÃ³n es

-- ---------------------------------------------------------------------
-- Ejercicio 5.1. Definir la funciÃ³n (distancia p1 p2) que calcule la 
-- distancia euclÃ­dea entre los puntos p1 y p2. Por ejemplo, 
--    distancia (0.5,2) (2.5,3.5) == 2.5 
--    distancia (1,2)   (4,6)     ==  5.0
-- ---------------------------------------------------------------------
 
distancia:: (Float,Float) -> (Float,Float) -> Float
distancia (x1,y1) (x2,y2) =
    sqrt $ (x2-x1)^2 + (y2-y1)^2
    -- $ funciona como si se pusiera un parentesis que englobe todo lo que haya detrás
    -- Se puede usar ** en vez de ^ pero es preferible usar ^ para los enteros
    --((x2-x1)^2 + (y2-y1)^2)**(1/2)
    -- Evitando la función sqrt

-- ---------------------------------------------------------------------
-- Ejercicio 5.2. Comprobar con QuickCheck que se verifica la propiedad
-- triangular de la distancia; es decir, dados tres puntos p1, p2 y p3,
-- la distancia de p1 a p3 es menor o igual que la suma de la distancia
-- de p1 a p2 y la de p2 a p3.
-- ---------------------------------------------------------------------

-- La propiedad es
prop_triangular:: (Float,Float) -> (Float,Float) -> (Float,Float) -> Bool
prop_triangular p1 p2 p3 = 
    -- Nos podemos ahorrar el poner todas las tuplas ya que en este caso no necesitamos saber los valores internos de la tupla
    distancia p1 p3 <= distancia p1 p2 + distancia p2 p3

-- La comprobación es

-- ---------------------------------------------------------------------
-- Ejercicio 6.1. Definir una funciÃ³n (ciclo xs) que calcule la lista 
-- obtenida permutando cÃ­clicamente los elementos de la lista xs, pasando 
-- el Ãºltimo elemento al principio de la lista. Por ejemplo, 
--    ciclo [2,5,7,9]  == [9,2,5,7]
--    ciclo []         == []
--    ciclo [2]        == [2]
-- ---------------------------------------------------------------------

ciclo = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 6.2. Comprobar que la longitud es un invariante de la
-- funciÃ³n ciclo; es decir, la longitud de (ciclo xs) es la misma que la
-- de xs.
-- ---------------------------------------------------------------------

-- La propiedad es
prop_ciclo = undefined

-- La comprobaciÃ³n es

-- ---------------------------------------------------------------------
-- Ejercicio 7. Definir la funciÃ³n (numeroMayor x y) que calcule el mayor 
-- nÃºmero de dos cifras que puede construirse con los dÃ­gitos x e y. 
-- Por ejemplo,  
--    numeroMayor 2 5  ==  52
--    numeroMayor 5 2  ==  52
--    numeroMayor 50 3  *** Exception: Los nÃºmeros deben ser de un dÃ­gito
-- ---------------------------------------------------------------------

{-
numeroMayor:: Int -> Int -> Int
numeroMayor x y =
    if (x/10) < 1 || (y/10) <1
    --Esto no se podría hacer porque deberían ser fractional y no Int
        then error "fallaste"
    else if x > y
        then x*10 + y
    else
        y*10 + x
-}

numeroMayor1:: Int -> Int -> Int
numeroMayor1 x y 
    | x < 0 || y < 0 || x >= 10 || y >= 10 =
        error "fallaste"
    | x > y = x*10 + y
    | otherwise = y*10 + x

-- ---------------------------------------------------------------------
-- Ejercicio 8. Definir la funciÃ³n (numeroDeRaices a b c) que calcule el
-- nÃºmero de raÃ­ces reales de la ecuaciÃ³n a*x^2 + b*x + c = 0. Por ejemplo,
--    numeroDeRaices 2 0 3    ==  0
--    numeroDeRaices 4 4 1    ==  1
--    numeroDeRaices 5 23 12  ==  2
-- ---------------------------------------------------------------------

numeroDeRaices:: Int -> Int -> Int -> Int
numeroDeRaices x y z
    | 4* x * z < y^2 = 0
    | 4* x * z == y^2 = 1
    | otherwise = 2

numeroDeRaices1:: Int -> Int -> Int -> Int
numeroDeRaices1 x y z
    | d > 0 = 2
    | d == 0 = 1
    | otherwise = 0
    where
        d = y^2 - 4* x * z 

-- ---------------------------------------------------------------------
-- Ejercicio 9.1. Definir la funciÃ³n (raices a b c) que calcule la lista 
-- de las raÃ­ces reales de la ecuaciÃ³n ax^2 + bx + c = 0. Por ejemplo, 
--    raices 1 3 2    ==  [-1.0,-2.0]
--    raices 1 (-2) 1 ==  [1.0,1.0]
--    raices 1 0 1    ==  []
-- ---------------------------------------------------------------------

-- Pensar bien el enunciado

{-
raices :: Int -> Int -> Int -> [FLoat]
raices x y z
    | numeroDeRaices1 x y z == 1 = d
    | numeroDeRaices1 x y z == 2 = [d,-d]
    where d = sqrt $ y^2 - 4*x*z
-}
-- ---------------------------------------------------------------------
-- Ejercicio 9.2. Definir el operador (x ~= y) que verifica si x e y son 
-- "casi iguales"; es decir si el valor absoluto de su diferencia es 
-- menor que una milÃ©sima. EL tipado de la funciÃ³n debe ser lo mÃ¡s genÃ©rico
-- posible. Por ejemplo, 
--    12.3457 ~= 12.3459  ==  True
--    12.3457 ~= 12.3479  ==  False
-- ---------------------------------------------------------------------
(~=) :: (Ord a, Fractional a) => a -> a -> Bool
--Si nos piden un tipado genérico podemos usar el que nos devuelve haskell al hacer :t (~=)
(~=) x y = abs (x-y) < 0.001

infix 4 ~= 
--infixr/l [1..9] Indicamos por donde hay que asociar y la prioridad

-- ---------------------------------------------------------------------
-- Ejercicio 10. En geometrÃ­a, la fÃ³rmula de HerÃ³n, descubierta por
-- HerÃ³n de AlejandrÃ­a, dice que el Ã¡rea de un triÃ¡ngulo cuyo lados
-- miden a, b y c es la raÃ­z cuadrada de s(s-a)(s-b)(s-c) donde s es el
-- semiperÃ­metro s = (a+b+c)/2
-- 
-- Definir la funciÃ³n (area a b c) que calcule el Ã¡rea del triÃ¡ngulo de 
-- lados a, b y c. Por ejemplo, 
--    area 3 4 5  ==  6.0
--    area 5 5 8  ==  12.0
--    area 5 5 11  *** Exception: El triÃ¡ngulo indicado no existe
-- ---------------------------------------------------------------------

area = undefined
        
-- ---------------------------------------------------------------------
-- Ejercicio 11.1. Los intervalos cerrados se pueden representar mediante
-- una lista de dos nÃºmeros (el primero es el extremo inferior del
-- intervalo y el segundo el superior). 
-- 
-- Definir la funciÃ³n (interseccion i1 i2) que calcule la intersecciÃ³n de 
-- los intervalos enteros cortos i1 e i2. Por ejemplo,
--    interseccion [] [3,5]     ==  []
--    interseccion [3,5] []     ==  []
--    interseccion [2,4] [6,9]  ==  []
--    interseccion [2,6] [6,9]  ==  [6,6]
--    interseccion [2,6] [0,9]  ==  [2,6]
--    interseccion [2,6] [0,4]  ==  [2,4]
--    interseccion [4,6] [0,4]  ==  [4,4]
--    interseccion [5,6] [0,4]  ==  []
-- ---------------------------------------------------------------------

interseccion = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 11.2. Comprobar con QuickCheck que la intersecciÃ³n de
-- intervalos es conmutativa.
-- ---------------------------------------------------------------------

-- La propiedad es
prop_interseccion = undefined

-- La comprobaciÃ³n es
-- la suma de dos lados de un triangulo deben ser mayor que la del otro restante

-- ---------------------------------------------------------------------
-- Ejercicio 12.1. Los nÃºmeros racionales pueden representarse mediante
-- pares de nÃºmeros enteros. Por ejemplo, el nÃºmero 2/5 puede
-- representarse mediante el par (2,5). 
-- 
-- Definir la funciÃ³n (formaReducida x) que calcule la forma reducida 
-- del nÃºmero racional x representado de la forma comentada. Por ejemplo, 
--    formaReducida (4,10)  ==  (2,5)
--    formaReducida (0,10)  ==  (0,1)
--    formaReducida (4,0)    *** Exception: No existe ese nÃºmero

-- gcd a b da el máximo común divisor
-- lcm a b da el mínimo común divisor
-- ---------------------------------------------------------------------
formaReducida :: (Int,Int) -> (Int, Int)
formaReducida (x,y)
    | x == 0 = (0,1)
    | y == 0 = error "No existe ese número"
    | otherwise = (div x d, div y d)
    where d = gcd x y

formaReducida' :: (Int, Int) -> (Int, Int)
formaReducida' (_, 0) = error "No existe ese número"  -- El denominador no puede ser 0
formaReducida' (0,_) = (0, 1)  -- Si el numerador es 0, la forma reducida es (0, 1)
formaReducida' (x, y) = (x div d, y div d) --O (div a d, div b d)
    where d = gcd x y  -- Calculamos el máximo común divisor (MCD)


-- ---------------------------------------------------------------------
-- Ejercicio 12.2. Definir la funciÃ³n (sumaRacional x y) que calcule
-- la suma de los nÃºmeros racionales x e y, expresada en forma reducida. 
-- Por ejemplo, 
--    sumaRacional (2,3) (5,6)  ==  (3,2)
--    sumaRacional (3,5) (-3,5) ==  (0,1)
-- ---------------------------------------------------------------------
 
sumaRacional:: (Int, Int) -> (Int,Int) -> (Int)
sumaRacional (x1,y1) (x2,y2) = 
    formaReducida ((x1*y2 + x2*y1) / (y1*y2))

-- ---------------------------------------------------------------------
-- Ejercicio 12.3. Definir la funciÃ³n (productoRacional x y) es el 
-- producto de los nÃºmeros racionales x e y, expresada en forma reducida. 
-- Por ejemplo, 
--    productoRacional (2,3)  (5,6) ==  (5,9)
--    productoRacional (2,3)  (0,3) ==  (0,1)
--    productoRacional (-2,3) (1,2) ==  (-1,3)
-- ---------------------------------------------------------------------
 
productoRacional = undefined
 
-- ---------------------------------------------------------------------
-- Ejercicio 12.4. Definir la funciÃ³n (igualdadRacional x y) que verifica 
-- si los nÃºmeros racionales x e y son iguales. Por ejemplo, 
--    igualdadRacional (6,9) (10,15)  ==  True
--    igualdadRacional (6,9) (11,15)  ==  False
--    igualdadRacional (0,2) (0,-5)   ==  True
-- ---------------------------------------------------------------------
 
igualdadRacional = undefined
    
-- ---------------------------------------------------------------------
-- Ejercicio 12.5. Comprobar con QuickCheck la propiedad distributiva
-- del producto racional respecto de la suma.
-- ---------------------------------------------------------------------

-- La propiedad es
prop_distributiva = undefined

-- La comprobaciÃ³n es

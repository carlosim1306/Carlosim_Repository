{-

Definir un tipo de dato == Definir un sinónimo de un tipo de dato

Definimos un sinónimo para una tupla de dos valores de cualquier tipo
type Punto2Dgenerico a = (a,a)

De esta manera marcaríamos que Punto2D es un Punto2Dgenerico de tipo float
type Punto2D = Punto2Dgenerico Float



-}
import Data.List (sort)
import Data.Char (toUpper)
import Text.Printf

ejSecuenciacion :: IO (Char,Char)
ejSecuenciacion = do
    x <- getChar
    getChar
    y <- getChar
    return (x,y)

ejSecuenciacionLinea :: IO String
ejSecuenciacionLinea = do
    xs <- getLine
    return xs

{-
Al ejecutar ejSecuenciacion

ejSecuenciacion
a
b
('a','b')

ejSecuenciacion
a b
('a','b')

ejSecuenciacion
a bc d
('a','b')
ejSecuenciacion
('c','d')

El espacio o salto de línea cuenta como un getChar, además se acumulan los datos que no se usen para la siguiente llamada de la función

ejSecuenciacionLinea
Hola Mundo  
"Hola Mundo"

Rellena el buffer con la línea completa

-}

--Devolver una los valores de una lista de carácteres ordenados alfabéticamente

ordenaCadenas :: [String] -> IO ()
ordenaCadenas xs = sequence_ (map putStrLn (sort xs))

-- map lo que hace es pasarle el putStrLn a cada cadena de la lista, en este caso lo que hace es realizar un put con cada valor

aMayusculas :: FilePath -> FilePath -> IO ()
aMayusculas f1 f2 = do
    cs <- readFile f1
    writeFile f2 (map toUpper cs)

-- Si el segundo fichero ya existe se sobreescribe, pero no se puede sobreescribir el fichero de entrada (Un fichero que se está leyendo)

ordenaFichero :: FilePath -> FilePath -> IO ()
ordenaFichero f1 f2 = do
    cs <- readFile f1
    writeFile f2 (unlines (sort(lines cs)))
--  writeFile f2 ((unlines . sort. lines) cs)

-----------------------------------------------------------------------------------------------------------------------------------

tablaCuadrados :: FilePath -> Int -> IO ()
tablaCuadrados f n =
    writeFile f (listaDeCuadrados n)

listaDeCuadrados :: Int -> String
listaDeCuadrados n =
    unwords (map show [(x,x*x) | x <- [1..n]])

-----------------------------------------------------------------------------------------------------------------------------------

tablaLogaritmos :: FilePath -> [Int] -> IO ()
tablaLogaritmos f ns = do
    writeFile f (tablaLogaritmosAux ns)

tablaLogaritmosAux :: [Int] -> String
tablaLogaritmosAux ns =
    linea ++ 
    cabecera ++ 
    linea ++ 
    concat [printf "| %2d | %.12f |\n" n x
                | n <- ns, let x = log (fromIntegral n) :: Double]
    ++ linea

linea, cabecera :: String
linea = "+----+----------------+\n"
cabecera = "| n  | log(n)         |\n"
import System.IO
-- Para lanzar el programa completo a partir de un main lo llamamos por consola como runhaskell.exe .\hola.hs

{-
main = do 
    putStr "Who are you? "
    hFlush stdout
    name <- getLine
    putStrLn ("Hello, " ++ name)

De esta manera forzamos la salida del buffer putStrLn
-}

main = do
    hSetBuffering stdout NoBuffering
    putStr "Who are you?"
    name <- getLine
    putStrLn ("Hello, " ++ name)

-- Si no se limpia el buffer con ninguna de las dos maneras haría la pregunta después de introducir el String

-- con hSetBuffering stdout NoBuffering desactivas el buffering de salida, es el que se suele usar
-- PD-Practica 1
-- Definiciones de funciones, tipos y clases.
-- Departamento de Ciencias de la Computación e I.A.
-- Universidad de Sevilla
-- =====================================================================

-- A continuación se importa el módulo QuickCheck. Necesita ser instalado
-- previamente con Cabal o Stack
import Test.QuickCheck

-- Pruebas clase 16/09

clasifica :: Integer -> String
clasifica n =
    if (n>100)
        then "muchos"
        else "pocos"

--sumaEntero :: Integer a => a -> a
sumaEntero :: Integer -> Integer
sumaEntero x = x + x       

--sumaEnteroChar :: Integer a => a -> Char -> a
sumaEnteroChar :: Integer -> Char -> Integer
sumaEnteroChar x letra = x + x       

-- :t funcion te devuelve el tipado de los valores de la función

-- ---------------------------------------------------------------------
-- Ejercicio 1. Evalúa las siguientes líneas para entender cómo funciona
-- el sistema de tipos que proporciona Haskell.
-- ---------------------------------------------------------------------

--

-- ¡Importante! Probar los tipados para entender que valores toma de entrada y cual es la salida

--

-- :type True
-- True :: Bool
-- :t True
-- 1 :: Num p => p
-- :t 1
-- 1.1 :: Fractional p => p
-- :t 1.1
-- 'a' :: Char
-- :t 'a'
-- "a" :: [Char]
-- :t "a"
-- [1,2] :: Num a => [a]
-- :t [1,2]
-- [1,2.1] :: Fractional a => [a]
-- :t [1,2.1]
-- error al ser elementos de distinto tipo
-- :t [1,'a']
-- (1,'a') :: Num a => (a, Char)
-- :t (1,'s')
-- (1,2.1) :: (Fractional b, Num a) => (a, b)
-- :t (1,2.1)
-- [[1],[1,2]] :: Num a => [[a]]
-- :t [[1],[1,2]] 
-- not :: Bool -> Bool
-- :t not
-- sum :: (Foldable t, Num a) => t a -> a
-- :t sum
-- sum :: (Foldable t, Num a) => t a -> a
-- :t (+)
-- [] :: [a]
-- :t []
-- () :: ()
-- :t ()
-- (3+) :: Num a => a -> a
-- :t (3+)
-- length :: Foldable t => t a -> Int
-- :t length
-- zip :: [a] -> [b] -> [(a, b)]
-- :t zip
-- take :: Int -> [a] -> [a]
-- :t take

-- ---------------------------------------------------------------------
-- Ejercicio 2. Sin evaluar las expresiones en GHC, decide qué tipo es  
-- el adecuado para cada una de ellas. Intenta dar el tipo más general.
-- ---------------------------------------------------------------------

i1:: Integer  -- El primero va de regalo
i1 = 45

i2 :: [Char]
-- i2 :: String
i2 = "123"

i3 :: Bool
i3 = 45 <= i1

i4 :: Char
i4 = 'c'

i5 :: [[Char]] -- ó [String]
i5 = ["abc","ok"]

i6 :: [Char]
i6 = head i5

i7 :: [Char]
i7 = tail "abc"

i8 :: (Bool, Float)
i8 = (True,4.5)

i9 :: [Integer]
i9 = [i1,34]

i11 :: Integer -> Int 
i11 x = length [1..x]

-- ---------------------------------------------------------------------
-- Ejercicio 3. Para cada una de las siguientes expresiones, reemplaza
-- undefined por una expresión válida para el tipo que la declara.
-- ---------------------------------------------------------------------

j1:: (String,Integer)
j1 = ("", 7)

j2:: [Double]
j2 = [1,1.25..10]

j3:: Char
j3 = 'c'

j4:: Double
j4 = 8.3
-- j4 = pi

j5:: (Integer,String,Integer,Char)
j5 = (9,"",3,'s')

j6:: ([Char],(Bool,String))
j6 = (['c','d'],(True,"Prueba"))
-- j6 = ("Prueba",(True,"Prueba"))


j7:: [[Bool]]
j7 = [[True,False,True],[True],[False]]

j8:: [(String,Bool)]
j8 = [("", True),("Prueba",False)]

j9:: Integer -> Integer
-- j9 n = 2* n
j9 = (2*)
-- Se pueden eliminar elementos y haskell los colocará a la izquierda de lo siguiente al igual, importante ponerlo entre paréntesis

j10:: Float -> [Bool] -> Bool
--j10 a b = True
j10 head x = True
--j10 head x = head [True,False]

-- En este caso la variable ganaría a la función reservada por lo que fallaría
-- Funcionaría porque tomaría head en vez de una función como el nombre de una variable ¡Evitar usar nombres de funciones como variables!

-- Para comprobar el tipado del siguiente valor que tienes que meter cuando ya has puesto un argumento puedes hacer t: j10 0.2 
-- y devolvería j10 0.2 ::[Bool] -> Bool

j11:: [Char] -> [[Int]]
j11 xs = [[1..10], [1..3]]


-- ---------------------------------------------------------------------
-- Ejercicio 4. Conocemos el cambio actual del euro a dólares estadounidenses: 1
-- Euro son 1.17507 dólares

--   - Definir la constante tipoCambio con dicho valor.
--   - Calcular la expresiones para el cambio a dólares de distintas cantidades 
--     de euros y viceversa
-- ---------------------------------------------------------------------

tipoCambio:: Double
tipoCambio = 1.17507

aEuros:: Double -> Double
aEuros = (/tipoCambio)
--aEuros x = x / tipoCambio

aDolares:: Double -> Double
aDolares = (tipoCambio*)
--aDolares x = tipoCambio*x

--Último cálculo en en la términal se puede llamar como it

-- ¡Importante si parcializas! Si la propiedad varía según dónde se coloque la puedes poner izq/der, sino siempre derecha

-- ---------------------------------------------------------------------
-- Ejercicio 5. Definir dos funciones, aEuros y aDolares, que dada una cantidad de
-- dólares (resp. euros) permita obtener la cantidad de euros (resp.
-- dólares) equivalente. Volver a calcular los cambios anteriores utilizando las 
-- funciones definidas.

-- Nota: No es necesario redondear el resultado.
-- ---------------------------------------------------------------------

-- Hecho en el apartado anterior

-- ---------------------------------------------------------------------
-- Ejercicio 6. Escribir la siguiente propiedad: dada cualquier cantidad de euros,
-- si la cambiamos a dólares y los dólares obtenidos los volvemos a
-- cambiar a euros, obtenemos la cantidad de euros original.

-- Nota: una propiedad de es función que devuelve un booleano y su cuerpo
--       define una expresión para comprbar una propiedad.
-- ---------------------------------------------------------------------

propiedad_cambio :: Double -> Bool
propiedad_cambio x = (aEuros . aDolares) x == x
-- f(g(x)) = f o g (x) ejecuta primero aEuros y luego aDolares

-- ---------------------------------------------------------------------
-- Ejercicio 7. Si la propiedad anterior ha fallado analiza el posible problema y
-- busca una solución al mismo.
-- ---------------------------------------------------------------------

propiedad_cambio1 :: Double -> Bool
propiedad_cambio1 x = ((aEuros . aDolares) x - x) < 0.1

--quickCheck propiedad para comprobar que se cumple la propiedad

-- ---------------------------------------------------------------------
-- Ejercicio 8. Definir una función que determinar si una cadena de 
-- caracteres es palíndromo.
--
--
-- $ es_palindromo "anilina"
-- True
-- $ es_palindromo "dábale arroz a la zorra el abad"
-- True
-- $ es_palindromo []
-- False
-- $ es_palindromo "hola"
-- False

-- Nota: consideramos que la cadena vacía no es palíndromo.
-- ---------------------------------------------------------------------
mitad :: [a] -> Int
mitad xs = (length xs) `div` 2
-- mitad xs = div (length xs) 2
-- Al poner `div` puedes usar la función como un operador y colocarlo dónde quieras

es_palindromo :: String -> Bool
es_palindromo [] = False
es_palindromo xs = 
    take len xs == take len(reverse xs)
    where len = mitad xs

-- ---------------------------------------------------------------------
-- Ejercicio 9. Crear una función que genere la letra de DNI. 
--    Para calcular la letra del DNI o caracter de verificación solo debes 
--    de realizar los siguientes pasos:

--    1. Dividir la parte numérica del DNI entre el número 23.
--    2. Tomamos el resto de dicha división y buscamos la lista de 
--       letras
-- ---------------------------------------------------------------------

letrasDNI = "TRWAGMYFPDXBBJZSQVHLCKE"

letraDNI:: Int -> Char
--letraDNI n = letrasDNI !! (mod n 23)
letraDNI n = letrasDNI !! (n `mod` 23)
-- !! permite hacer un get a una lista en la posición que pongamos

-- ---------------------------------------------------------------------
-- Ejercicio 10.  Conocemos que 0ºC se corresponden con 32ªF y que un incremento de
-- 5ºC suponen un incremento de 9ºF.

-- Definir una función que permita pasar de ºC a ºF (y otra para el
-- cambio contrario).

-- Si para mañana está prevista un mínimo de 19ºC y un máximo de
-- 34ºC, ¿cuál sería el rango expresado en ºF?
-- ---------------------------------------------------------------------

c2f = undefined


f2c = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 11. Una tienda vende las mallas de 2kg de patatas a 2.70 euros. Para 
--  favorecer la venta de cantidades mayores ofrece un precio reducido
--  de 2.20 euros a partir de la quinta malla. Es decir, si un cliente
--  compra 18 mallas, las cinco primeras las cobra a 2.70 y las 13
--  restantes a 2.20.

--  * Definir una función que, dada la cantidad de mallas calcule el
--    precio sin tener en cuenta la promoción. Calcular el precio del
--    ejemplo proporcionado.

--  * Definir una función que, dada la cantidad de mallas, calcular el
--    precio correspondiente según la promoción. Usar dicha función
--    para calcular, de nuevo, el precio del ejemplo.

--  La oferta ha tenido tanto éxito que el vendedor decide ampliarla
--  reduciendo el precio a 2 euros a partir de la décima malla.

--  * Definir una función para la nueva promoción y volver al calcular
--    el precio del ejemplo.
-- ---------------------------------------------------------------------



-- ---------------------------------------------------------------------
-- Ejercicio 12. Consideremos el siguiente juego: Dado un número mayor que 1, si es
--  par divídelo entre 2 y si es impar multiplícalo por 3 y súmale 1.
--  Si el resultado es 1 ya has terminado, en caso contrario repite el
--  procedimiento sobre el resultado.

--  Pregunta: Dado un número inicial cualquiera, cuántas veces tendrás
--  que aplicar el procedimiento.

--  Ejemplos:

--  Si empezamos por 10 => dividimos por 2 y obtenemos 5 =>
--  multiplicamos por 3 y sumamos 1, obteniendo 16 => toca volver a
--  dividir y obtenemos 8 => repetimos y obtenemos 4 => seguimos y
--  obtenemos 2 => alcanzamos el 1.

--  los valores han sido 5, 16, 8, 4, 2, 1: lo hemos aplicado 6 veces

--  Si empezamos por 7 los valores serán 22, 11, 34, 17, 52, 26, 13, 40, 20, 10, 5,
--  16, 8, 4, 2, 1: lo hemos aplicado 16 veces.


--  * Definir una función que aplique una vez el procedimiento
--    anterior. Utilizarla sucesivamente para verificar que los
--    resultados proporcionados a partir de 10 y de 7 son correctos.

--    Nota: Pueden ser de utilidad las funciones even y div

--  * Definir una función que dado un número natural mayor que uno
--    calcule el número de veces que se repite el resultado.

--  * Definir una función que devuelva la lista de resultados hasta
--    llegar  a 1.
-- ---------------------------------------------------------------------

siguiente:: Integer -> Integer
siguiente n = 
    if even n
        then div n 2
    else 3*n +1

resultado:: Integer -> [Integer]
resultado 1 = [1]
resultado n = n: (resultado(siguiente n))

-- n: añade elementos por la izquierda

-- ---------------------------------------------------------------------
-- Ejercicio 13. Defina la función 'al_ultimo' que toma una lista y
-- envía a su primer elemento al final de la lista.
--
-- 
-- > al_ultimo [1..3]
-- [2,3,1]
-- > al_ultimo []
-- []
--
-- ---------------------------------------------------------------------

al_ultimo = undefined


-- ---------------------------------------------------------------------
-- Ejercicio 14. Defina la función 'el_del_medio' que toma una lista y
-- devuelve el elemento central. Si el número de elementos N es par, debe
-- devolver el elemento N/2. 
--
-- 
-- > el_del_medio [1..3]
-- 2
-- > el_del_medio []
-- *** Exception: Prelude.!!: index too large
-- > el_del_medio [1..4]
-- 3
--
-- ---------------------------------------------------------------------  

--el_del_medio = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 14. Defina la función 'el_del_medio' que toma una lista y
-- devuelve el elemento central. Si el número de elementos N es par, debe
-- devolver el elemento N/2. 
--
-- 
-- > el_del_medio [1..3]
-- 2
-- > el_del_medio []
-- *** Exception: Prelude.!!: index too large
-- > el_del_medio [1..4]
-- 3
--
-- ---------------------------------------------------------------------  

el_del_medio = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 15. Defina la función 'particiona' que toma una lista y 
-- una posición y devuelve una listas con dos listas en su interior 
-- con la particion de la lista original por la posición dada.
--
-- 
-- > particiona [1..10] 3
-- [[1,2,3],[4,5,6,7,8,9,10]]
--
-- > particiona [1..10] 0
-- [[],[1,2,3,4,5,6,7,8,9,10]]
--
-- > > particiona [1..10] 20
-- [[1,2,3,4,5,6,7,8,9,10],[]]

-- ---------------------------------------------------------------------  

particiona = undefined

-- ---------------------------------------------------------------------
-- Ejercicio 16. Define la función 'inserta' que añade un nuevo elemento
-- a una lista dada en una posición indicada.
--
-- 
-- > inserta 20 [1..10] 3
-- [1,2,3,20,4,5,6,7,8,9,10]
-- 
-- > inserta 20 [1..10] 20
-- [1,2,3,4,5,6,7,8,9,10,20]
-- 
-- > inserta 20 [1..10] 0
-- [20,1,2,3,4,5,6,7,8,9,10]
-- 
-- --------------------------------------------------------------------- 

inserta = undefined 


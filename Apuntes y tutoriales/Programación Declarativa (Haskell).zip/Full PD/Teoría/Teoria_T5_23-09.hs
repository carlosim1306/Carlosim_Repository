-- Cómo se lee una lista por comprensión

-- [2 * x | x <- [1..10]]
-- Antes de la guarda '|' colocamos la función que queremos expresar en la lista, en este caso, el cuadrado de la variable 'x'
-- Tras la guarda colocamos el nombre de la variable, en este caso, la variable se llama 'x'
-- Tras la variable colocamos los valores que recorrerá la variable de este modo '<- [1..10]'

pos_pares :: [Int] -> [Int]
pos_pares xs = [2*x | (x,i) <- zip xs [0..], even i]

-- Esta función devuelve una lista de los elementos de xs en posición par 'i' multiplicados por 2
-- El zip nos ayuda a la hora de enumerar los índices de las listas

-- [(x,y) | x <- [1,2,3], y <- [4,5]]
-- Se pueden usar varios generadores, dando prioridad siempre al valor de la izquierda, es decir, primero fija los valores de 'x' y 
-- recorre los de 'y', con el ejemplo anterior tendríamos como resultado: [(1,4),(1,5),(2,4),(2,5),(3,4),(3,5)]

pos_pares_mul_3 :: [Int] -> [Int]
pos_pares_mul_3 xs = [2*x | (x,i) <- zip xs [0..], even i, mod x 3 == 0]

-- Las comas tras las guardas funcionan como un &&
-- Por ejemplo en este caso primero evalúa si el índice es par y tras eso comprueba que el valor de x es múltiplo de 3 y después lo
-- almacena en la lista resultante multiplicándola x*2
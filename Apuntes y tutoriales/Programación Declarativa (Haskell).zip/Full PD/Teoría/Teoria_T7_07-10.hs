dosVeces :: (a -> a) -> a -> a
-- (a->a) Nos dice que el primer argumento es una función que recibe un argumento de tipo a y devuelve un argumento de tipo a
dosVeces f x = f (f x)

divide:: Fractional a => a -> (a -> a)
-- Fractional a Implica que el valor de a deberá de ser Fractional
divide x = (/x)

divide':: Fractional a => a -> a -> a
-- Es lo mismo que divide, ya que haskell pone paréntesis a la derecha de forma automática
divide' x y = y / x

--Funciones chetadas

{-

- map f xs : Devuelve la lista resultante de aplicarle f a cada elemento de la lista xs
   ej. map (*2) [1..5]

- filter p xs : Devuelve la lista resultante de aplicar el filtro p a cada elemento de la lista
   ej. filter even [1..10]

- all p xs : Verifica que todos los elementos de xs cumplen la propiedad p

- any p xs : Verifica que alguno de los elementos de xs cumplen la propiedad p

- takeWhile p xs : Devuelve los elementos iniciales de xs que verifiquen p, si el primer elemento no verifica devuelve una lista vacía

- dropWhile p xs : Devuelve xs sin los elementos iniciales que verifiquen p, si el primer elemento no lo cumple devuelve la lista inicial
   Una idea chetada es que si queremos el primer elemento que cumpla una propiedad, hagamos dropWhile con el contrario de la propiedad p
   
   -IMPORTANTE-

- funciones anónimas o Lambda:
      - No tienen etiqueta
      - Un solo uso
      - Un solo patrón

- (Plegado) : las recursiones sobre listas son tan comunes que tienen funciones de resumen

      - (Plegado a derecha)
         foldr f v [] = v
         foldr f v (x:xs) = f x (foldr f v xs)

         En primer lugar representamos el caso base, en este caso la lista vacía y lo que debe devolver
         
         Ejemplo:

            inversa [] = []
            inversa (x:xs) = (inversa xs) ++ [x]

            inversafr xs = foldr f [] xs
               where f x rec = rec ++ [xs]
            
         Ejemplo 2:

            foldr (+) 0 [1..10]

            La función a ejecutar sobre los elementos es la suma, el caso base es que la suma sea 0 y los valores de la lista van de 1 a 10

            foldr (/) 1 [1..3]

            Este ejemplo es interesante porque nos demuestra que la función recursiva se hace de derecha a izquierda,
            es decir, los elementos se toman de izquierda a derecha, pero las operaciones se hacen de izquierda a derecha
     
      - (Plegado a izquierda) #Como recursión con acumulador
         
         foldl f ac [] = ac
         foldl f ac (x:xs) = foldl f (f ac x) xs

            Ejemplo:

               inversaRa xs = inversa_aux [] xs

               inversa_aux ac [] = ac
               inversa_aux ac (x:xs) = inversa_aux(x:ac) xs

            inversaPl xs = foldl f [] xs
               where f ac x = x:ac
   
   scanr (+) 5 [1..4]
   Nos mostraría los pasos de los cálculos empezando por el caso base y pasándole la función recursivamente
   [15,14,12,9,5]

-}

sumaCuadradosPares:: (Num a) => [a] -> a
sumaCuadradosPares xs =
   sum (map (^2) (filter even xs))
-- Esta función primero realiza un filtro con even en el cual reduce xs a la lista de los números pares de xs, tras esto eleva al
-- cuadrado los elementos resultantes del filtro y tras eso los suma

resto3:: Fractional a => [a] -> [a]
resto3 xs = map f xs
   where f x = x `mod` 3

resto3':: Fractional a => [a] -> [a]
resto3' xs = map (\x -> x `mod` 3) xs

{-
Ejercicios de examen de esta parte

-}
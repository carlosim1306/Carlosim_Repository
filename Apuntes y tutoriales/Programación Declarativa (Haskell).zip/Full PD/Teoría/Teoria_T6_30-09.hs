{-
Manual en haskell: 
Tipado de la funcion
Enumerar los casos
Define los casos base
Generalizar y simplificar

Ejemplo: la funcion factorial

(El tipado es lo primero, pero en la pizarra lo omitiré)
   {1 n=0.1
n!={n * (n1)! c.c

fact :: Integer -> Integer 
fact 0 = 1 --caso base
fact 1 = 1 --caso redundante
fact n = n fact (n-1) --llamada recursiva

traza del fact 3 = 3 * fact(3-1)
                   3 * fact(2)
                   3 * (2 * fact(2-1))
                   3 * (2 * (1 * fact (0)))
                   3 * 2 * 1 * 1 = 6

Recursion numerica: el n-esimo valor de la sucesion de fibonacci. 
       {1  n=0,1
f(n) = {f(n-1) + f(n-2) c.c

-}

fib :: Integer -> Integer 
fib 0 = 1 
fib 1 = 1 
fib n = fib (n-1) + fib (n-2) 

{-

Recursion es una herramienta muy potente pero puede llegar a ser muy ineficiente --> Programacion dinamica 

Recursion sobre listas: 

Sumar elementos de una lista. 

-}

suma :: Num a => [a] -> a
suma [] = 0 
--suma [x] = x --caso redundante
suma (x:xs) = x + suma xs 
--patron de lista con al menos 1 elemento

{-
suma (x:y:xs) = suma((x+y):xs)
La idea de usar esta recursión es que se haga la suma antes de hacer la llamada recursiva, de esta manera el último valor de la
función sería el valor final, no habría que ir recorriendo las funciones hacia atras para obtener los valores
No se suele hacer, ya que la mejora con respecto a la recursión normal es mínima
-}

--Recursión con acumulador

{-
1º Definir el tipado de la función
2º Llamo a una función auxiliar que contendrá el acumulador(argumento extra)
Evaluar con un caso inicial de acumulador, no tiene por qué ser el caso base
3º Definir la función auxiliar de manera recursiva, esta devolverá el valor del acumulador 
   a la función inicial cuando llegue al caso base.
-}

sumaRA :: Num a => [a] -> a
sumaRA xs = sumaAC 0 xs

sumaAC :: Num a => a -> [a] -> a
sumaAC ac [] = ac
sumaAC ac (x:xs) = sumaAC (ac+x) xs
--Como buscamos el sumatorio de la lista lo que hacemos, iniciamoas el acumulador a 0 y vamos llamando a la función del acumulador
--de forma recursiva sumando el acumulador y el primer valor de la lista

--Calcular la inversa de una lista con acumulador

inversaRA :: [a] -> [a]
inversaRA xs = inversaAC [] xs

inversaAC:: [a] -> [a] -> [a]
inversaAC ac [] = ac
--inversaAC ac (x:xs) = (inversaAC ac xs) ++ [x]
--Esta forma da bien los cálculos pero seguiría siendo una recursión normal, ya que necesita que se haga toda la recursión, el acumula
--dor estaría vacío hasta la final
inversaAC ac (x:xs) = inversaAC (x:ac) xs

inversaR :: [a] -> [a]
inversaR [] = []
inversaR [x] = [x]
inversaR (x:xs)= (inversaR xs) ++ [x]

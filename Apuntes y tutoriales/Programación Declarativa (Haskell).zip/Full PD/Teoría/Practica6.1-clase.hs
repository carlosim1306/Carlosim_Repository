-- PD-PrÃ¡ctica 6.1 
-- Tipos: Definiciones bÃ¡sicas de tipos de datos algebrÃ¡icos
-- Departamento de Ciencias de la ComputaciÃ³n e I.A.
-- Universidad de Sevilla
-- =====================================================================

-- Ejemplo de clase

-- Definir el tipo de una figura que pueda ser el círculo con su radio o un rectángulo con sus dos lados

data Figura = 
    Circulo Float   | Rect Float Float
    deriving (Show)

instance Eq Figura where
    Circulo x == Circulo y = x == y
    Rect x1 y1 == Rect x2 y2 = (x1 == x2) && (y1 == y2) || (x1 == y2) && (y1 == x2)
    _ == _ = error "No se puede comparar un círculo y un rectángulo"

instance Ord Figura where
    Circulo x < Circulo y = x < y
    Rect x1 y1 < Rect x2 y2 = x1*y1 < x2* y2
    _ <= _ = error "No se puede comparar un círculo y un rectángulo"


-- En deriving podemos utilizar todas las clases de los tipos que formen el data

c1 = Circulo 0.2
r1 = Rect 0.15 2.5

-- Definir un data recursivo
data Lista a = 
    Nil | Cons a (Lista a)
    deriving (Show)


l1:: Lista Int
l1 = Cons 1 (Cons 2(Cons 3 Nil))

-- Definir un árbol binario
data Arbol a =
    H a | N a (Arbol a) (Arbol a)

-- ---------------------------------------------------------------------
-- Ejercicio 1. Haciendo uso de la decraraciÃ³n de tipos (type) define un
-- tipo nuevo, Punto2D, para los Puntos del Plano (de 2 dimensiones).
-- ---------------------------------------------------------------------

type Punto2Dgenerico a = (a,a)

-- type Punto2D = (Float, Float)
type Punto2D = Punto2Dgenerico Float

-- Movimiento, dado un punto inicial devuelve un punto
type Movimiento = Punto2D -> Punto2D

p1:: Punto2D
p1 = (0,0)
-- ---------------------------------------------------------------------
-- Ejercicio 2. Usando el tipo Punto2D, define un vector delimitado por
-- un par de puntos, Vector2D.
-- ---------------------------------------------------------------------

type Vector2D = (Punto2D, Punto2D)

-- ---------------------------------------------------------------------
-- Ejercicio 3. Definir la funciÃ³n vector2Dcoor, que reciba un Vector2D
-- y devuelva un par que describa sus coordenadas. Si el vector estÃ¡
-- formado por los puntos p1 y p2, entonces el calculo del par se
-- calcula como sigue:
--   * la primera componente es la diferencia de la primera componente
--     de p2 menos del p1.
--   * la segunda componente es la diferencia de la segunda componente
--     de p2 menos del p1.
-- ---------------------------------------------------------------------

vector2Dcoor:: Vector2D -> Punto2D
vector2Dcoor ((x1,y1), (x2,y2)) = (x2-x1, y2-y1)

-- ---------------------------------------------------------------------
-- Ejercicio 4. Definir la funciÃ³n productoEscalar, tal que reciba dos
-- vectores Vector2D, y devuelva su producto escalar, calculado como
-- sigue: la suma de la multiplicaciÃ³n de las componentes de las
-- coordenadas de los vectores.
-- ---------------------------------------------------------------------

productoEscalar:: Vector2D -> Vector2D -> Float
productoEscalar v1 v2 = a1*a2 + b1*b2
    where (a1,b1) = vector2Dcoor v1
          (a2,b2) = vector2Dcoor v2

-- ---------------------------------------------------------------------
-- Ejercicio 5. Definir la funciÃ³n norma, tal que reciba un vector tipo
-- Vector2D y devuelva el mÃ³dulo del vector, definido como la raÃ­z
-- cuadrada del producto escalar del vector por sÃ­ mismo.
-- ---------------------------------------------------------------------


-- ---------------------------------------------------------------------
-- Ejercicio 6. Definir la funciÃ³n paralelos, que reciba dos vectores
-- tipo Vector2D y devuelva si los vectores son paralelos. El cÃ¡lculo
-- necesario para ello es comprobar que el valor absoluto del producto
-- escalar de los dos vectores dividido por la multiplicaciÃ³n de la
-- norma de cada uno, sea igual a 1.
-- ---------------------------------------------------------------------


-- ---------------------------------------------------------------------
-- Ejercicio 7. Define tipos de datos (data) para almacenar informaciÃ³n
-- sobre el calendario: dÃ­as de la semana, meses, y estaciones del aÃ±o.
-- ---------------------------------------------------------------------

data Dia = 
    Lunes | Martes | Miercoles | Jueves | Viernes | Sábado | Domingo

data Mes =
    Enero | Febrero | Marzo | Abril | Mayo | Junio | Julio | Agosto | Septiembre | Octubre | Noviembre | Diciembre

data Estacion =
    Invierno | Primavera | Verano | Otoño

ayer:: Dia -> Dia
ayer Lunes = Domingo
-- Habría que hacer una línea por cada día


-- ---------------------------------------------------------------------
-- Ejercicio 8. Haciendo uso del tipo Maybe, define una funciÃ³n de
-- divisiÃ³n segura (que al dividir por 0 no lance una excepciÃ³n).
-- ---------------------------------------------------------------------

divisionNoSegura:: Float -> Float -> Maybe Float
-- Maybe Float devuelve un Nothing si divides por 0, sino lanza el just
divisionNoSegura _ 0 = Nothing
divisionNoSegura x y = Just (x/y)

-- ---------------------------------------------------------------------
-- Ejercicio 9. Haciendo uso del tipo Maybe, define una funciÃ³n que
-- devuelva las raices de una ecuaciÃ³n de segundo grado.
-- ---------------------------------------------------------------------



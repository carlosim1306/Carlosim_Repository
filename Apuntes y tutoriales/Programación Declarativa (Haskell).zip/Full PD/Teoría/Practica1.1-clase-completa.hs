-- PD-Practica 1.1
-- Definiciones de funciones, tipos y clases.
-- Departamento de Ciencias de la Computación e I.A.
-- Universidad de Sevilla
-- =====================================================================
import Data.Char
import Data.List

-- Definir previamente los tipos de la funciones a desarrollar.


-- ---------------------------------------------------------------------
-- Ejercicio 1. Define una función (contiene cs e) que dada una cadena de
-- caracteres cs y un caracter c, verifica si c pertenece a cs. Por ejemplo:
--
-- contiene "Hola mundo" 'b' == False
-- contiene "Hola mundo" 'a' == True
-- contiene "Hola mundo" 'm' == True
-- contiene [] 'm'           == False
-- ---------------------------------------------------------------------

contiene :: String -> Char -> Bool
contiene [] _ = False
contiene (c:cs) e = c == e || contiene cs e


-- La función (flip) cambia el orden de los dos primeros argumentos de 
-- entrada de una función. Ojo: si tienes tres o más argumentos, sólo 
-- cambia los dos primeros de orden.

contiene' :: String -> Char -> Bool
contiene' = flip elem

-- ---------------------------------------------------------------------
-- Ejercicio 2. Define una función (indice a cs) que dada un caracter a y
-- una cadena de caracteres cs, devuelve el índice de a dentro de cs
-- (empezando por la posición 0). Por ejemplo:
--
-- indice 'b' "Hola mundo" == -1
-- indice 'a' "Hola mundo" == 3
-- indice 'u' "Hola mundo" == 6
-- ---------------------------------------------------------------------

indice :: Char -> String -> Maybe Int 
indice [] _ = -1
indice a cs = 
    if contiene cs a 
    then i
    else -1 
    where Just i = elemIndex a cs --Las funciones se pueden buscar en internet buscando dataChar list en haskell

--Recursion con ac

indice' :: Char -> String -> Int 
indice' a cs = indice_aux a cs 0
indice' :: Char -> String -> Int -> Int 
indice' [] _ ac = -1 --Puedes incluso poner ac como _ (valor anonimo)
indice_aux a (c:cs) ac = 
    if a == c 
    then ac 
    else indice_aux a cs (ac+1)

--Recursion 

indice'' :: Char -> String -> Int 
indice [] _ = -1 
indice'' a (c:cs) 
    | a == x = 0 
    | recu == -1 = -1 
    | otherwise = 1 + recu
    where recu = indice'' a cs 



-- ---------------------------------------------------------------------
-- Ejercicio 3. Definir (EliminaN xs n) que dada una lista xs y un entero n,
-- elimina el n-ésimo elemento de xs (emepezando desde la posición 1). 
-- Por ejemplo:
--
-- eliminaN [0,1,2,2,4,5] 1 == [1,2,2,4,5]
-- eliminaN [0,1,2,2,4,5] 3 == [0,1,2,4,5]
-- eliminaN [0,1,2,2,4,5] 7 == [0,1,2,2,4,5] 
-- ---------------------------------------------------------------------

eliminaN :: [a] -> Int -> [a]
eliminaN xs n = take (n-1) xs ++ drop n xs 

--Recursion
eliminaN' :: [a] -> Int -> [a]
eliminaN' [] _ = []
eliminaN' (x:xs) 1 = xs 
eliminaN' (x:xs) n = x: eliminaN' xs (n-1)


-- ---------------------------------------------------------------------
-- Ejercicio 4. Define funciones para determinar si un carácter es una 
-- letra mayúscula, es mínuscula o es un número. Por ejemplo:
--
-- esMayus 'A' == True
-- esMayus 'z' == False
-- esMinus 'A' == False
-- esMinus 'z' == True
-- esNum '3' == True 
-- esNum '?' == False
-- ---------------------------------------------------------------------

esMayus :: Char -> Bool
esMayus x = elem c ['A'..'Z'] 
--esMayus = contiene ['A'..'Z'] 

esMinus :: Char -> Bool
esMinus = contiene ['a'..'z']

esNum :: Char -> Bool
esNum = contiene ['0'..'9']

-- ---------------------------------------------------------------------
-- Ejercicio 5. Define una función (esLetraNum c) que dado un carácter, 
-- verifica si es una letra mayúscula, mínuscula o número. Por ejemplo:
--
-- esLetraNum 'C' == True
-- esLetraNum 'd' == True
-- esLetraNum '3' == True
-- esLetraNum '?' == False
--
-- ---------------------------------------------------------------------

esLetraNum :: a -> Bool
esLetraNum c = esMayus c || esMinus c || esNum c 

-- ---------------------------------------------------------------------
-- Ejercicio 6. Define una función (sumaConsecutiva n s xs) que dados dos
-- enteros n y s, y una lista xs, verifique si hay n elementos consecutivos 
-- de xs que sumen s.
--
-- sumaConsecutiva 3 5 [0,1,2,2,4,5,6,7] == True
-- sumaConsecutiva 2 5 [2,1,2,1,4,5,6,7] == True
-- sumaConsecutiva 6 5 [1,4,5,6,7]       == False
-- ---------------------------------------------------------------------

sumaConsecutiva :: Int -> Int -> [Int] -> Bool
sumaConsecutiva n s xs = 
    or [sum (take n (drop i xs)) == s | i <- length xs-n] 

sumaConsecutiva' :: Int -> Int -> [Int] -> Bool 
sumaConsecutiva' n s ys@(x:xs) = 
    if n > length ys 
    then False
    else s == sum (take n ys) || sumaConsecutiva' n s xs 

--Hay otra forma de hacerlo subido a ev: un if then else es lo mismo que un &&

-- ---------------------------------------------------------------------
-- Ejercicio 7. Definir la función (capital cs) que dada una cadena
-- de caracteres cs, devuelve la cadena en capital case:
--
-- capital "hola mundo"   == "Hola Mundo"
-- capital ""             == ""
-- capital "hola mundo ?" == "Hola Mundo ?"
-- ---------------------------------------------------------------------


capital = 



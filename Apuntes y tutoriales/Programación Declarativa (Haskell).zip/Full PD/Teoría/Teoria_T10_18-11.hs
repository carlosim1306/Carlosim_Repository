import Data.Array
import qualified Data.Matrix as M
import qualified Data.Vector as V
-- Importante que a la hora de importar la función Data.Matrix debe ser de forma cualificada para que no pise las funciones del Prelude

-- Índices

-- range(m,n) lista de valores entre m y n, pueden ser de cualquier tipo
-- importante se pueden generar los índices dando un rando de tuplas, por ejemplo para devolver los vectores de una matriz cuadrada
-- ej: range ((0,0),(3,3)) -> devolvería los vectores de una matriz cuadrada desde 0 a 3

-- index(m,n) i devuelve la posición de i en el rango
-- inRange(m,n) i devuelve si i pertenece al rango
-- rangeSize(m,n) número de elementos del rango

-- Array i e (Siendo i un índice y e los elementos que la componen)

-- array (m,n) irs : irs es una lista de tuplas tipo índice y valor
-- listArray (m,n) xs : xs son valores que se asociarán a los índices por orden
-- accumArray f ini (m,n) irs : f será la función que se aplique, ini el valor inicial o por defecto, (m,n) el rango de valores de la
--      matriz y irs la lista de tuplas de los valores a los que se le va a aplicar la función.
--      sirve para rellenar los valores de un array

m1 = array (1,4) [(1,10),(4,7),(2,9), (3,18)]
-- En primer lugar ponermos el rango de índices  y en segundo lugar una lista de tuplas en el que el primer valor es el índice y el 
-- segundo los elementos, importante si se quieren almacenar varios elementos se pone como un tipo lista o tupla

m2 = listArray ('a', 'd') [10..]
-- De esta manera se van rellenando los valores del primer índice al último con los valores de la lista
-- Si no hay valores para todos los índices fallará

m3 = accumArray (+) 0 (1,10) (zip [1..5] [10..])
-- Dejaría como valor inicial o por defecto 0 y le aplizaría al rango (1,10) la suma de los elementos por índice del zip,
-- es decir, a los índices del 1 al 5 se le sumará 10,11,12,13,14 y 15, los demás tendrán el valor por defecto

-- accumArray (+) 0 (1,10) (zip [1,1,1,1,1,1] [10..])
-- otro ejemplo para probar, en esta caso todo se acumularía en el índice a 1 y los demás índices se quedarían a 0

-- funciones de acceso

x1 = m1 ! 4

--xs = elem m1

ixs = assocs m1
-- Devuelve la lista de tuplas de índices y elementos

(nfil,ncol) = bounds m1
-- Devuelve el rango de índices

-- Funciones modificadoras

m5 = m1 // [(2,1000000),(3,-1)]
-- De esta manera sustituimos el un valor en un array

-- Dada una matriz de enteros en formato Array, haz ceros en la diagonal principal

type MatrizInt = Array (Int,Int) Integer

eliminaDiagonal :: MatrizInt -> MatrizInt
eliminaDiagonal a = a // [((i,i),0) | i <- [1.. min nfil ncol]]
    where (nfil,ncol) = snd (bounds a)

identidad :: Int -> M.Matrix Int
identidad n = M.matrix n n (\(i,j) -> if i == j then 1 else 0)

m6 = M.fromLists [[1,2],[1,2]]
m7 = M.fromList 2 2 [1,2,1,1]
-- Funciones para generar matrices usando listas o dimensiones y una lista que irá rellenando por orden

-- Definir una función que simule una función M.matrix pero con array

matrixA :: Int -> Int -> ((Int,Int) -> Integer) -> MatrizInt
matrixA m n f =
    array ((1,1),(m,n))
     [((i,j), f (i,j)) | i <- [1..m], j <- [1..n]]

-- En este cado los generadores pueden estar desordenados ya que damos las coordenadas (i,j)
-- matrixA 3 3 (\(i,j) -> if i == j then 1 else 0) generaría la matriz identidad

matrixA1 :: Int -> Int -> ((Int,Int) -> Integer) -> MatrizInt
matrixA1 m n f =
    listArray ((1,1),(m,n))
     [f (i,j) | i <- [1..m], j <- [1..n]]

-- En este cado los generadores deben estar ordenados ya que los valores de los índices se rellenarán por orden

-- Definir una función que construya una matriz dada una lista de listas

arrayFromList :: [[Integer]] -> MatrizInt
arrayFromList xss = listArray ((1,1),(m,n)) (concat xss)
     where
        m = length xss
        n = length (head xss)
-- Recordar que siempre que usemos listArray primero se pone los rangos y después una lista ordenada de cómo se va a rellenar
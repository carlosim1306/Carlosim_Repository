media :: Fractional a => [a] -> a
media xs = 
    if null xs
    then 0
    else resultado
    where 
        n = (fromIntegral (length xs))
        resultado = sum xs / n

media' :: Fractional a => [a] -> a
media' xs
    | null xs = 0
    | otherwise = sum xs / n
    where n = (fromIntegral (length xs))

-- Cuando hay un error en las guardas de paréntesis normalmente, te señala la fila posterior a la que contiene el error
-- Intentar usar siempre las guardas 

media'' :: Fractional a => [a] -> a
media'' xs =
    case xs of
        [] -> 0
        [x] -> x
        xs -> sum xs / n
    where n = (fromIntegral (length xs))

-- Con esta sintaxis podemos modelar cada caso, se suele usar para modelar casos de lista vacía, un elemento y lista general
-- El el caso de no listar todos los casos posibles dará error (por ejemplo, si eliminamos el caso de la lista vacía)

and' :: Bool -> Bool -> Bool
and' True True = True
and' x y = False
-- and' _ _ = False
-- La sintaxis anterior hace que dado cualquier valor evalua, sin la necesidad de saber los valores ni ejecutar las funciones pertinentes
-- Permite ahorrar tiempo

and'' :: Bool -> Bool -> Bool
and'' True x = x
and'' False _ = False

-- ¡Patrones básicos para listas!

--suma :: Num a => [a] -> a
--suma [] = 0 -- patrón lista vacía
--suma [x] = x -- patrón lista con solo un elemento
--suma [x,y] = x + y -- patrón lista con solo dos elementos
--suma (x:xs) = x + suma xs -- patrón lista con al menos un elemento, xs se añadiría a la derecha de ese elemento
--suma (x:y:xs) = x + y + suma xs -- patrón con al menos dos elementos
--suma (x:y:z:xs) = x+y+z+suma xs -- patrón con al menos tres elementos

-- Ejemplo para evaluación de tuplas
-- tercero :: (a, b, c, d) -> c
-- tercero (_,_,z,_) = z
-- Al usar _ solo tendrá en cuenta el tercer elemento de la tupla

-- Estas funcionalidades se pueden usar tanto en listas como en tuplas

-- Esto es un ejemplo de operadores

--(*&) :: Bool -> Bool -> Bool
--(*&) True True = True
--(*&) _ _ = False
--infixr 1 *&

-- infixr 1 *& Esto significa que este operador que hemos definido tendrá una prioridad de 1(más débil) sobre los otros operadores y
-- además de esto se va a asociar por la derecha

-- infixl indica que la asociatividad se realiza por la izquierda, es decir, a+b+c == ((a+b)+c)
-- infixr indica que la asociatividad se realiza por la derecha, es decir, a+b+c == (a+(b+c))

--Ejercicio de examen 100% va a ser transparencia 18-19 sobre definir una propiedad y comprobarla con el quickcheck
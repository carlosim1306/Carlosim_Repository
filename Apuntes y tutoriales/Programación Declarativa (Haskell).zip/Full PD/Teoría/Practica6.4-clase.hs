-- PD-PrÃ¡ctica 6.4
-- Ãrboles Trie
-- Departamento de Ciencias de la ComputaciÃ³n e I.A.
-- Universidad de Sevilla
-- =====================================================================

-- ---------------------------------------------------------------------
-- Un Ã¡rbol Trie es un Ã¡rbol que codifica un diccionario, es decir,
-- asociaciones de clave - valor. La peculiaridad de estos Ã¡rboles es que
-- los nodos internos codifican las claves de forma eficiente, ya que
-- los prefijos comunes a las claves solo aparecen una vez. En
-- concreto, se puede usar para almacenar cadenas como claves de forma
-- eficiente, si en cada nodo interno se almacena una letra y sus hijos
-- son las posibles letras que le pueden suceder. De esta forma la 
-- representaciÃ³n de todo un vocabulario se compacta. A continuaciÃ³n se
-- muestra un ejemplo, donde las Claves son nombres de personas y los
-- Valores son enteros que representan un nÃºmero de telÃ©fono.
--
--                              ""
--                             /  \
--                           "J"  "I"
--                            |    | \ 
--                           "U"  "V" "N"
--                           / \    \   \
--                         "A" "L"  "A" "E"
--                         /     \   |    \
--                       "N"    "I" "N"   "S"
--                      / |      |    \     \
--                   "A" 68972  "A"  69712  66631
--                    |         / \
--                 63822    67321 62375
--                              
-- el Ã¡rbol de ejemplo almacena los telÃ©fonos de los siguientes contactos:
--  "JUAN" -> 68972, "JULIA" -> 67321, "JULIA" -> 62375, "IVAN" -> 69712,
--  "JUANA" -> 63822, "INES" -> 66631
-- NÃ³tese que hay dos nombres repetidos ("JULIA"). De esta manera, las
-- claves se distribuyen en los nodos internos, de tal forma que cada nodo
-- tiene asociado tan solo un carÃ¡cter en forma de cadena (la clave es la
-- concatenaciÃ³n de la sucesiÃ³n de nodos internos desde la raÃ­z hasta la
-- hoja.
-- ---------------------------------------------------------------------


-- ---------------------------------------------------------------------
-- Ejercicio 1.1. Definir el tipo de datos para un Ã¡rbol Trie polimÃ³rfico,
-- donde los nodos internos almacenen un elemento de un tipo Clave y puedan
-- tener mÃ¡s de un hijo, y las hojas almacenen tan solo un Valor de otro 
-- tipo. El Ã¡rbol debe ser imprimible. LlÃ¡malo ArbolTrie, y usa como 
-- constructores HT para las hojas y NT para los nodos internos.
-- ---------------------------------------------------------------------

data ArbolTriePolimorfico c v = HT v
      | NT c [ArbolTriePolimorfico c v]
      deriving Show

--Ponemos c v porque c y v pueden ser de distintos tipos

-- ---------------------------------------------------------------------
-- Ejercicio 1.2. Definir un sinÃ³nimo de Ã¡rbol Trie que emplee cadenas
-- como Claves y enteros como Valores. LlÃ¡malo ArbolTrieContactos.
-- ---------------------------------------------------------------------

type ArbolTrieContactos = ArbolTriePolimorfico String Int

-- ---------------------------------------------------------------------
-- Ejercicio 2. Definir las funciones siguientes:
--    (a) (arbolTrieVacio), que devuelva un Ã¡rbol con solo el nodo raÃ­z,
--         el cual tiene como clave la cadena vacÃ­a ("") y ningÃºn hijo.
--    (b) (clave n), que devuelva la clave asociado al nodo n. Si n es
--         una hoja, devolver la cadena vacÃ­a "".
--    (c) (esHoja n), que indique con un booleano si el nodo n es una hoja.
-- Por ejemplo,
-- Î»> arbolTrieVacio
-- NT "" []
-- Î»> clave (NT "c" [])
-- "c"
-- Î»> clave (HT 433)
-- ""
-- Î»> esHoja (HT 433)
-- True
-- Î»> esHoja (NT "c" [])
-- False
--
-- ---------------------------------------------------------------------

arbolTrieVacio::  ArbolTrieContactos
arbolTrieVacio = NT "" []

clave :: ArbolTrieContactos -> String
clave (HT _) = ""
clave (NT c _ )= c

esHoja :: ArbolTrieContactos -> Bool
esHoja (HT _) = True
esHoja _ = False

-- ---------------------------------------------------------------------
-- Ejercicio 3.1 Definir la funciÃ³n (buscaClave s as), tal que reciba una
-- lista de Ã¡rboles as y una cadena de un solo carÃ¡cter s, y devuelva el
-- Ã¡rbol cuya clave coincida con s, en caso de existir mÃ¡s de uno,
-- devolver el primero de ellos. Si tal Ã¡rbol no existe, entonces
-- serÃ¡ un nodo interno nuevo con clave s y sin hijos. Por ejemplo,
-- Î»> buscaClave "s" [NT "o" [],NT "s" [HT 100]]
-- NT "s" [HT 100]
-- Î»> buscaClave "x" [NT "o" [],NT "s" [HT 100]]
-- NT "x" []
-- Î»> buscaClave "s" [NT "s" [],NT "s" [HT 100]]
--
-- ---------------------------------------------------------------------

buscaClave :: String -> [ArbolTrieContactos] -> ArbolTrieContactos
buscaClave s as
            | or [clave a == s | a <- as] = head [a | a <- as, clave a == s]
            | otherwise = NT s []

-- ---------------------------------------------------------------------
-- Ejercicio 3.2 Definir la funciÃ³n (siguienteNodo hs s), que reciba una
-- lista de Ã¡rboles as y una cadena de un solo carÃ¡cter s, y devuelva un
-- par tal que:
--  1. El primer elemento del par serÃ¡ el resultado de llamar a la funciÃ³n
--     buscaClave con s y as.
--  2. El segundo elemento del par serÃ¡n todos los nodos de as cuyas claves
--     no coincidan con s.
-- Por ejemplo,
-- Î»> siguienteNodo "s" [NT "o" [],NT "s" [HT 100]]
-- (NT "s" [HT 100],[NT "o" []])
-- Î»> siguienteNodo "x" [NT "o" [],NT "s" [HT 100]]
-- (NT "x" [],[NT "o" [],NT "s" [HT 100]])
--
-- ---------------------------------------------------------------------

siguienteNodo :: String -> [ArbolTrieContactos] -> (ArbolTrieContactos,[ArbolTrieContactos])
siguienteNodo s as = (buscaClave s as, nodosNoIguales)
      where nodosNoIguales = [a | a <- as, clave a /= s]

-- ---------------------------------------------------------------------
-- Ejercicio 4. Definir la funciÃ³n (inserta a p), que reciba un
-- Ã¡rbol Trie, a, y un par p = (clave, valor), siendo clave una cadena
-- de caracteres, y valor es un entero. La funciÃ³n debe devolver el
-- Ã¡rbol a extendido tal que incluya el nuevo par (clave,valor). El
-- procedimiento es como sigue:
--   - Si la clave es la cadena vacÃ­a, se aÃ±ade el valor como hoja del
--     nodo interno actual
--   - En otro caso, se llama a siguienteNodo con la primera letra de
--     la clave, y la lista lista de nodos hijos del nodo actual y la
--     primera letra de la clave. El resultado se utiliza para llamar
--     de nuevo a la funciÃ³n inserta y se aÃ±ade como hijo del nodo actual.
-- Por ejemplo,
-- Î»> inserta  arbolTrieVacio ("ok",43)
-- NT "" [NT "o" [NT "k" [HT 43]]]
-- Î»> inserta (NT "" [NT "o" [NT "k" [HT 43]]]) ("os",542)
-- NT "" [NT "o" [NT "s" [HT 542],NT "k" [HT 43]]]
--
-- ---------------------------------------------------------------------

inserta :: ArbolTrieContactos -> (String, Int) -> ArbolTrieContactos
inserta (NT c hs) ("", valor) = NT c  (HT valor : hs)
inserta (NT c hs) (s,valor) = NT c ((inserta a (tail s, valor)): as)
      where (a, as) = siguienteNodo [head s] hs

-- ---------------------------------------------------------------------
-- Ejercicio 5. Definir la funciÃ³n (insertaElemsEnArbol a cs), que reciba un
-- Ã¡rbol Trie, a, y una lista, cs, de pares (clave, valor), y devuelva un
-- Ã¡rbol con todos los elementos insertados. Por ejemplo, 
--    insertaElemsEnArbol arbolTrieVacio
--        [("IVAN",69712),("JULIA",62375),("JULIA",67321),("JUAN",68972)]
-- NT ""
-- [NT "J" [NT "U" [NT "A" [NT "N" [HT 68972]],NT "L" [NT "I" [NT "A" [HT 67321,HT 62375]]]]],
--  NT "I" [NT "V" [NT "A" [NT "N" [HT 69712]]]]]
--
-- ---------------------------------------------------------------------

insertaElemsEnArbol :: ArbolTrieContactos -> [(String, Int)] -> ArbolTrieContactos
insertaElemsEnArbol a [] = a
insertaElemsEnArbol a (x:xs) = insertaElemsEnArbol (inserta a x) xs

-- ---------------------------------------------------------------------
-- Ejercicio 6. Definir la (consultaValor a cs), tal que reciba un Ã¡rbol
-- Trie a y una Clave cs, y devuelva los valores asociados a ella. Si la
-- clave no estÃ¡ en el Ã¡rbol o no tiene asociados valores, devolver la
-- lista vacÃ­a. Por ejemplo,
-- let a = NT "" [NT "J" [NT "U" [NT "A" [NT "N" [HT 68972]],NT "L" [NT "I" [NT "A" [HT 67321,HT 62375]]]]],NT "I" [NT "V" [NT "A" [NT "N" [HT 69712]]]]]
-- Î»> consultaValor a "JUAN"
-- [68972]
-- Î»> consultaValor a "JULIA"
-- [67321,62375]
-- Î»> consultaValor a "JULIO"
-- []
--
-- ---------------------------------------------------------------------

consultaValor :: ArbolTrieContactos -> String -> [Int]
consultaValor (NT _ hs) "" = [ v | (HT v) <- hojas]
      where hojas = [h | h<-hs, esHoja h]
consultaValor (NT c hs) (s:ss)  
      | null as = []
      | otherwise = consultaValor arb ss
      where arb@(NT x as) = buscaClave [s] hs

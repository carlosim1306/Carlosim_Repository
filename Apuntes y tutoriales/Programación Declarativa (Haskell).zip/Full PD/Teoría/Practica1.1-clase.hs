-- PD-Practica 1.1
-- Definiciones de funciones, tipos y clases.
-- Departamento de Ciencias de la Computación e I.A.
-- Universidad de Sevilla
-- =====================================================================
import Data.Char
import Data.List

-- Definir previamente los tipos de la funciones a desarrollar.


-- ---------------------------------------------------------------------
-- Ejercicio 1. Define una función (contiene cs e) que dada una cadena de
-- caracteres cs y un caracter c, verifica si c pertenece a cs. Por ejemplo:
--
-- contiene "Hola mundo" 'b' == False
-- contiene "Hola mundo" 'a' == True
-- contiene "Hola mundo" 'm' == True
-- contiene [] 'm'           == False
-- ---------------------------------------------------------------------

contiene :: String -> Char -> Bool
contiene [] _ = False
contiene (c:cs) e = c == e || contiene cs e

-- la idea recursiva consta de hacer un or con la función que le pasamos a la cadena de manera recursiva, con caso base la lista vacía
-- y lo que sea y el caso recursivo que comprueba que la lista tenga al menos un caracter

-- La función (flip) cambia el orden de los dos primeros argumentos de 
-- entrada de una función. Ojo: si tienes tres o más argumentos, sólo 
-- cambia los dos primeros de orden.

contiene' :: String -> Char -> Bool
contiene' = flip elem

-- ---------------------------------------------------------------------
-- Ejercicio 2. Define una función (indice a cs) que dada un caracter a y
-- una cadena de caracteres cs, devuelve el índice de a dentro de cs
-- (empezando por la posición 0). Por ejemplo:
--
-- indice 'b' "Hola mundo" == -1
-- indice 'a' "Hola mundo" == 3
-- indice 'u' "Hola mundo" == 6
-- ---------------------------------------------------------------------

indice :: String -> Char -> Int
indice [] _ = -1
indice (c:cs) e =
    if c == e
        then 0
    else
        indice cs e + 1
        
-- La solucion a esta función es añadirle un acumulador
-- Ctr i para parar un bucle al comprobar una función

indice' :: String -> Char -> Int
indice' cs c = indice_aux cs c 0

indice_aux :: String -> Char -> Int -> Int
indice_aux [] _ _ = -1
indice_aux (c:cs) e ac =
    if c == e
        then ac
    else
        indice_aux cs e (ac+1)

-- Pedir la función reservada

indice'' :: Char -> String -> Int
indice'' _ [] = -1
indice'' a (c:cs)
    | a == c = 0
    | recu == -1 = -1
    | otherwise = 1 + recu
    where recu = indice'' a cs

-- Esta sería la forma de hacerlo de manera recursiva comprueba hasta el final, si llega a la lista vacía la función recursiva será -1

-- ---------------------------------------------------------------------
-- Ejercicio 3. Definir (EliminaN xs n) que dada una lista xs y un entero n,
-- elimina el n-ésimo elemento de xs (emepezando desde la posición 1). 
-- Por ejemplo:
--
-- eliminaN [0,1,2,2,4,5] 1 == [1,2,2,4,5]
-- eliminaN [0,1,2,2,4,5] 3 == [0,1,2,4,5]
-- eliminaN [0,1,2,2,4,5] 7 == [0,1,2,2,4,5] 
-- ---------------------------------------------------------------------

--eliminaN :: [Int] -> Int -> [Int]
--eliminaN ns n = eliminaN_aux ns n 0

--eliminaN_aux :: [Int] -> Int -> Int -> [Int]
--eliminaN_aux [] _ _ = []
--eliminaN_aux (n:ns) e ac =
--    if ac == e
--    then eliminaN_aux ns e (ac+1)
--    else
--        eliminaN_aux ns e (ac+1)

-- Misma idea pero habría que meter tanto un acumulador de número como de resultado

-- ---------------------------------------------------------------------
-- Ejercicio 4. Define funciones para determinar si un carácter es una 
-- letra mayúscula, es mínuscula o es un número. Por ejemplo:
--
-- esMayus 'A' == True
-- esMayus 'z' == False
-- esMinus 'A' == False
-- esMinus 'z' == True
-- ---------------------------------------------------------------------

esMayus:: Char -> Bool
esMayus c = 
    if c == toUpper c
    then True
    else False
--esMayus c = elem c ['A'..'Z']
--esMayus = flip elem ['A'..'Z']

esMinus:: Char -> Bool
esMinus c = 
    if c == toLower c
    then True
    else False
--esMinus c = elem c ['a'..'z']

esNum:: Char -> Bool
esNum  =  contiene ['0'..'9']

-- ---------------------------------------------------------------------
-- Ejercicio 5. Define una función (esLetraNum c) que dado un carácter, 
-- verifica si es una letra mayúscula, mínuscula o número. Por ejemplo:
--
-- esLetraNum 'C' == True
-- esLetraNum 'd' == True
-- esLetraNum '3' == True
-- esLetraNum '?' == False
--
-- ---------------------------------------------------------------------

esLetraNum:: Char -> Bool
esLetraNum c = esMayus c || esMinus c || esNum c

-- ---------------------------------------------------------------------
-- Ejercicio 6. Define una función (sumaConsecutiva n s xs) que dados dos
-- enteros n y s, y una lista xs, verifique si hay n elementos consecutivos 
-- de xs que sumen s.
--
-- sumaConsecutiva 3 5 [0,1,2,2,4,5,6,7] == True
-- sumaConsecutiva 2 5 [2,1,2,1,4,5,6,7] == True
-- sumaConsecutiva 6 5 [1,4,5,6,7]       == False
-- ---------------------------------------------------------------------

sumaConsecutiva :: Int -> Int -> [Int] -> Bool
sumaConsecutiva n s xs@(ns) =
    if n > length xs
    then False
    else sum(take n xs) == s || sumaConsecutiva n s xs
        
sumaConsecutiva' :: Int -> Int -> [Int] -> Bool
sumaConsecutiva' n s ns =
    or [sum(take n (drop i xs)) == s || i <- length ns -n]

-- ---------------------------------------------------------------------
-- Ejercicio 7. Definir la función (capital cs) que dada una cadena
-- de caracteres cs, devuelve la cadena en capital case:
--
-- capital "hola mundo"   == "Hola Mundo"
-- capital ""             == ""
-- capital "hola mundo ?" == "Hola Mundo ?"
-- ---------------------------------------------------------------------

capital = undefined



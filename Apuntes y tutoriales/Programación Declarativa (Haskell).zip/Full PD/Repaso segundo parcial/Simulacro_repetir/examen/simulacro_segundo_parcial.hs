import Data.Array
import System.IO
import System.Environment
import Pila
import Control.Exception (catch, SomeException)
import System.Environment (getArgs)
import Data.List
-- -----------------------------------------------------------------------------
-- Programación Declarativa 2023/24
-- Grado de Ingeniería Informática - Tecnologías Informáticas y
-- Doble Grado en Matemáticas e Ingenigería Informática
-- 2º Parcial                                            18 de Diciembre de 2023
-- -----------------------------------------------------------------------------
-- Apellidos:
-- Nombre:
-- UVUS:
-- Laboratorio/Puesto:
--
-- NO OLVIDES RELLENAR CON TUS DATOS LA CABECERA ANTERIOR
-- 
-- -----------------------------------------------------------------------------
-- INSTRUCCIONES PARA LA ENTREGA
-- 1. CAMBIA EL NOMBRE de este archivo por: examen_<uvus>.hs
--    donde "<uvus>" es tu UVUS. 
-- 2. COMENTA LAS LÍNEAS CON ERRORES hasta que se pueda cargar el fichero:
--    sin problemas. AQUELLOS ARCHIVOS DE CÓDIGO QUE NO CARGUEN POR ERRORES
--    DE CÓDIGO NO SE CORREGIRÁN.
-- 3. RELLENA los datos de la cabecera incluido el laboratorio y puesto.
-- 4. COMPRIME ESTE archivo en un único fichero llamado EXACTAMENTE:
--      ENTREGA-<uvus>.tar.gz      (o bien)       ENTREGA-<uvus>.tar.xz
--    donde "<uvus>" es tu UVUS. No te olvides del guión después de
--    ENTREGA, y NO lo comprimas en un fichero .zip.
-- 4. REINICIA el equipo. En el menú de selección del sistema (con fondo
--    blanco), HAZ CLICK SOBRE "Enviar examen" al lado de sistema Ubuntu.
-- 5. Pregunta al profesor si ha llegado tu entrega correctamente, si es
--    así, ya puedes dejar tu puesto APAGANDO EL EQUIPO (si lo consieras
--    oportuno, vuelve al escritorio y borra el examen del equipo).
-- ----------------------------------------------------------------------
-- ORIENTACIONES
-- · Escribe la solución de cada ejercicio en el hueco reservado para
--   ello. NO ESCRIBAS FUERA DE DICHO HUECO. NO MODIFIQUES NADA DE LOS 
--   ENUNCIADOS.
-- · Se valorará el uso correcto de tipados para cada función definida.
-- · Puedes añadir tantas funciones auxiliares como necesites (incluyendo su 
--   signatura adecuadamente).
-- · Puedes usar otros módulos de Haskell que estén ya importados.
-- -----------------------------------------------------------------------------

-- ------------------------------------------------------------------------------
-- Ejercicio 1.1 (0.5 puntos)
-- ------------------------------------------------------------------------------
-- Queremos almacenar listas de películas según nombre, año, nota en críticas 
-- y género. Para ello, definir el tipo de dato Genero que tenga los constructores 
-- Accion, Comedia, Drama, o CienciaFiccion, y sea mostrable en pantalla y 
-- comparable por igualdad.
-- ------------------------------------------------------------------------------

-- implementa el tipo de dato tras esta línea

-- ------------------------------------------------------------------------------

data Genero =
          Accion | Comedia | Drama | CienciaFiccion
          deriving (Eq,Show) 
-- ------------------------------------------------------------------------------
-- Ejercicio 1.2 (0.5 puntos)
-- ------------------------------------------------------------------------------
-- Definir, mediante sintaxis de registro, un nuevo tipo de dato Pelicula que  
-- contenga la información de las películas con el constructor del mismo nombre:
--   * titulo, tipo cadena de caracteres;
--   * year, tipo entero corto;
--   * notaMedia, tipo flotante;
--   * genero, tipo Genero.
--
-- El tipo de dato debe poder ser mostrable en pantalla.
-- ------------------------------------------------------------------------------

-- implementa el tipo de dato tras esta línea

-- ------------------------------------------------------------------------------
data Pelicula =
  Pelicula {
        titulo :: String, 
        year :: Int,
        notaMedia :: Float, 
        genero :: Genero
        }
        deriving (Show)
-- ------------------------------------------------------------------------------
-- Ejercicio 1.3 (0.5 puntos)
-- ------------------------------------------------------------------------------
-- Definir un tipo sinónimo para una lista de películas, una vez definido 
-- descomentar el ejemplo peliculas. Este ejemplo debe poder evaluarse sin errores.
-- ------------------------------------------------------------------------------

-- implementa el tipo sinónimo tras esta línea

type ListaPeliculas = [Pelicula]

-- descomentar tras definir el tipo

-- Ejemplo de uso

peliculas :: ListaPeliculas
peliculas =
  [ Pelicula "Inception" 2010 8.7 CienciaFiccion
  , Pelicula "The Shawshank Redemption" 1994 9.3 Drama
  , Pelicula "The Dark Knight" 2008 9.0 Accion
  , Pelicula "Forrest Gump" 1994 8.8 Drama
  , Pelicula "Pulp Fiction" 1994 8.9 Comedia
  , Pelicula "Godfather" 1972 9.2 Drama
  , Pelicula "Orgullo y Prejuicio" 2005 7.5 Drama
  , Pelicula "Fast And Furious" 2001 5.5 Accion
  , Pelicula "El Grinch" 2018 9 Comedia
  , Pelicula "El mundo es Nuestro" 2012 10 Comedia
  ]


-- ------------------------------------------------------------------------------

-- ------------------------------------------------------------------------------
-- Ejercicio 1.4 (1 punto)
-- ------------------------------------------------------------------------------
-- Definir la función (filtrarPorNotaMediaYGenero) que dados una nota media n, un 
-- Genero gen y una lista de peliculas ps, filtra las películas del género gen y 
-- con nota media superior a n.
--
-- >>> head $ filtrarPorNotaMediaYGenero 9.5 Comedia peliculas
-- Pelicula {titulo = "El mundo es Nuestro", year = 2012, notaMedia = 10.0, genero = Comedia}
--
-- >>> filtrarPorNotaMediaYGenero 5.5 Drama peliculas 
-- [Pelicula {titulo = "The Shawshank Redemption", year = 1994, notaMedia = 9.3, genero = Drama},
--  Pelicula {titulo = "Forrest Gump", year = 1994, notaMedia = 8.8, genero = Drama},
--  Pelicula {titulo = "Godfather", year = 1972, notaMedia = 9.2, genero = Drama},
--  Pelicula {titulo = "Orgullo y Prejuicio", year = 2005, notaMedia = 7.5, genero = Drama}]
--
-- ------------------------------------------------------------------------------

filtrarPorNotaMediaYGenero not xg [] = []
filtrarPorNotaMediaYGenero not gen (x:xs)
                                        | ((notaMedia x) > not) && (genero x) == gen = [x] ++ filtrarPorNotaMediaYGenero not gen xs
                                        | otherwise = filtrarPorNotaMediaYGenero not gen xs

-- ------------------------------------------------------------------------------

-- ------------------------------------------------------------------------------
-- Ejercicio 2.1 (0.5 puntos)
-- ------------------------------------------------------------------------------
-- Tenemos almacenados enteros y operaciones aritméticas en dos pilas distintas, 
-- con las cuales queremos realizar operaciones de forma consecutiva. Por ejemplo:
--
--     1|2|3|4|5|6|7|8|9|10|-  y  '+'|'-'|'+'|'-'|'+'|'*'|'*'|'+'|'+'|'-'|-
-- 
-- Definir el tipo de dato PilaAritmetica, que sea una tupla con el primer elemento 
-- como una pila de enteros y el segundo como una pila de caracteres. Una vez que se 
-- haya definido, descomentar los ejemplos.
-- ------------------------------------------------------------------------------

-- implementa el tipo de dato tras esta línea

type PilaAritmetica = (Pila Int, Pila Char)

-- descomentar tras definir el tipo

pilaNum :: Pila Int
pilaNum = foldr apila vacia [1..10]

pila1 :: PilaAritmetica
pila1 = (pilaNum, (apila '+' (apila '-' (apila '+' (apila '-' (apila '+' 
              (apila '*' (apila '*' (apila '+' (apila '+' (apila '-' vacia)))))))))))

pila2 :: PilaAritmetica
pila2 = (pilaNum, (apila '-' vacia))


-- ------------------------------------------------------------------------------

-- ------------------------------------------------------------------------------
-- Ejercicio 2.2 (1.5 puntos)
-- ------------------------------------------------------------------------------
-- Definir la función opera p, la cual, dada una pila aritmética p, realiza las
-- operaciones aritméticas de manera consecutiva con los enteros correspondientes. 
-- En caso de que las operaciones sean diferentes a +, - o *, el cálculo debe
-- detenerse y devolver un error informando de una operación no válida. Si la lista
-- de operaciones o valores está vacía, se debe devolver 0.
--
-- Por ejemplo,

-- > opera pila1 == 1135
-- True
-- > opera pila2 == 1
-- True
-- > opera (apila 5 (apila 7 vacia), apila '^' (apila '-' vacia))
-- *** Exception: Operación no válida
-- ------------------------------------------------------------------------------

opera :: PilaAritmetica -> Int
opera (p1,p2)
              | esVacia p2 || esVacia p1 = 0
              | (elem (cp2) ['+','-','*']) == False = error "Operación no válida"
              | cp2 == '+' = cp1 + opera (dp1,dp2)
              | cp2 == '-' = cp1 - opera (dp1,dp2)
              | otherwise = cp1 * opera (dp1,dp2)
              where
                cp1 = cima p1
                cp2 = cima p2
                dp1 = desapila p1
                dp2 = desapila p2

-- ------------------------------------------------------------------------------

-- ------------------------------------------------------------------------------
-- Ejercicio 3 (2 puntos)
-- ------------------------------------------------------------------------------
-- Supongamos que queremos simular con qué frecuencia se desbordará una nueva 
-- presa, lo cual depende del número de días lluviosos consecutivos observados. 
-- Podríamos empezar haciendo observaciones sobre una secuencia de días consecutivos 
-- para determinar si cada día estaba lluvioso (L) o soleado (S). Lo observado se 
-- muestra a continuación:
-- 
--          LLLLLLLLSSSSSSSLSSSSSLSSSSLLLLLLLLLLSLLLLSSSSSS
--
-- Parece que exactamente la mitad de los días observados fueron lluviosos. Con esto, 
-- podríamos intentar simular datos similares lanzando virtualmente una "moneda" para 
-- cada día, de modo que la probabilidad de lluvia en cualquier día 
-- en particular sea del 50%. Con este procedimiento obtendríamos un resultado similar 
-- al siguiente:
--
--           LLLSSSLLLLSSSLLLSLSLLLLSSSLSSLLLSLSSSSSLLSSLLLS
--
-- Observa cómo la secuencia simulada no se parece mucho a los datos observados reales. 
-- En los datos originales, hay largas secuencias de L y S, mientras que los datos 
-- simulados tienen secuencias mucho más cortas. 
--
-- La discrepancia es que la probabilidad de que un día en particular esté soleado o 
-- lluvioso no es independiente de si el día anterior fue soleado o lluvioso. En 
-- particular, parece que si un día es lluvioso, la probabilidad de que al día siguiente 
-- también llueva es mayor que si fuera soleado. Del mismo modo, si un día es soleado, 
-- la probabilidad de que al día siguiente también sea soleado es mayor que si fuera 
-- lluvioso.

-- Basándonos en todas las observaciones, parece que los días consecutivos tienen el 
-- mismo clima el 90% del tiempo. Con esto, podemos construir el siguiente modelo:

--
--                    +-----+       0.90        +-----+
--                    |  L  |<----------------->|  L  |
--                    +-----+                   +-----+
--                       ^                         ^ 
--                       | 0.10                    | 0.10
--                       v                         v 
--                    +-----+                   +-----+
--                    |  S  |<----------------->|  S  |
--                    +-----+       0.90        +-----+
-- 
--

-- Un modelo como este se llama una cadena de Markov, nombrada así en honor a Andrey Markov, 
-- un matemático ruso que publicó por primera vez un artículo sobre el tema en 1906.

-- Una de las características más interesantes de una cadena de Markov es que la probabilidad 
-- de llegar a cualquier estado después de cierto número de iteraciones (es decir, días en el 
-- ejemplo discutido) se puede encontrar a través de una potencia de una matriz de transición 
-- asociada:
--
-- 
--  |P(Li+1)|     | 0.9  0.1 |   | P(Li) |   | P(Li) * 0.9 + P(Si) * 0.1 |
--  |       |  =  |          | * |       | = |                           |
--  |P(Si+1)|     | 0.1  0.9 |   | P(Si) |   | P(Si) * 0.1 + P(Si) * 0.9 |
-- 

-- Implementar la función pAFuturo que recibe la matriz de transición, las probabilidades de 
-- un día (o estado inicial) y el número de días a futuro sobre los que calcular las nuevas 
-- probabilidades. Por ejemplo, si el estadoInicial es un vector [1,0] (hoy fue un día 
-- lluvioso):
--
-- > pAFuturo matrizTransicion 9 estadoInicial
-- array (1,2) [(1,0.5671088640000002),(2,0.4328911360000001)]
-- 
-- > pAFuturo matrizTransicion 1000 estadoInicial
-- array (1,2) [(1,0.5000000000000013),(2,0.5000000000000009)]
--
-- > pAFuturo matrizTransicion (-1) estadoInicial
-- array *** Exception: El número de días debe ser mayor o igual a cero.
-- CallStack (from HasCallStack):
--   error, called at examen.hs:84:16 in main:Main
--
-- Usar la función pAFuturo para calcular la probabilidad de lluvia y sol que hará dentro de 6 
-- días si hoy fue un día lluvioso.
--
-- Nota: la función pAFuturo debe ser válida para cualquier cadena de Markov, es decir, la matriz 
-- de transición puede tener cualquier dimensión.

--
-- ------------------------------------------------------------------------------
estadoInicial = listArray (1,2) [1.0,0.0]

matrizTransicion = listArray ((1,1),(2,2)) [if x == y then 0.9 else 0.1 | (x,y) <- range((1,1),(2,2))]

pAFuturo mt n ei
                | n < 0 = error "El número de días debe ser mayor o igual a cero"
                | n == 0 = ei
                | otherwise = pAFuturo mt (n-1) (multiplicaMatrizVector mt ei)

multiplicaMatrizVector mt ei = listArray (1,2) [ sum [((fila mt x)!x') * (ei!x') | x' <- range(bounds(fila mt x))] | x <- range(1,2)]

fila m i = listArray (1,f2) [m!(i,x)| x <- range(1,f2)]
          where (ini,(f1,f2)) = bounds m

-- ------------------------------------------------------------------------------

-- ------------------------------------------------------------------------------
-- Ejercicio 4 (3.5 puntos)
-- ------------------------------------------------------------------------------
-- Crea un programa Haskell que funcione como un simple sistema de gestión de
-- tareas. El programa debe permitir al usuario realizar las siguientes operaciones:
--
--    a. Leer las tareas desde un archivo. El programa debe ser capaz de cargar una
--       lista de tareas desde un archivo indicado por el usuario como argumento del
--       programa. Cada línea del archivo contiene la información de la tarea: nombre,
--       descripción y estado. Los estados posibles son: pendiente, en progreso, cerrada.
--
--    b. El programa debe permitir al usuario seleccionar una tarea de la lista
--       mostrada con un número de tarea y nombre. Una vez seleccionada, solicitará
--       el número de estado y después un texto adicional para agregar a la descripción.
--
--    c. Después de realizar cambios en las tareas, se podrá seleccionar la opción
--       terminar y guardar. Se deberá actualizar el archivo de lista de tareas.
--
--
-- Instrucciones para la implementación:
--   * Define el tipo de dato Tarea para representar cada registro de tareas. Usa la
--     sintaxis de registro vista en clase. Este tipo de dato debe tener los campos
--     numero (int), nombre (string), descripcion (string) y estado (int). Ejemplo:
--
--     Tarea {numero = 1, nombre = "Tarea 1", descripcion = "Lorem ipsum dolor sit amet,
--     conse", estado = 0}
--
--   * Implementa una función leerTareas que, dado una ruta de archivo, lea su contenido,
--     lo parsee y devuelva la lista de tareas (del tipo de datos Tarea). Funciones auxiliares
--     para parsear cada línea del archivo y convertirla a un tipo Tarea resultarán útiles:
--
--     > tareas <- leerTareas "tareas.txt"
--     > tareas
--     [Tarea {numero = 1, nombre = "Tarea 1", descripcion = "Lorem ipsum dolor sit amet,
--     conse", estado = 0}, Tarea {numero = 2, nombre = "Tarea 2", descripcion = "Ut ut
--     lacus ut sapien blandit ullamcorper.", estado = 2}]
--
--   * Implementa una función que permita seleccionar una tarea mediante su número. Si el
--     número indicado es válido, se pedirá el nuevo estado y la descripción adicional a
--     anexar a la ya existente. Esta función deberá devolver la lista de tareas actualizada:
--
--     > seleccionaYmodifica tareas
--     Seleccione una tarea por su número:
--     1
--     Seleccione un nuevo estado para la tarea (pendiente: 0, en progreso: 1, cerrada: 2):
--     1
--     Ingrese texto adicional para agregar a la descripción (deje en blanco si no desea
--     cambiarla):
--     Texto adicional
--     [Tarea {numero = 1, nombre = "Tarea 1", descripcion = "Lorem ipsum dolor sit amet,...
--     Texto adicional", estado = 1}, Tarea {numero = 2, nombre = "Tarea 2", descripcion =
--     "Ut ut lacus ut sapien blandit ullamcorper...", estado = 2}]
--
--   * Implementa la función guardarTareas. Esta función debe convertir a texto una
--     lista de tareas y guardarlo en el archivo indicado. Será de utilidad una
--     función para convertir una tarea a texto.
--   
--   * Implementa la función main. Esta función debe comprobar si se ha introducido el
--     argumento con el nombre del archivo de tareas. Si es así, se leerán las tareas
--     y se llamará a la función modificarOTerminar. Tras la ejecución de esta función,
--     se deberá llamar a la función guardarTareas.
     --------------------------------------------------------------------------------------------------------------------------

data Tarea =
    Tarea {
      numero :: Int, 
      nombre :: String, 
      descripcion :: String, 
      estado :: Int}
      deriving (Show)


printTarea :: Tarea -> IO()
printTarea tarea = do
  putStrLn ((show (numero tarea)) ++ "\t" ++ (nombre tarea) ++ ":: " ++ (take 30 (descripcion tarea)) ++ "...\t" ++ (show (estado tarea)))

printTareas :: [Tarea] -> IO()
printTareas tareas = sequence_ (map printTarea tareas)


-- Función para leer tareas desde un archivo

leerTareas :: FilePath -> IO [Tarea]
leerTareas path = do
    contenido <- readFile path
    let lineas = lines contenido
    return [parseTarea n l| (n,l) <- zip [1..] lineas]

parseTarea :: Int -> String -> Tarea
parseTarea num linea = Tarea num (nombreT linea) (descripcionT linea) (estadoT linea)
  where
    nombreT l = takeWhile (/='|') l
    descripcionT l = takeWhile (/='|') (tail (dropWhile (/='|') l))
    estadoT l = read [last l] :: Int
    
modifica :: Tarea -> String -> Int -> Tarea
modifica t cs n 
  | elem n [0,1,2] = Tarea (numero t) (nombre t) (desc ++ cs) n
  | otherwise = error "Estado no válido."
  where desc = descripcion t

-- Función para seleccionar y modificar una tarea

seleccionaYmodifica :: [Tarea] -> IO [Tarea]
seleccionaYmodifica ts = do
  putStrLn "Seleccione una tarea por su número:"
  l <- getLine
  let numTarea = read l :: Int
  if elem numTarea (map numero ts) then do
    putStrLn "Seleccione un nuevo estado para la tarea (pendiente: 0, en progreso: 1, cerrada: 2):"
    n <- getLine
    let nEstado = read n :: Int
    putStrLn "Ingrese texto adicional para agregar a la descripción (deje en blanco si no desea cambiarla):"
    cs <- getLine
    return [if numero t == numTarea then modifica t cs nEstado else t |  t <- ts] 
    else do
      putStrLn "Número de tarea no encontrado."
      seleccionaYmodifica ts

-- Esta parte la dan

modificarOTerminar :: [Tarea] -> IO [Tarea]
modificarOTerminar tareas = do
   printTareas tareas
   putStrLn "¿Que desea hacer?"
   putStrLn "M: Modificar Tarea"
   putStrLn "S: Salir y guardar"
   entrada <- getLine
   
   if entrada == "M" then do
     tareas <- seleccionaYmodifica tareas
     modificarOTerminar tareas
   else do
     if entrada == "S" then
       return tareas
     else do
       putStrLn "La opción introducida no es válida"
       modificarOTerminar tareas

-- Función para guardar tareas en un archivo
guardarTareas :: [Tarea] -> FilePath -> IO ()
guardarTareas tareas path = do
    let contenido = unlines $ map showTarea tareas
    writeFile path contenido

-- Función auxiliar para convertir una tarea a texto
showTarea :: Tarea -> String
showTarea tarea = nombre tarea ++ "|" ++ descripcion tarea ++ "|" ++ show (estado tarea)

-- Función principal
main :: IO ()
main = do
    args <- getArgs
    let fileName = case args of
            (a:_) -> a
            _ -> "tareas.txt"
    input <- catch (readFile fileName) (\err -> print (err :: SomeException) >> return "")
    if length input > 0
        then do
            let tareas = zipWith parseTarea [1..] (lines input)
            tareasModificadas <- modificarOTerminar tareas
            guardarTareas tareasModificadas fileName
        else return ()

-- Función para modificar o terminar
modificarOTerminar :: [Tarea] -> IO [Tarea]
modificarOTerminar tareas = do
    printTareas tareas
    putStrLn "¿Qué desea hacer?"
    putStrLn "M: Modificar Tarea"
    putStrLn "S: Salir y guardar"
    entrada <- getLine
    case entrada of
        "M" -> do
            tareasModificadas <- seleccionaYmodifica tareas
            modificarOTerminar tareasModificadas
        "S" -> return tareas
        _ -> do
            putStrLn "La opción introducida no es válida"
            modificarOTerminar tareas

-- ------------------------------------------------------------------------------


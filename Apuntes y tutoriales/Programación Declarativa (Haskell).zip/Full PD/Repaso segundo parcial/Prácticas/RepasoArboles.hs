data ArbolBinario a = 
    HB a | NB a (ArbolBinario a)  (ArbolBinario a)
    deriving (Eq, Show)

data ArbolTernario a =
    HT a | NT a (ArbolTernario a) (ArbolTernario a) (ArbolTernario a)
    deriving (Eq, Show)

data ArbolNario a =
    HN a | NN a [ArbolNario a]
    deriving (Eq, Show)

type ArbolBinarioEntero = ArbolBinario Int

--                          Número de hojas

-- Árbol Binario
-- ---------------------------------------------------------------------
-- Ejercicio 1.3.1. Definir la función
--    nHojasBinario :: Arbol a -> Int
-- tal que (nHojasBinario x) es el número de hojas del árbol binario x. Por ejemplo,
--    nHojasBinario (NB 9 (HB 2) (HB 4))  ==  2
-- ---------------------------------------------------------------------

nHojasBinario :: ArbolBinarioEntero -> Int
nHojasBinario (HB a) = 1
nHojasBinario (NB a izq der) = (nHojasBinario izq) + (nHojasBinario der)

-- Árbol Ternario
-- ---------------------------------------------------------------------
-- Ejercicio 1.3.2. Definir la función
--    nHojasTernario :: ArbolTernario a -> Int
-- tal que (nHojasTernario x) es el número de hojas del árbol ternario x. Por ejemplo,
--    nHojasTernario (NT 9 (HT 2) (HT 4) (HT 7))  ==  3
-- ---------------------------------------------------------------------

nHojasTernario :: ArbolTernario a -> Int
nHojasTernario (HT a) = 1
nHojasTernario (NT a izq cen der) = (nHojasTernario izq) + (nHojasTernario cen) + (nHojasTernario der)

-- Árbol N-ario
-- ---------------------------------------------------------------------
-- Ejercicio 1.3.3. Definir la función
--    nHojasNario :: ArbolNario a -> Int
-- tal que (nHojasNario x) es el número de hojas del árbol n-ario x. Por ejemplo,
--    nHojasNario (NN 9 [HN 2, HN 4, HN 7])  ==  3
-- ---------------------------------------------------------------------

nHojasNario :: ArbolNario a -> Int
nHojasNario (HN a) = 1
nHojasNario (NN a xs) = sum [nHojasNario x | x <- xs]

--                          Número de nodos

-- Árbol Binario
-- ---------------------------------------------------------------------
-- Ejercicio 1.4.1. Definir la función
--    nNodosBinario :: Arbol a -> Int
-- tal que (nNodosBinario x) es el número de nodos del árbol binario x. Por ejemplo,
--    nNodosBinario (NB 9 (NB 3 (HB 2) (HB 4)) (HB 7))  ==  2
-- ---------------------------------------------------------------------

nNodosBinario (HB _) = 0
nNodosBinario (NB _ izq der) = 1 + nNodosBinario izq + nNodosBinario der

-- Árbol Ternario
-- ---------------------------------------------------------------------
-- Ejercicio 1.4.2. Definir la función
--    nNodosTernario :: ArbolTernario a -> Int
-- tal que (nNodosTernario x) es el número de nodos del árbol ternario x. Por ejemplo,
--    nNodosTernario (NT 9 (NT 3 (HT 2) (HT 4) (HT 5)) (HT 7) (HT 8))  ==  2
-- ---------------------------------------------------------------------

nNodosTernario (HT _) = 0
nNodosTernario (NT _ izq cen der) = 1 + nNodosTernario izq + nNodosTernario cen + nNodosTernario der
-- Árbol N-ario
-- ---------------------------------------------------------------------
-- Ejercicio 1.4.3. Definir la función
--    nNodosNario :: ArbolNario a -> Int
-- tal que (nNodosNario x) es el número de nodos del árbol n-ario x. Por ejemplo,
--    nNodosNario (NN 9 [NN 3 [HN 2, HN 4], HN 7])  ==  2
-- ---------------------------------------------------------------------

nNodosNario (HN _) = 0
nNodosNario (NN _ xs) = 1 + sum [nNodosNario x| x <- xs]

--                          Profundidad

-- Árbol Binario
-- ---------------------------------------------------------------------
-- Ejercicio 2.3.1. Definir la función
--    profundidadBinario :: Arbol a -> Int
-- tal que (profundidadBinario x) es la profundidad del árbol binario x. Por ejemplo,
--    profundidadBinario (NB 9 (NB 3 (HB 2) (HB 4)) (HB 7))  ==  2
-- ---------------------------------------------------------------------

profundidadBinario (HB _) = 0
profundidadBinario (NB _ izq der) = max (1+profundidadBinario izq) (1+profundidadBinario der)
-- Árbol Ternario
-- ---------------------------------------------------------------------
-- Ejercicio 2.3.2. Definir la función
--    profundidadTernario :: ArbolTernario a -> Int
-- tal que (profundidadTernario x) es la profundidad del árbol ternario x. Por ejemplo,
--    profundidadTernario (NT 9 (NT 3 (NT 1 (HT 2) (HT 4) (HT 5)) (HT 6) (HT 7)) (NT 8 (HT 10) (HT 11) (HT 12)) (HT 13))  ==  3
-- ---------------------------------------------------------------------

profundidadTernario (HT _) = 0
profundidadTernario (NT _ izq cen der) = maximum [(1+profundidadTernario izq),(1+profundidadTernario cen),(1+profundidadTernario der)]
-- Árbol N-ario
-- ---------------------------------------------------------------------
-- Ejercicio 2.3.3. Definir la función
--    profundidadNario :: ArbolNario a -> Int
-- tal que (profundidadNario x) es la profundidad del árbol n-ario x. Por ejemplo,
--    profundidadNario (NN 9 [NN 3 [HN 2, HN 4], HN 7])  ==  2
-- ---------------------------------------------------------------------

profundidadNario (HN _) = 0
profundidadNario (NN a xs) = maximum [1+profundidadNario x | x <- xs]


--                          Añade hojas

-- Árbol Binario
-- ---------------------------------------------------------------------
-- Ejercicio 2.4.1. Definir la función
--    anadeHojasBinario :: Arbol a -> a -> a -> Arbol a
-- tal que (anadeHojasBinario a x y) añade a cada hoja del árbol a dos hojas con los datos x e y. Por ejemplo,
--    anadeHojasBinario (HB 5) 0 10 == NB 5 (HB 0) (HB 10)
-- ---------------------------------------------------------------------

anadeHojasBinario (HB a) i d = NB a (HB i) (HB d)
anadeHojasBinario (NB a izq der) i d = NB a (anadeHojasBinario izq i d) (anadeHojasBinario der i d)

-- Árbol Ternario
-- ---------------------------------------------------------------------
-- Ejercicio 2.4.2. Definir la función
--    anadeHojasTernario :: ArbolTernario a -> a -> a -> a -> ArbolTernario a
-- tal que (anadeHojasTernario a x y z) añade a cada hoja del árbol a tres hojas con los datos x, y y z. Por ejemplo,
--    anadeHojasTernario (HT 5) 0 10 20 == NT 5 (HT 0) (HT 10) (HT 20)
-- ---------------------------------------------------------------------

anadeHojasTernario (HT a) i c d = NT a (HT i) (HT c) (HT d)
anadeHojasTernario (NT a izq cen der) i c d = NT a (anadeHojasTernario izq i c d) (anadeHojasTernario cen i c d) (anadeHojasTernario der i c d)

-- Árbol N-ario
-- ---------------------------------------------------------------------
-- Ejercicio 2.4.3. Definir la función
--    anadeHojasNario :: ArbolNario a -> a -> ArbolNario a
-- tal que (anadeHojasNario a x) añade a cada hoja del árbol a una hoja con el dato x. Por ejemplo,
--    anadeHojasNario (HN 5) 0 == NN 5 [HN 0]
-- ---------------------------------------------------------------------

anadeHojasNario (HN a) x = NN a [HN x]
anadeHojasNario (NN a xs) x = NN a [anadeHojasNario x' x | x' <- xs]

--                  Sacar la lista de valores

-- Árbol Binario
-- ---------------------------------------------------------------------
-- Ejercicio 3.4.1. Definir la función
--    preordenBinario :: Arbol a -> [a]
-- tal que (preordenBinario x) es la lista correspondiente al recorrido preorden del árbol binario x. Por ejemplo,
--    listaBinario (NB 9 (NB 3 (HB 2) (HB 4)) (HB 7))  ==  [9, 3, 2, 4, 7]
-- ---------------------------------------------------------------------

listaBinario (HB a) = [a]
listaBinario (NB a izq der) = [a] ++ listaBinario izq ++ listaBinario der

-- Árbol Ternario
-- ---------------------------------------------------------------------
-- Ejercicio 3.4.2. Definir la función
--    preordenTernario :: ArbolTernario a -> [a]
-- tal que (preordenTernario x) es la lista correspondiente al recorrido preorden del árbol ternario x. Por ejemplo,
--    listaTernario (NT 9 (NT 3 (HT 2) (HT 4) (HT 5)) (HT 7) (HT 8))  ==  [9, 3, 2, 4, 5, 7, 8]
-- ---------------------------------------------------------------------

listaTernario (HT a) = [a]
listaTernario (NT a izq cen der) = [a] ++ listaTernario izq ++ listaTernario cen ++ listaTernario der

-- Árbol N-ario
-- ---------------------------------------------------------------------
-- Ejercicio 3.4.3. Definir la función
--    preordenNario :: ArbolNario a -> [a]
-- tal que (preordenNario x) es la lista correspondiente al recorrido preorden del árbol n-ario x. Por ejemplo,
--    listaNario (NN 9 [NN 3 [HN 2, HN 4], HN 7])  ==  [9, 3, 2, 4, 7]
-- ---------------------------------------------------------------------

listaNario (HN a) = [a]
listaNario (NN a xs) = [a] ++ concat[listaNario x | x <- xs]

--                              Suma valores hijos recursivamente

-- Árbol Binario
-- ---------------------------------------------------------------------
-- Ejercicio 5.1.1. Definir la función
--    sumaHijosBinario :: Num a => Arbol a -> Arbol a
-- tal que (sumaHijosBinario x) es un árbol binario donde el valor de cada nodo es la suma de sus hijos. Por ejemplo,
--    sumaHijosBinario (NB 9 (NB 3 (HB 2) (HB 4)) (HB 7))  ==  NB 16 (NB 6 (HB 2) (HB 4)) (HB 7)
-- ---------------------------------------------------------------------

sumaHijosBinario (HB a) = HB a
sumaHijosBinario (NB a izq der) = NB (a + valorArbolB hijoIzq + valorArbolB hijoDer) hijoIzq hijoDer
    where
        hijoIzq = sumaHijosBinario izq
        hijoDer = sumaHijosBinario der

valorArbolB (HB a) = a
valorArbolB (NB a izq der) = a

-- Árbol Ternario
-- ---------------------------------------------------------------------
-- Ejercicio 5.2.1. Definir la función
--    sumaHijosTernario :: Num a => ArbolTernario a -> ArbolTernario a
-- tal que (sumaHijosTernario x) es un árbol ternario donde el valor de cada nodo es la suma de sus hijos. Por ejemplo,
--    sumaHijosTernario (NT 9 (NT 3 (HT 2) (HT 4) (HT 1)) (HT 7) (HT 8))  ==  NT 34 (NT 10 (HT 2) (HT 4) (HT 1)) (HT 7) (HT 8)
-- ---------------------------------------------------------------------

sumaHijosTernario (HT a) = HT a
sumaHijosTernario (NT a izq cen der) = NT (a + valorArbolT hijoIzq + valorArbolT hijoCen + valorArbolT hijoDer) 
    hijoIzq hijoCen hijoDer
    where
        hijoIzq = sumaHijosTernario izq
        hijoCen = sumaHijosTernario cen
        hijoDer = sumaHijosTernario der

valorArbolT (HT a) = a
valorArbolT (NT a izq cen der) = a

-- Árbol N-ario
-- ---------------------------------------------------------------------
-- Ejercicio 5.3.1. Definir la función
--    sumaHijosNario :: Num a => ArbolNario a -> ArbolNario a
-- tal que (sumaHijosNario x) es un árbol n-ario donde el valor de cada nodo es la suma de sus hijos. Por ejemplo,
--    sumaHijosNario (NN 9 [NN 3 [HN 2, HN 4, HN 1], HN 7, HN 8])  ==  NN 27 [NN 10 [HN 2,HN 4,HN 1],HN 7,HN 8]

sumaHijosNario (HN a) = HN a
sumaHijosNario (NN a xs) = NN (a + sum[valorArbolN x| x <- xs]) [sumaHijosNario x'| x' <- xs]

valorArbolN (HN a) = a
valorArbolN (NN a xs) = a

--                          Suma el mayor hijo

-- Árbol Binario
-- ---------------------------------------------------------------------
-- Ejercicio 6.1.1. Definir la función
--    sumaMaxHijosBinario :: (Ord a, Num a) => Arbol a -> Arbol (a, a)
-- tal que (sumaMaxHijosBinario x) es un árbol binario donde el valor de cada nodo es una tupla de la suma del valor máximo de la suma
-- de sus hijos y su propio valor. Por ejemplo,
--    sumaMaxHijosBinario (NB 9 (NB 3 (HB 2) (HB 4)) (HB 7))  ==  NB (16, 9) (NB (7, 3) (HB (2, 2)) (HB (4, 4))) (HB (7, 7))
-- ---------------------------------------------------------------------

sumaMaxHijosBinario (HB a) = HB (a,a)
sumaMaxHijosBinario (NB a izq der) = NB (a + max (valorArbolBTupla hijoIzq) (valorArbolBTupla hijoDer), a) hijoIzq hijoDer
    where
        hijoIzq = sumaMaxHijosBinario izq
        hijoDer = sumaMaxHijosBinario der

valorArbolBTupla (HB (b,a)) = b
valorArbolBTupla (NB (b,a) izq der) = b

-- Árbol Ternario
-- ---------------------------------------------------------------------
-- Ejercicio 6.2.1. Definir la función
--    sumaMaxHijosTernario :: (Ord a, Num a) => ArbolTernario a -> ArbolTernario (a, a)
-- tal que (sumaMaxHijosTernario x) es un árbol ternario donde el valor de cada nodo es una tupla de la suma del valor máximo de sus hijos y su propio valor. Por ejemplo,
--    sumaMaxHijosTernario (NT 9 (NT 3 (HT 2) (HT 4) (HT 1)) (HT 7) (HT 8))  ==  NT (17, 9) (NT (7, 3) (HT (2, 2)) (HT (4, 4)) (HT (1, 1))) (HT (7, 7)) (HT (8, 8))
-- ---------------------------------------------------------------------

sumaMaxHijosTernario (HT a) = HT (a,a)
sumaMaxHijosTernario (NT a izq cen der) = NT (a+ maximum [valorArbolTTupla hijoIzq,valorArbolTTupla hijoCen,valorArbolTTupla hijoDer],a) hijoIzq hijoCen hijoDer
    where
        hijoIzq = sumaMaxHijosTernario izq
        hijoCen = sumaMaxHijosTernario cen
        hijoDer = sumaMaxHijosTernario der

valorArbolTTupla (HT (b,a)) = b
valorArbolTTupla (NT (b,a) _ _ _) = b
-- Árbol N-ario
-- ---------------------------------------------------------------------
-- Ejercicio 6.3.1. Definir la función
--    sumaMaxHijosNario :: (Ord a, Num a) => ArbolNario a -> ArbolNario (a, a)
-- tal que (sumaMaxHijosNario x) es un árbol n-ario donde el valor de cada nodo es una tupla de la suma del valor máximo de sus hijos y su propio valor. Por ejemplo,
--    sumaMaxHijosNario (NN 9 [NN 3 [HN 2, HN 4, HN 1], HN 7, HN 8])  ==  NN (17, 9) [NN (7, 3) [HN (2, 2), HN (4, 4), HN (1, 1)], HN (7, 7), HN (8, 8)]
-- ---------------------------------------------------------------------

sumaMaxHijosNario (HN a) = HN (a,a)
sumaMaxHijosNario (NN a xs) = NN (a + maximum [valorArbolNTupla (sumaMaxHijosNario x) | x <- xs],a) [sumaMaxHijosNario x'| x'<- xs]

valorArbolNTupla (HN (b,a)) = b
valorArbolNTupla (NN (b,a) _) = b

--                              Busca un valor y devuelve un árbol

-- Árbol Binario
-- ---------------------------------------------------------------------
-- Ejercicio 7.1.1. Definir la función
--    buscaValorBinario :: Eq a => a -> Arbol a -> Maybe (Arbol a)
-- tal que (buscaValorBinario v x) devuelve el subárbol a partir del nodo que contiene el valor v en el árbol binario x. Si el valor no se encuentra, devuelve Nothing. Por ejemplo,
--    buscaValorBinario 4 (NB 9 (NB 3 (HB 2) (HB 4)) (HB 7))  ==  Just (HB 4)
--    buscaValorBinario 3 (NB 9 (NB 3 (HB 2) (HB 4)) (HB 7))  ==  Just (NB 3 (HB 2) (HB 4))
--    buscaValorBinario 5 (NB 9 (NB 3 (HB 2) (HB 4)) (HB 7))  ==  Nothing
-- ---------------------------------------------------------------------

buscaValorBinario v (HB a)
    | a == v    = Just (HB a)
    | otherwise = Nothing
buscaValorBinario v (NB a izq der)
    | a == v    = Just (NB a izq der)
    | otherwise = case buscaValorBinario v izq of
                    Just subArbol -> Just subArbol
                    Nothing       -> buscaValorBinario v der
-- Árbol Ternario
-- ---------------------------------------------------------------------
-- Ejercicio 7.2.1. Definir la función
--    buscaValorTernario :: Eq a => a -> ArbolTernario a -> Maybe (ArbolTernario a)
-- tal que (buscaValorTernario v x) devuelve el subárbol a partir del nodo que contiene el valor v en el árbol ternario x. Si el valor no se encuentra, devuelve Nothing. Por ejemplo,
--    buscaValorTernario 4 (NT 9 (NT 3 (HT 2) (HT 4) (HT 1)) (HT 7) (HT 8))  ==  Just (HT 4)
--    buscaValorTernario 3 (NT 9 (NT 3 (HT 2) (HT 4) (HT 1)) (HT 7) (HT 8))  ==  Just (NT 3 (HT 2) (HT 4) (HT 1))
--    buscaValorTernario 5 (NT 9 (NT 3 (HT 2) (HT 4) (HT 1)) (HT 7) (HT 8))  ==  Nothing
-- ---------------------------------------------------------------------

-- Árbol N-ario
-- ---------------------------------------------------------------------
-- Ejercicio 7.3.1. Definir la función
--    buscaValorNario :: Eq a => a -> ArbolNario a -> Maybe (ArbolNario a)
-- tal que (buscaValorNario v x) devuelve el subárbol a partir del nodo que contiene el valor v en el árbol n-ario x. Si el valor no se encuentra, devuelve Nothing. Por ejemplo,
--    buscaValorNario 4 (NN 9 [NN 3 [HN 2, HN 4, HN 1], HN 7, HN 8])  ==  Just (HN 4)
--    buscaValorNario 3 (NN 9 [NN 3 [HN 2, HN 4, HN 1], HN 7, HN 8])  ==  Just (NN 3 [HN 2, HN 4, HN 1])
--    buscaValorNario 5 (NN 9 [NN 3 [HN 2, HN 4, HN 1], HN 7, HN 8])  ==  Nothing
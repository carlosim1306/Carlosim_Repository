-- PD-PrÃ¡ctica 6.1 
-- Tipos: Definiciones bÃ¡sicas de tipos de datos algebrÃ¡icos
-- Departamento de Ciencias de la ComputaciÃ³n e I.A.
-- Universidad de Sevilla
-- =====================================================================

-- ---------------------------------------------------------------------
-- Ejercicio 1. Haciendo uso de la decraraciÃ³n de tipos (type) define un
-- tipo nuevo, Punto2D, para los Puntos del Plano (de 2 dimensiones).
-- ---------------------------------------------------------------------

type Punto2D = (Int,Int)

-- ---------------------------------------------------------------------
-- Ejercicio 2. Usando el tipo Punto2D, define un vector delimitado por
-- un par de puntos, Vector2D.
-- ---------------------------------------------------------------------

type Vector2D = (Punto2D,Punto2D)

-- ---------------------------------------------------------------------
-- Ejercicio 3. Definir la funciÃ³n vector2Dcoor, que reciba un Vector2D
-- y devuelva un par que describa sus coordenadas. Si el vector estÃ¡
-- formado por los puntos p1 y p2, entonces el calculo del par se
-- calcula como sigue:
--   * la primera componente es la diferencia de la primera componente
--     de p2 menos del p1.
--   * la segunda componente es la diferencia de la segunda componente
--     de p2 menos del p1.
-- ---------------------------------------------------------------------

vector2Dcoor :: Vector2D -> Punto2D
vector2Dcoor ((x,y),(x1,y1)) = (x1-x,y1-y)

-- ---------------------------------------------------------------------
-- Ejercicio 4. Definir la funciÃ³n productoEscalar, tal que reciba dos
-- vectores Vector2D, y devuelva su producto escalar, calculado como
-- sigue: la suma de la multiplicaciÃ³n de las componentes de las
-- coordenadas de los vectores.
-- ---------------------------------------------------------------------

productoEscalar :: Vector2D -> Vector2D -> Int
productoEscalar v1 v2 = (x *x1) + (y * y1)
    where 
        (x,y) = vector2Dcoor v1
        (x1,y1) = vector2Dcoor v2

-- ---------------------------------------------------------------------
-- Ejercicio 5. Definir la funciÃ³n norma, tal que reciba un vector tipo
-- Vector2D y devuelva el mÃ³dulo del vector, definido como la raÃ­z
-- cuadrada del producto escalar del vector por sÃ­ mismo.
-- ---------------------------------------------------------------------

norma :: Vector2D -> Float
norma ((x,y),(x1,y1)) =  raizEntera (productoEscalar vector vector)
    where 
        vector = ((x,y),(x1,y1))
        raizEntera x = sqrt (fromIntegral x :: Float)

-- ---------------------------------------------------------------------
-- Ejercicio 6. Definir la funciÃ³n paralelos, que reciba dos vectores
-- tipo Vector2D y devuelva si los vectores son paralelos. El cÃ¡lculo
-- necesario para ello es comprobar que el valor absoluto del producto
-- escalar de los dos vectores dividido por la multiplicaciÃ³n de la
-- norma de cada uno, sea igual a 1.
-- ---------------------------------------------------------------------

paralelos :: Vector2D -> Vector2D -> Bool
paralelos v1 v2 = divisionRara (abs (productoEscalar v1 v2)) (norma v1 * norma v2) == 1.0
    where divisionRara x y = (fromIntegral x :: Float) / y

-- ---------------------------------------------------------------------
-- Ejercicio 7. Define tipos de datos (data) para almacenar informaciÃ³n
-- sobre el calendario: dÃ­as de la semana, meses, y estaciones del aÃ±o.
-- ---------------------------------------------------------------------

data DiaSemana = Lunes | Martes | Miercoles | Jueves | Viernes | Sabado | Domingo
  deriving (Show, Eq, Enum, Bounded)

data Mes = Enero | Febrero | Marzo | Abril | Mayo | Junio | Julio | Agosto | Septiembre | Octubre | Noviembre | Diciembre
  deriving (Show, Eq, Enum, Bounded)

data Estacion = Primavera | Verano | Otono | Invierno
  deriving (Show, Eq, Enum, Bounded)
-- ---------------------------------------------------------------------
-- Ejercicio 8. Haciendo uso del tipo Maybe, define una funciÃ³n de
-- divisiÃ³n segura (que al dividir por 0 no lance una excepciÃ³n).
-- ---------------------------------------------------------------------

divisionSegura :: (Eq a, Fractional a) => a -> a -> Maybe a
divisionSegura _ 0 = Nothing
divisionSegura a b = Just (a / b)

-- ---------------------------------------------------------------------
-- Ejercicio 9. Haciendo uso del tipo Maybe, define una funciÃ³n que
-- devuelva las raices de una ecuaciÃ³n de segundo grado.
-- ---------------------------------------------------------------------

raicesEcuacion :: (Eq a1, Eq a2, Num a1, Num a2, Num a3) => a1 -> a2 -> p -> Maybe a3
raicesEcuacion 0 _ _ = Nothing
raicesEcuacion a 0 _ = Just 1
raicesEcuacion _ _ _ = Just 2


import Data.List
import Test.QuickCheck

-- Hay que elegir una implementaciÃ³n del TAD pilas.

import PilaTA

-- ---------------------------------------------------------------------
-- A lo largo de la relaciÃ³n de ejercicios usaremos los siguientes
-- ejemplos de pilas:
-- ---------------------------------------------------------------------

ejP1, ejP2, ejP3, ejP4, ejP5 :: Pila Int
ejP1 = foldr apila vacia [1..20]
ejP2 = foldr apila vacia [2,5..18]
ejP3 = foldr apila vacia [3..10]
ejP4 = foldr apila vacia [4,-1,7,3,8,10,0,3,3,4]
ejP5 = foldr apila vacia [1..5]

-- importante, la pila mete y saca los valores por el mismo lugar, si rellenas una pila con la lista [1..20],
-- el primer valor de la pila es el 1
-- Para comprobar el funcionamiento, probar en la terminal cima(desapila ej1) y cima ej1

-- ---------------------------------------------------------------------
-- Ejercicio 1: Definir la funciÃ³n
--    filtraPila :: (a -> Bool) -> Pila a -> Pila a
-- tal que (filtraPila p pila) es la pila con los elementos de pila
-- que verifican el predicado p, en el mismo orden. Por ejemplo,
--    ghci> ejP1
--    1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|-
--    ghci> filtraPila even ejP1
--    2|4|6|8|10|12|14|16|18|20|-

-- ---------------------------------------------------------------------

filtraPila :: (a -> Bool) -> Pila a -> Pila a
filtraPila f p
                | esVacia p = vacia
                | f cp = apila cp (filtraPila f dp)
                | otherwise = filtraPila f dp
                where
                    cp = cima p
                    dp = desapila p

-- ---------------------------------------------------------------------
-- Ejercicio 2: Definir la funciÃ³n
--    mapPila :: (a -> a) -> Pila a -> Pila a
-- tal que (mapPila f pila) es la pila formada con las imÃ¡genes por f de
-- los elementos de pila, en el mismo orden. Por ejemplo,
--    ghci> mapPila (+7) ejP1
--    8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|-
-- ---------------------------------------------------------------------

mapPila :: (a -> a) -> Pila a -> Pila a
mapPila f p
            | esVacia p = vacia
            | otherwise = apila (f cp) (mapPila f dp)
            where
                cp = cima p
                dp = desapila p

-- ---------------------------------------------------------------------
-- Ejercicio 3: Definir la funciÃ³n
--    pertenecePila :: (Eq a) => a -> Pila a -> Bool
-- tal que (pertenecePila y p) se verifica si y sÃ³lo si y es un elemento
-- de la pila p. Por ejemplo,
--    pertenecePila 7 ejP1  == True
--    pertenecePila 70 ejP1 == False
-- ---------------------------------------------------------------------

pertenecePila :: (Eq a) => a -> Pila a -> Bool
pertenecePila n p
                | esVacia p = False
                | n == cp = True
                | otherwise = pertenecePila n dp
                where
                    cp = cima p
                    dp = desapila p

-- ---------------------------------------------------------------------
-- Ejercicio 4: definir la funciÃ³n
--    contenidaPila :: (Eq a) => Pila a -> Pila a -> Bool
-- tal que (contenidaPila p1 p2) se verifica si y sÃ³lo si todos los
-- elementos de p1 son elementos de p2. Por ejemplo,
--    contenidaPila ejP2 ejP1 == True
--    contenidaPila ejP1 ejP2 == False
-- ---------------------------------------------------------------------

contenidaPila :: (Eq a) => Pila a -> Pila a -> Bool
contenidaPila p1 p2
                    | esVacia p1 = True
                    | esVacia p2 = False
                    | cp1 == cp2 = contenidaPila dp1 dp2
                    | otherwise = contenidaPila p1 dp2
                    where
                        cp1 = cima p1
                        cp2 = cima p2
                        dp1 = desapila p1
                        dp2 = desapila p2

-- ---------------------------------------------------------------------
-- Ejercicio 4: Defiir la funciÃ³n
--    prefijoPila :: (Eq a) => Pila a -> Pila a -> Bool
-- tal que (prefijoPila p1 p2) se verifica si la pila p1 es justamente
-- un prefijo de la pila p2. Por ejemplo,
--    prefijoPila ejP3 ejP2 == False
--    prefijoPila ejP5 ejP1 == True
-- ---------------------------------------------------------------------

prefijoPila :: (Eq a) => Pila a -> Pila a -> Bool
prefijoPila p1 p2
                | esVacia p1 = True
                | cp1 == cp2 = True && (prefijoPila dp1 dp2)
                | otherwise = False && (prefijoPila dp1 dp2)
                where
                    cp1 = cima p1
                    cp2 = cima p2
                    dp1 = desapila p1
                    dp2 = desapila p2
-- ---------------------------------------------------------------------
-- Ejercicio 5: Definir la funciÃ³n
--    subPila :: (Eq a) => Pila a -> Pila a -> Bool
-- tal que (subPila p1 p2) se verifica si p1 es una subpila de p2.
-- Por ejemplo, 
--    subPila ejP2 ejP1 == False
--    subPila ejP3 ejP1 == True
-- ---------------------------------------------------------------------

subPila :: (Eq a) => Pila a -> Pila a  -> Bool
subPila p1 p2
                | esVacia p2 = False
                | prefijoPila p1 p2 = True
                | otherwise = subPila p1 dp2
                where
                    dp2 = desapila p2
            

-- ---------------------------------------------------------------------
-- Ejercicio 6: Definir la funciÃ³n
--    ordenadaPila :: (Ord a) => Pila a -> Bool
-- tal que (ordenadaPila p) se verifica si los elementos de la pila p
-- estÃ¡n ordenados en orden creciente. Por ejemplo,
--    ordenadaPila ejP1 == True
--    ordenadaPila ejP4 == False
-- ---------------------------------------------------------------------

ordenadaPila :: (Ord a) => Pila a -> Bool
ordenadaPila p
                | esVacia dp = True
                | cp1 > cp2 = False
                | otherwise =  True && ordenadaPila dp
                where
                    cp1 = cima p
                    dp = desapila p
                    cp2 = cima dp

-- ---------------------------------------------------------------------
-- Ejercicio 9.1: Definir la funciÃ³n 
--    ordenaInserPila :: (Ord a) => Pila a -> Pila a
-- tal que (ordenaInserPila p) es una pila con los elementos de la pila
-- p, ordenados por inserciÃ³n. Por ejemplo,
--    ghci> ordenaInserPila ejP4
--    -1|0|3|3|3|4|4|7|8|10|-
-- ---------------------------------------------------------------------

ordenaInserPila :: (Ord a) => Pila a -> Pila a
ordenaInserPila p
                | esVacia p = vacia
                | esMenor cp p = apila cp (ordenaInserPila dp)
                | otherwise = apila menor (ordenaInserPila (eliminaMenor menor p))
                where
                    cp = cima p
                    dp = desapila p
                    menor = buscaMenor p cp

esMenor n p
            | esVacia p = True
            | n <= cp = True && esMenor n dp
            | otherwise = False
            where
                cp = cima p
                dp = desapila p

buscaMenor p acc
                | esVacia p = acc
                | otherwise = (buscaMenor dp (min acc cp))
                where
                    cp = cima p
                    dp = desapila p

eliminaMenor n p
                | n == cp = dp
                | otherwise = apila cp (eliminaMenor n dp)
                where
                    cp = cima p
                    dp = desapila p

-- ---------------------------------------------------------------------
-- Ejercicio 10.1: Definir la funciÃ³n
--    nubPila :: (Eq a) => Pila a -> Pila a
-- tal que (nubPila p) es una pila con los elementos de p sin
-- repeticiones. Por ejemplo,
--    ghci> ejP4
--    4|-1|7|3|8|10|0|3|3|4|-
--    ghci> nubPila ejP4
--    -1|7|8|10|0|3|4|-
-- ---------------------------------------------------------------------

nubPila p
        | esVacia p = vacia
        | pertenecePila cp dp = nubPila dp
        | otherwise = apila cp (nubPila dp)
        where
            cp = cima p
            dp = desapila p
-- ---------------------------------------------------------------------
-- Ejercicio 11: Definir la funciÃ³n 
--    maxPila :: (Ord a) => Pila a -> a
-- tal que (maxPila p) sea el mayor de los elementos de la pila p. Por
-- ejemplo, 
--    ghci> ejP4
--    4|-1|7|3|8|10|0|3|3|4|-
--    ghci> maxPila ejP4
--    10
-- ---------------------------------------------------------------------

maxPila p = auxMaxPila dp cp
    where 
        cp = cima p
        dp = desapila p

auxMaxPila p acc
                | esVacia p = acc
                | otherwise = (auxMaxPila dp (max acc cp))
                where
                    cp = cima p
                    dp = desapila p
-- ---------------------------------------------------------------------
-- Ejercicio 6: Definir la función
--    inviertePila :: Pila a -> Pila a
-- tal que (inviertePila p) es la pila con los elementos de p en orden
-- inverso. Por ejemplo,
--    ghci> ejP1
--    1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|-
--    ghci> inviertePila ejP1
--    20|19|18|17|16|15|14|13|12|11|10|9|8|7|6|5|4|3|2|1|-
-- ---------------------------------------------------------------------

inviertePila p
            | esVacia p = vacia
            | otherwise = apila (ultimo p) (inviertePila (pilaUlt p))
                
ultimo p
        | esVacia dp = cp
        | otherwise = ultimo dp
        where
            cp = cima p
            dp = desapila p

pilaUlt p
        | esVacia dp = vacia
        | otherwise = apila cp (pilaUlt dp)
        where
            cp = cima p
            dp = desapila p
            
-- ---------------------------------------------------------------------
-- Ejercicio 7: Definir la función
--    concatenaPilas :: Pila a -> Pila a -> Pila a
-- tal que (concatenaPilas p1 p2) es la pila resultante de concatenar
-- las pilas p1 y p2. Por ejemplo,
--    ghci> ejP1
--    1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|-
--    ghci> ejP2
--    2|5|8|11|14|17|-
--    ghci> concatenaPilas ejP1 ejP2
--    1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|2|5|8|11|14|17|-
-- ---------------------------------------------------------------------
concatenaPilas p1 p2
                    | esVacia p1 && esVacia p2 = vacia
                    | esVacia p1 = apila cp2 (concatenaPilas p1 dp2)
                    | otherwise = apila cp1 (concatenaPilas dp1 p2)
                    where
                        cp1 = cima p1
                        cp2 = cima p2
                        dp1 = desapila p1
                        dp2 = desapila p2

-- ---------------------------------------------------------------------
-- Ejercicio 8: Definir la función
--    nubPrimeroPila :: (Eq a) => Pila a -> Pila a
-- tal que (nubPrimeroPila p) es la pila con los elementos de p sin
-- repeticiones, manteniendo el primero de cada elemento. Por ejemplo,
--    ghci> ejP4
--    4|-1|7|3|8|10|0|3|3|4|-
--    ghci> nubPrimeroPila ejP4
--    -1|7|8|10|0|3|4|-
-- ---------------------------------------------------------------------

nubPrimeroPila p
                | esVacia p = vacia
                | pertenecePila cp dp = apila cp (nubPrimeroPila (filtraPila (/=cp) dp))
                | otherwise = apila cp (nubPrimeroPila dp)
                where
                    cp = cima p
                    dp = desapila p

-- ---------------------------------------------------------------------
-- Ejercicio 9: Definir la función
--    interseccionPilas :: (Eq a) => Pila a -> Pila a -> Pila a
-- tal que (interseccionPilas p1 p2) es la pila con los elementos
-- comunes a las pilas p1 y p2. Por ejemplo,
--    ghci> ejP1
--    1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|-
--    ghci> ejP2
--    2|5|8|11|14|17|-
--    ghci> interseccionPilas ejP1 ejP2
--    2|5|8|11|14|17|-
-- ---------------------------------------------------------------------

interseccionPilas p1 p2
                        | esVacia p2 = vacia
                        | pertenecePila cp2 p1 = apila cp2 (interseccionPilas p1 dp2)
                        | otherwise = (interseccionPilas p1 dp2)
                        where
                            cp1 = cima p1
                            cp2 = cima p2
                            dp1 = desapila p1
                            dp2 = desapila p2
-- ---------------------------------------------------------------------
-- Ejercicio 10: Definir la función
--    esPalindromoPila :: (Eq a) => Pila a -> Bool
-- tal que (esPalindromoPila p) se verifica si los elementos de la pila
-- p forman un palíndromo. Por ejemplo,
--    ghci> ejP1
--    1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|-
--    ghci> esPalindromoPila ejP1
--    False
--    ghci> ejP5
--    1|2|3|4|5|-
--    ghci> esPalindromoPila ejP5
--    False
--    ghci> inviertePila ejP5
--    5|4|3|2|1|-
--    ghci> esPalindromoPila (concatenaPilas ejP5 (inviertePila ejP5))
--    True
-- ---------------------------------------------------------------------

esPalindromoPila p 
                    | esVacia p = True
                    | esVacia dp = True
                    | cp /= (ultimo p) = False
                    | otherwise = True && (esPalindromoPila (pilaUlt dp))
                    where
                        cp = cima p
                        dp = desapila p
                    
-- ---------------------------------------------------------------------
-- Generador de pilas                                                 --
-- ---------------------------------------------------------------------

-- genPila es un generador de pilas. Por ejemplo,
--    ghci> sample genPila
--    -
--    0|0|-
--    -
--    -6|4|-3|3|0|-
--    -
--    9|5|-1|-3|0|-8|-5|-7|2|-
--    -3|-10|-3|-12|11|6|1|-2|0|-12|-6|-
--    2|-14|-5|2|-
--    5|9|-
--    -1|-14|5|-
--    6|13|0|17|-12|-7|-8|-19|-14|-5|10|14|3|-18|2|-14|-11|-6|-

genPila :: (Arbitrary a, Num a) => Gen (Pila a)
genPila = do xs <- listOf arbitrary
             return (foldr apila vacia xs)
         


-- El tipo pila es una instancia del arbitrario. 
instance (Arbitrary a, Num a) => Arbitrary (Pila a) where
    arbitrary = genPila

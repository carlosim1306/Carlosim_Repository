-- PD- El TAD de las colas.
-- Correspondiente a RelaciÃ³n 22 de I1M 2019-20
-- Departamento de Ciencias de la ComputaciÃ³n e I.A.
-- Universidad de Sevilla
-- =====================================================================

-- ---------------------------------------------------------------------
-- IntroducciÃ³n                                                       --
-- ---------------------------------------------------------------------

-- El objetivo de esta relaciÃ³n de ejercicios es definir funciones sobre 
-- el TAD de las colas, utilizando las implementaciones estudiadas en el 
-- tema 15 transparencias se encuentran en 
--    http://www.cs.us.es/~jalonso/cursos/i1m/temas/tema-15.html
-- 
-- Para realizar los ejercicios hay que instalar la librerÃ­a I1M que
-- contiene la implementaciÃ³n de TAD de las pilas. Los pasos para
-- instalarla son los siguientes:
-- + cabal update
-- + cabal install I1M
-- 
-- Otra forma es descargar las implementaciones de las implementaciones
-- de las colas:
-- + ColaConListas.hs    que estÃ¡ en http://bit.ly/21z3wQL
-- + ColaConDosListas.hs que estÃ¡ en http://bit.ly/21z3AQp

-- ---------------------------------------------------------------------
-- ImportaciÃ³n de librerÃ­as                                           --
-- ---------------------------------------------------------------------

import Data.List
import Test.QuickCheck

-- Hay que elegir una implementaciÃ³n del TAD colas:
import ColaConListas
-- import ColaConDosListas
-- import I1M.Cola
    
-- ---------------------------------------------------------------------
-- Nota. A lo largo de la relaciÃ³n de ejercicios usaremos los siguientes
-- ejemplos de colas:
c1, c2, c3, c4, c5, c6 :: Cola Int
c1 = foldr inserta vacia [1..20]
c2 = foldr inserta vacia [2,5..18]
-- Este acaba en 17 porque va de 3 en 3
c3 = foldr inserta vacia [3..10]
c4 = foldr inserta vacia [4,-1,7,3,8,10,0,3,3,4]
c5 = foldr inserta vacia [15..20]
c6 = foldr inserta vacia (reverse [1..20])
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 1: Definir la funciÃ³n
--    ultimoCola :: Cola a -> a
-- tal que (ultimoCola c) es el Ãºltimo elemento de la cola c. Por
-- ejemplo:
--    ultimoCola c4 == 4
--    ultimoCola c5 == 15
-- ---------------------------------------------------------------------

ultimoCola :: Cola a -> a
ultimoCola c
            | esVacia rc = pc
            | otherwise = ultimoCola rc
            where
                pc = primero c
                rc = resto c

-- ---------------------------------------------------------------------
-- Ejercicio 2: Definir la funciÃ³n
--    longitudCola :: Cola a -> Int
-- tal que (longitudCola c) es el nÃºmero de elementos de la cola c. Por
-- ejemplo, 
--     longitudCola c2 == 6
-- ---------------------------------------------------------------------

longitudCola :: Cola a -> Int
longitudCola c
                | esVacia rc = 1
                | otherwise = 1 + longitudCola rc
                where
                    pc = primero c
                    rc = resto c

-- ---------------------------------------------------------------------
-- Ejercicio 3: Definir la funciÃ³n 
--    todosVerifican :: (a -> Bool) -> Cola a -> Bool
-- tal que (todosVerifican p c) se verifica si todos los elementos de la
-- cola c cumplen la propiedad p. Por ejemplo,
--    todosVerifican (>0) c1 == True
--    todosVerifican (>0) c4 == False
-- ---------------------------------------------------------------------

todosVerifican :: (a -> Bool) -> Cola a -> Bool
todosVerifican p c
                    | esVacia rc = p pc
                    | otherwise = p pc && todosVerifican p rc
                    where
                        pc = primero c
                        rc = resto c

-- ---------------------------------------------------------------------
-- Ejercicio 4: Definir la funciÃ³n
--    algunoVerifica :: (a -> Bool) -> Cola a -> Bool
-- tal que (algunoVerifica p c) se verifica si algÃºn elemento de la cola
-- c cumple la propiedad p. Por ejemplo,
--   algunoVerifica (<0) c1 == False
--   algunoVerifica (<0) c4 == True
-- ---------------------------------------------------------------------

algunoVerifica :: (a -> Bool) -> Cola a -> Bool
algunoVerifica p c 
                    | esVacia rc = p pc
                    | otherwise = p pc || algunoVerifica p rc
                    where
                        pc = primero c
                        rc = resto c

-- ---------------------------------------------------------------------
-- Ejercicio 5: Definir la funciÃ³n
--    ponAlaCola :: Cola a -> Cola a -> Cola a
-- tal que (ponAlaCola c1 c2) es la cola que resulta de poner los
-- elementos de c2 a la cola de c1. Por ejemplo,
--    ponAlaCola c2 c3 == C [17,14,11,8,5,2,10,9,8,7,6,5,4,3]
-- ---------------------------------------------------------------------

ponAlaCola :: Cola a -> Cola a -> Cola a
ponAlaCola c1 c2
                | esVacia c2 = c1
                | otherwise = inserta pc2 (ponAlaCola c1 rc2)
                where
                    pc2 = primero c2
                    rc2 = resto c2

-- ---------------------------------------------------------------------
-- Ejercicio 6: Definir la funciÃ³n
--    mezclaColas :: Cola a -> Cola a -> Cola a
-- tal que (mezclaColas c1 c2) es la cola formada por los elementos de
-- c1 y c2 colocados en una cola, de forma alternativa, empezando por
-- los elementos de c1. Por ejemplo,
--    mezclaColas c2 c4 == C [17,4,14,3,11,3,8,0,5,10,2,8,3,7,-1,4]
-- ---------------------------------------------------------------------

mezclaColas :: Cola a -> Cola a -> Cola a
mezclaColas c1 c2 = auxMezclaColas c1 c2 vacia

auxMezclaColas :: Cola a -> Cola a -> Cola a -> Cola a
auxMezclaColas c1 c2 acc
                        | esVacia c1 && esVacia c2 = acc
                        | esVacia c1 && (esVacia c2 == False) = auxMezclaColas c1 rc2 (inserta pc2 acc)
                        | (esVacia c1 == False) && esVacia c2 = auxMezclaColas rc1 c2 (inserta pc1 acc)
                        | otherwise = auxMezclaColas rc1 rc2 (inserta pc2 (inserta pc1 acc))
                        where
                            pc1 = primero c1
                            pc2 = primero c2
                            rc1 = resto c1
                            rc2 = resto c2

-- ---------------------------------------------------------------------
-- Ejercicio 7: Definir la funciÃ³n
--    agrupaColas :: [Cola a] -> Cola a
-- tal que (agrupaColas [c1,c2,c3,...,cn]) es la cola formada mezclando
-- las colas de la lista como sigue: mezcla c1 con c2, el resultado con
-- c3, el resultado con c4, y asÃ­ sucesivamente. Por ejemplo,
--    ghci> agrupaColas [c3,c3,c4]
--    C [10,4,10,3,9,3,9,0,8,10,8,8,7,3,7,7,6,-1,6,4,5,5,4,4,3,3]
-- ---------------------------------------------------------------------

agrupaColas :: [Cola a] -> Cola a
agrupaColas [] = vacia
agrupaColas [x] = x
agrupaColas xs = auxAgrupaColas xs vacia

auxAgrupaColas :: [Cola a] -> Cola a -> Cola a
auxAgrupaColas xs acc
                    | length xs == 0 = acc
                    | esVacia acc = auxAgrupaColas (tail (tail xs)) (mezclaColas (head xs) (head (tail xs)))
                    | otherwise = auxAgrupaColas (tail xs) (mezclaColas acc (head xs))


-- ---------------------------------------------------------------------
-- Ejercicio 8: Definir la funciÃ³n
--    perteneceCola :: Eq a => a -> Cola a -> Bool
-- tal que (perteneceCola x c) se verifica si x es un elemento de la
-- cola c. Por ejemplo, 
--    perteneceCola 7 c1  == True
--    perteneceCola 70 c1 == False
-- ---------------------------------------------------------------------

perteneceCola :: Eq a => a -> Cola a -> Bool
perteneceCola y c
                | esVacia c = False
                | otherwise = y == pc || perteneceCola y rc
                where
                    pc = primero c
                    rc = resto c

-- ---------------------------------------------------------------------
-- Ejercicio 9: Definir la funciÃ³n
--    contenidaCola :: Eq a => Cola a -> Cola a -> Bool
-- tal que (contenidaCola c1 c2) se verifica si todos los elementos de
-- c1 son elementos de c2. Por ejemplo, 
--    contenidaCola c2 c1 == True
--    contenidaCola c1 c2 == False
-- ---------------------------------------------------------------------

contenidaCola :: Eq a => Cola a -> Cola a -> Bool
contenidaCola c1 c2
                    | esVacia c1 = True
                    | otherwise = perteneceCola pc1 c2 && contenidaCola rc1 c2
                    where
                        pc1 = primero c1
                        rc1 = resto c1

-- ---------------------------------------------------------------------
-- Ejercicio 10: Definir la funciÃ³n
--    prefijoCola :: Eq a => Cola a -> Cola a -> Bool
-- tal que (prefijoCola c1 c2) se verifica si la cola c1 es un prefijo
-- de la cola c2. Por ejemplo, 
--    prefijoCola c3 c2 == False
--    prefijoCola c5 c1 == True
-- ---------------------------------------------------------------------

prefijoCola :: Eq a => Cola a -> Cola a -> Bool
prefijoCola c1 c2 
                    | esVacia c1 = True
                    | esVacia c2 = False
                    | otherwise = pc1 == pc2 && prefijoCola rc1 rc2
                    where
                        pc1 = primero c1
                        rc1 = resto c1
                        pc2 = primero c2
                        rc2 = resto c2

-- ---------------------------------------------------------------------
-- Ejercicio 11: Definir la funciÃ³n
--    subCola :: Eq a => Cola a -> Cola a -> Bool
-- tal que (subCola c1 c2) se verifica si c1 es una subcola de c2. Por
-- ejemplo,  
--    subCola c2 c1 == False
--    subCola c3 c1 == True
-- ---------------------------------------------------------------------

subCola :: Eq a => Cola a -> Cola a -> Bool
subCola c1 c2 = esVacia (auxSubcola c1 c2 c1)

auxSubcola :: Eq a => Cola a -> Cola a -> Cola a -> Cola a
auxSubcola c1 c2 acc
                    | esVacia c2 = acc
                    | esVacia acc = vacia
                    | pc2 /= pcAcc = auxSubcola c1 rc2 c1
                    | otherwise = auxSubcola c1 rc2 rcAcc
                    where
                        pc2 = primero c2
                        pcAcc = primero acc
                        rc2 = resto c2
                        rcAcc = resto acc


-- ---------------------------------------------------------------------
-- Ejercicio 12: Definir la funciÃ³n
--    ordenadaCola :: Ord a => Cola a -> Bool
-- tal que (ordenadaCola c) se verifica si los elementos de la cola c
-- estÃ¡n ordenados en orden creciente. Por ejemplo,
--    ordenadaCola c6 == True
--    ordenadaCola c4 == False
-- ---------------------------------------------------------------------

ordenadaCola :: Ord a => Cola a -> Bool
ordenadaCola c
                | esVacia c || esVacia rc1 = True
                | otherwise = pc1 <= pc2 && ordenadaCola rc1
                where
                        pc1 = primero c
                        pc2 = primero rc1
                        rc1 = resto c

-- ---------------------------------------------------------------------
-- Ejercicio 13.1: Definir una funciÃ³n
--    lista2Cola :: [a] -> Cola a
-- tal que (lista2Cola xs) es una cola formada por los elementos de xs.
-- Por ejemplo,
--    lista2Cola [1..6] == C [1,2,3,4,5,6]
-- ---------------------------------------------------------------------

lista2Cola :: [a] -> Cola a
lista2Cola [] = vacia
lista2Cola xs = inserta (last xs) (lista2Cola (take (length xs -1) xs))

-- ---------------------------------------------------------------------
-- Ejercicio 13.2: Definir una funciÃ³n
--    cola2Lista :: Cola a -> [a]
-- tal que (cola2Lista c) es la lista formada por los elementos de p.
-- Por ejemplo,
--    cola2Lista c2 == [17,14,11,8,5,2]
-- ---------------------------------------------------------------------

cola2Lista :: Cola a -> [a]
cola2Lista c
            | esVacia rc = [pc]
            | otherwise = pc : (cola2Lista rc)
            where
                pc = primero c
                rc = resto c

-- ---------------------------------------------------------------------
-- Ejercicio 13.3. Comprobar con QuickCheck que la funciÃ³n cola2Lista es
-- la inversa de  lista2Cola, y recÃ­procamente.
-- ---------------------------------------------------------------------

prop_cola2Lista :: Cola Int -> Bool
prop_cola2Lista c = undefined

-- ghci> quickCheck prop_cola2Lista
-- +++ OK, passed 100 tests.

prop_lista2Cola :: [Int] -> Bool
prop_lista2Cola xs = undefined

-- ghci> quickCheck prop_lista2Cola
-- +++ OK, passed 100 tests.

-- ---------------------------------------------------------------------
-- Ejercicio 14: Definir la funciÃ³n 
--    maxCola :: Ord a => Cola a -> a
-- tal que (maxCola c) es el mayor de los elementos de la cola c. Por
-- ejemplo, 
--    maxCola c4 == 10
-- ---------------------------------------------------------------------

maxCola :: Ord a => Cola a -> a
maxCola c
        | esVacia rc2 = max pc1 pc2
        | otherwise = max pc1 (maxCola rc1)
        where
            pc1 = primero c
            rc1 = resto c
            pc2 = primero rc1
            rc2 = resto rc1

-- ---------------------------------------------------------------------
-- Generador de colas                                          --
-- ---------------------------------------------------------------------

-- genCola es un generador de colas de enteros. Por ejemplo,
--    ghci> sample genCola
--    C ([],[])
--    C ([],[])
--    C ([],[])
--    C ([],[])
--    C ([7,8,4,3,7],[5,3,3])
--    C ([],[])
--    C ([1],[13])
--    C ([18,28],[12,21,28,28,3,18,14])
--    C ([47],[64,45,7])
--    C ([8],[])
--    C ([42,112,178,175,107],[])
genCola :: (Num a, Arbitrary a) => Gen (Cola a)
genCola = frequency [(1, return vacia),
                     (30, do n <- choose (10,100)
                             xs <- vectorOf n arbitrary
                             return (creaCola xs))]
          where creaCola = foldr inserta vacia

-- El tipo cola es una instancia del arbitrario.
instance (Arbitrary a, Num a) => Arbitrary (Cola a) where
    arbitrary = genCola


-- ColaConListas.hs
-- ImplementaciÃ³n de las colas mediante listas.
-- JosÃ© A. Alonso JimÃ©nez <jalonso@us.es>
-- Sevilla, 11 de Septiembre de 2010
-- ---------------------------------------------------------------------

module ColaConListas 
    (Cola,
     vacia,   -- Cola a
     inserta, -- a -> Cola a -> Cola a
     primero, -- Cola a -> a
     resto,   -- Cola a -> Cola a
     esVacia, -- Cola a -> Bool
     valida   -- Cola a -> Bool
    ) where

-- Colas como listas:
newtype Cola a = C [a]
    deriving (Show, Eq)

-- Ejemplo de cola
--    ghci> c1
--    C [10,9,8,7,6,5,4,3,2,1]
c1 = foldr inserta vacia [1..10]

-- vacia es la cola vacÃ­a. Por ejemplo,
--    ghci> vacia
--    C []
vacia :: Cola a
vacia = C []

-- (inserta x c) es la cola obtenida aÃ±adiendo x al final de la cola
-- c. Por ejemplo,
--    inserta 12 c1  ==  C [10,9,8,7,6,5,4,3,2,1,12]
inserta :: a -> Cola a -> Cola a
inserta x (C c) = C (c ++ [x])

-- Nota: La operaciÃ³n inserta usa O(n) pasos.

-- (primero c) es el primer elemento de la cola c. Por ejemplo,
--    primero c1  ==  10
primero :: Cola a -> a
primero (C (x:_)) = x
primero (C [])    = error "primero: cola vacia"

-- (resto c) es la cola obtenida eliminando el primer elemento de la
-- cola c. Por ejemplo,
--    resto c1  ==  C [9,8,7,6,5,4,3,2,1]
resto :: Cola a -> Cola a
resto (C (_:xs)) = C xs
resto (C [])     = error "resto: cola vacia"

-- (esVacia c) se verifica si c es la cola vacÃ­a. Por ejemplo,
--    esVacia c1     ==  False
--    esVacia vacia  ==  True
esVacia :: Cola a -> Bool
esVacia (C xs)  = null xs

-- (valida c) se verifica si c representa una cola vÃ¡lida. Con esta
-- representaciÃ³n, todas las colas son vÃ¡lidas.
valida :: Cola a -> Bool
valida c = True

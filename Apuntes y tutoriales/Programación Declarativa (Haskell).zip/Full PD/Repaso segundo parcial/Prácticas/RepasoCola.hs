
import Data.List
import Test.QuickCheck

-- Hay que elegir una implementaciÃ³n del TAD colas:
import ColaConListas
-- import ColaConDosListas
    
-- ---------------------------------------------------------------------
-- Nota. A lo largo de la relaciÃ³n de ejercicios usaremos los siguientes
-- ejemplos de colas:
c1, c2, c3, c4, c5, c6 :: Cola Int
c1 = foldr inserta vacia [1..20]
c2 = foldr inserta vacia [2,5..18]
-- Este acaba en 17 porque va de 3 en 3
c3 = foldr inserta vacia [3..10]
c4 = foldr inserta vacia [4,-1,7,3,8,10,0,3,3,4]
c5 = foldr inserta vacia [15..20]
c6 = foldr inserta vacia (reverse [1..20])
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 1: Definir la funciÃ³n
--    ultimoCola :: Cola a -> a
-- tal que (ultimoCola c) es el Ãºltimo elemento de la cola c. Por
-- ejemplo:
--    ultimoCola c4 == 4
--    ultimoCola c5 == 15
-- ---------------------------------------------------------------------

ultimoCola c
            | esVacia rc = pc
            | otherwise = ultimoCola rc
            where
                rc = resto c
                pc = primero c

-- ---------------------------------------------------------------------
-- Ejercicio 2: Definir la funciÃ³n
--    longitudCola :: Cola a -> Int
-- tal que (longitudCola c) es el nÃºmero de elementos de la cola c. Por
-- ejemplo, 
--     longitudCola c2 == 6
-- ---------------------------------------------------------------------

longitudCola c
                | esVacia c = 0
                | otherwise = 1 + (longitudCola rc)
                where
                    rc = resto c

-- ---------------------------------------------------------------------
-- Ejercicio 3: Definir la funciÃ³n 
--    todosVerifican :: (a -> Bool) -> Cola a -> Bool
-- tal que (todosVerifican p c) se verifica si todos los elementos de la
-- cola c cumplen la propiedad p. Por ejemplo,
--    todosVerifican (>0) c1 == True
--    todosVerifican (>0) c4 == False
-- ---------------------------------------------------------------------

todosVerifican f c
                    | esVacia c = True
                    | f pc = True && (todosVerifican f rc)
                    | otherwise = False
                    where
                        pc = primero c
                        rc = resto c

-- ---------------------------------------------------------------------
-- Ejercicio 4: Definir la funciÃ³n
--    algunoVerifica :: (a -> Bool) -> Cola a -> Bool
-- tal que (algunoVerifica p c) se verifica si algÃºn elemento de la cola
-- c cumple la propiedad p. Por ejemplo,
--   algunoVerifica (<0) c1 == False
--   algunoVerifica (<0) c4 == True
-- ---------------------------------------------------------------------

algunoVerifica f c
                    | esVacia c = False
                    | f pc = True 
                    | otherwise = False || (algunoVerifica f rc)
                    where
                        pc = primero c
                        rc = resto c

-- ---------------------------------------------------------------------
-- Ejercicio 5: Definir la funciÃ³n
--    ponAlaCola :: Cola a -> Cola a -> Cola a
-- tal que (ponAlaCola c1 c2) es la cola que resulta de poner los
-- elementos de c2 a la cola de c1. Por ejemplo,
--    ponAlaCola c2 c3 == C [17,14,11,8,5,2,10,9,8,7,6,5,4,3]
-- ---------------------------------------------------------------------

ponAlaCola c1 c2
                | esVacia c2 = c1
                | otherwise = inserta pc2 (ponAlaCola c1 rc2)
                where
                    pc2 = primero c2
                    rc2 = resto c2

concatenaCola c1 c2 = auxConcatenaCola c1 c2 vacia

auxConcatenaCola c1 c2 acc
                        | esVacia acc = (auxConcatenaCola c1 c2 c1)
                        | esVacia c2 = acc
                        | otherwise = auxConcatenaCola c1 rc2 (inserta pc2 acc)
                        where
                            pc2 = primero c2
                            rc2 = resto c2

-- ---------------------------------------------------------------------
-- Ejercicio 6: Definir la funciÃ³n
--    mezclaColas :: Cola a -> Cola a -> Cola a
-- tal que (mezclaColas c1 c2) es la cola formada por los elementos de
-- c1 y c2 colocados en una cola, de forma alternativa, empezando por
-- los elementos de c1. Por ejemplo,
--    mezclaColas c2 c4 == C [17,4,14,3,11,3,8,0,5,10,2,8,3,7,-1,4]
-- ---------------------------------------------------------------------

mezclaColas c1 c2 = auxMezclacola c1 c2 vacia

auxMezclacola c1 c2 acc
                        | esVacia c1 && esVacia c2 = acc
                        | esVacia c1 = auxMezclacola c1 rc2 (inserta pc2 acc)
                        | esVacia c2 = auxMezclacola rc1 c2 (inserta pc1 acc)
                        | otherwise = auxMezclacola rc1 rc2 (inserta pc2 (inserta pc1 acc))
                        where
                            pc1 = primero c1
                            pc2 = primero c2
                            rc1 = resto c1
                            rc2 = resto c2

-- ---------------------------------------------------------------------
-- Ejercicio 7: Definir la funciÃ³n
--    agrupaColas :: [Cola a] -> Cola a
-- tal que (agrupaColas [c1,c2,c3,...,cn]) es la cola formada mezclando
-- las colas de la lista como sigue: mezcla c1 con c2, el resultado con
-- c3, el resultado con c4, y asÃ­ sucesivamente. Por ejemplo,
--    ghci> agrupaColas [c3,c3,c4]
--    C [10,4,10,3,9,3,9,0,8,10,8,8,7,3,7,7,6,-1,6,4,5,5,4,4,3,3]
-- ---------------------------------------------------------------------

agrupaColas xs
                | length xs == 0 = vacia
                | length xs == 1 = head xs
                | length xs == 2 = mezclaColas (head xs) (head (tail xs))
                | otherwise = auxAgrupaColas xs vacia

auxAgrupaColas xs acc
                    | esVacia acc = auxAgrupaColas (tail (tail xs)) (mezclaColas (head xs) (head (tail xs)))
                    | length xs == 0 = acc
                    | otherwise = auxAgrupaColas (tail xs) (mezclaColas acc (head xs))
-- ---------------------------------------------------------------------
-- Ejercicio 8: Definir la funciÃ³n
--    perteneceCola :: Eq a => a -> Cola a -> Bool
-- tal que (perteneceCola x c) se verifica si x es un elemento de la
-- cola c. Por ejemplo, 
--    perteneceCola 7 c1  == True
--    perteneceCola 70 c1 == False
-- ---------------------------------------------------------------------

perteneceCola n c
                | esVacia c = False
                | n == pc = True
                | otherwise = perteneceCola n rc
                where
                    pc = primero c
                    rc = resto c

-- ---------------------------------------------------------------------
-- Ejercicio 9: Definir la funciÃ³n
--    contenidaCola :: Eq a => Cola a -> Cola a -> Bool
-- tal que (contenidaCola c1 c2) se verifica si todos los elementos de
-- c1 son elementos de c2. Por ejemplo, 
--    contenidaCola c2 c1 == True
--    contenidaCola c1 c2 == False
-- ---------------------------------------------------------------------

contenidaCola c1 c2
                    | esVacia c1 = True
                    | perteneceCola pc1 c2 = (contenidaCola rc1 c2)
                    | otherwise = False
                    where
                        pc1 = primero c1
                        rc1 = resto c1

-- ---------------------------------------------------------------------
-- Ejercicio 10: Definir la funciÃ³n
--    prefijoCola :: Eq a => Cola a -> Cola a -> Bool
-- tal que (prefijoCola c1 c2) se verifica si la cola c1 es un prefijo
-- de la cola c2. Por ejemplo, 
--    prefijoCola c3 c2 == False
--    prefijoCola c5 c1 == True
-- ---------------------------------------------------------------------

prefijoCola c1 c2
                | esVacia c1 = True
                | pc1 == pc2 = True && (prefijoCola rc1 rc2)
                | otherwise = False
                where
                    pc1 = primero c1
                    rc1 = resto c1
                    pc2 = primero c2
                    rc2 = resto c2
-- ---------------------------------------------------------------------
-- Ejercicio 11: Definir la funciÃ³n
--    subCola :: Eq a => Cola a -> Cola a -> Bool
-- tal que (subCola c1 c2) se verifica si c1 es una subcola de c2. Por
-- ejemplo,  
--    subCola c2 c1 == False
--    subCola c3 c1 == True
-- ---------------------------------------------------------------------

subCola c1 c2
            | esVacia c2 = False
            | prefijoCola c1 c2 = True
            | otherwise = subCola c1 rc2
            where
                rc2 = resto c2
-- ---------------------------------------------------------------------
-- Ejercicio 12: Definir la funciÃ³n
--    ordenadaCola :: Ord a => Cola a -> Bool
-- tal que (ordenadaCola c) se verifica si los elementos de la cola c
-- estÃ¡n ordenados en orden creciente. Por ejemplo,
--    ordenadaCola c6 == True
--    ordenadaCola c4 == False
-- ---------------------------------------------------------------------

ordenadaCola c
                | esVacia rc1 = True
                | pc1 > pc2 = False
                | otherwise = ordenadaCola rc1
                where
                    pc1 = primero c
                    rc1 = resto c
                    pc2 = primero rc1
-- ---------------------------------------------------------------------
-- Ejercicio 14: Definir la funciÃ³n 
--    maxCola :: Ord a => Cola a -> a
-- tal que (maxCola c) es el mayor de los elementos de la cola c. Por
-- ejemplo, 
--    maxCola c4 == 10
-- ---------------------------------------------------------------------

maxCola c = auxMaxPila rc pc
            where
                pc = primero c
                rc = resto c

auxMaxPila c acc
                | esVacia c = acc
                | otherwise = auxMaxPila rc (max acc pc)
                where
                    pc = primero c
                    rc = resto c
-- ---------------------------------------------------------------------
-- Ejercicio 13: Definir la función
--    invierteCola :: Cola a -> Cola a
-- tal que (invierteCola c) es la cola con los elementos en orden inverso. Por ejemplo,
--    invierteCola c1 == C [20,19,18,...,1]
-- ---------------------------------------------------------------------

invierteCola c1
                | esVacia c1 = vacia
                | otherwise = inserta pc1 (invierteCola rc1)
                where
                    pc1 = primero c1
                    rc1 = resto c1
-- ---------------------------------------------------------------------
-- Ejercicio 15: Definir la función
--    sumaColas :: Num a => Cola a -> Cola a -> Cola a
-- tal que (sumaColas c1 c2) es la cola que resulta de sumar los elementos correspondientes de c1 y c2. Si una cola es más larga que la otra, los elementos restantes se añaden tal cual. Por ejemplo,
--    sumaColas c2 c3 == C C [27,23,19,15,11,7]
-- ---------------------------------------------------------------------

sumaColas c1 c2 = auxSumaColas c1 c2 vacia

auxSumaColas c1 c2 acc
                        | esVacia c1 || esVacia c2 = acc
                        | otherwise = auxSumaColas rc1 rc2 (inserta (pc1 + pc2) acc)
                        where
                            pc1 = primero c1
                            pc2 = primero c2
                            rc1 = resto c1
                            rc2 = resto c2

-- ---------------------------------------------------------------------
-- Ejercicio 17: Definir la función
--    interseccionColas :: Eq a => Cola a -> Cola a -> Cola a
-- tal que (interseccionColas c1 c2) es la cola que contiene los elementos que están en ambas colas. Por ejemplo,
--    interseccionColas c1 c2 == C [2,5,8,11,14,17]
-- ---------------------------------------------------------------------

interseccionColas c1 c2 = auxInterseccionColas c1 c2 vacia

auxInterseccionColas c1 c2 acc
                            | esVacia c1 = acc
                            | perteneceCola pc1 c2 = auxInterseccionColas rc1 c2 (inserta pc1 acc)
                            | otherwise = auxInterseccionColas rc1 c2 acc
                            where
                                pc1 = primero c1
                                pc2 = primero c2
                                rc1 = resto c1
                                rc2 = resto c2
-- ---------------------------------------------------------------------
-- Ejercicio 18: Definir la función
--    colaDeColas :: Cola (Cola a) -> Cola a
-- tal que (colaDeColas cc) es la cola que resulta de concatenar todas las colas en cc. Por ejemplo,
--    colaDeColas (C [c1, c2, c3]) == C [1,2,...,20,2,5,...,17,3,4,...,10]
-- ---------------------------------------------------------------------
{-
colaDeColas cc = auxColaColas rcc pcc
                where
                    pcc = primero cc
                    rcc = resto cc

auxColaColas cc acc
                    | esVacia cc = acc
                    | otherwise = auxColaColas rcc (concatenaCola acc pcc vacia)
                    where
                        pcc = primero cc
                        rcc = resto cc
-}
-- ---------------------------------------------------------------------
-- Generador de colas                                          --
-- ---------------------------------------------------------------------

-- genCola es un generador de colas de enteros. Por ejemplo,
--    ghci> sample genCola
--    C ([],[])
--    C ([],[])
--    C ([],[])
--    C ([],[])
--    C ([7,8,4,3,7],[5,3,3])
--    C ([],[])
--    C ([1],[13])
--    C ([18,28],[12,21,28,28,3,18,14])
--    C ([47],[64,45,7])
--    C ([8],[])
--    C ([42,112,178,175,107],[])
genCola :: (Num a, Arbitrary a) => Gen (Cola a)
genCola = frequency [(1, return vacia),
                     (30, do n <- choose (10,100)
                             xs <- vectorOf n arbitrary
                             return (creaCola xs))]
          where creaCola = foldr inserta vacia

-- El tipo cola es una instancia del arbitrario.
instance (Arbitrary a, Num a) => Arbitrary (Cola a) where
    arbitrary = genCola


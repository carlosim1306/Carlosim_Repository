-- PD. PrÃ¡ctica 7.3
--Tipos: Multiconjuntos como Diccionarios
-- Departamento de Ciencias de la ComputaciÃ³n e I.A.
-- Universidad de Sevilla
-- =====================================================================

-- ---------------------------------------------------------------------
-- IntroducciÃ³n                                                       --
-- ---------------------------------------------------------------------

-- Un multiconjunto es una colecciÃ³n de elementos en los que no importa
-- el orden de los elementos, pero sÃ­ el nÃºmero de veces en que
-- aparecen. Por ejemplo, la factorizaciÃ³n prima de un nÃºmero se puede
-- representar como un multiconjunto de nÃºmeros primos. 
-- 
-- El objetivo de esta relaciÃ³n de ejercicios es implementar el TAD de
-- los multiconjuntos utilizando los diccionarios.

-- El manual, con ejemplos, de la librerÃ­a Data.Map se encuentra en
-- http://bit.ly/25B1na0

-- ---------------------------------------------------------------------
-- LibrerÃ­as auxiliares                                               --
-- ---------------------------------------------------------------------

import qualified Data.Map as M

-- ---------------------------------------------------------------------
-- El tipo de dato de multiconjuntos                                  --
-- ---------------------------------------------------------------------

-- Un multiconjunto se puede representar mediante un diccionario donde
-- las claves son los elementos del multiconjunto y sus valores sus
-- nÃºmeros de ocurrencias. Por ejemplo, el multiconjunto 
--    {a, b, a, c, b, a, e}
-- se representa por el diccionario
--    fromList [(a,3), (b,2), (c,1), (e,1)]

type MultiConj a = M.Map a Int

-- ---------------------------------------------------------------------
-- Construcciones de multiconjuntos                                   --
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 1. Definir la constante
--    vacio :: MultiConj a
-- para el multiconjunto vacÃ­o. Por ejemplo,
--    vacio  ==  fromList []
-- ---------------------------------------------------------------------

vacio :: MultiConj a
vacio = M.empty

-- ---------------------------------------------------------------------
-- Ejercicio 2. Definir la funciÃ³n
--    unitario :: a -> MultiConj a
-- tal que (unitario x) es el multiconjunto cuyo Ãºnico elemento es
-- x. Por ejemplo,
--    unitario 'a'  ==  fromList [('a',1)]
-- ---------------------------------------------------------------------

unitario :: a -> MultiConj a
unitario x = M.singleton x 1

-- ---------------------------------------------------------------------
-- AÃ±adir y quitar elementos                                          --
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 3. Definir la funciÃ³n
--    inserta :: Ord a => a -> MultiConj a -> MultiConj a
-- tal que (inserta x m) es el multiconjunto obtenido aÃ±adiÃ©ndole a m el 
-- elemento x. Por ejemplo,
--    ghci> inserta 'a' (unitario 'a')
--    fromList [('a',2)]
--    ghci> inserta 'b' it
--    fromList [('a',2),('b',1)]
--    ghci> inserta 'a' it
--    fromList [('a',3),('b',1)]
--    ghci> inserta 'b' it
--    fromList [('a',3),('b',2)]
-- ---------------------------------------------------------------------

inserta :: Ord a => a -> MultiConj a -> MultiConj a
inserta x m = M.insertWith (+) x 1 m

resta :: Ord a => a -> MultiConj a -> MultiConj a
resta x map = M.insertWith (+) x (-1) map
-- ---------------------------------------------------------------------
-- Ejercicio 4. Definir la funciÃ³n 
--    listaAmc :: Ord a => [a] -> MultiConj a
-- tal que (listaAmc xs) es el multiconjunto cuyos elementos son los de
-- la lista xs. Por ejemplo,
--    listaAmc "ababc"  ==  fromList [('a',2),('b',2),('c',1)]
-- ---------------------------------------------------------------------

listaAmc :: Ord a => [a] -> MultiConj a
listaAmc [] = vacio
listaAmc (x:xs) = inserta x (listaAmc xs)

-- ---------------------------------------------------------------------
-- Ejercicio 5. Definir la funciÃ³n
--    insertaVarios :: Ord a => a -> Int -> MultiConj a -> MultiConj a
-- tal que (insertaVarios x n m) es el multiconjunto obtenido
-- aÃ±adiÃ©ndole a m n copias del elemento x. Por ejemplo, 
--    ghci> insertaVarios 'a' 3 vacio
--    fromList [('a',3)]
--    ghci> insertaVarios 'b' 2 it 
--    fromList [('a',3),('b',2)]
--    ghci> insertaVarios 'a' 2 it 
--    fromList [('a',5),('b',2)]
-- ---------------------------------------------------------------------

insertaVarios :: Ord a => a -> Int -> MultiConj a -> MultiConj a
insertaVarios x 0 map = map
insertaVarios x n map = inserta x (insertaVarios x (n-1) map)

-- ---------------------------------------------------------------------
-- Ejercicio 6. Definir la funciÃ³n
--    borra :: Ord a => a -> MultiConj a -> MultiConj a
-- tal que (borra x m) es el multiconjunto obtenido borrando una
-- ocurrencia de x en m. Por ejemplo,
--    ghci> borra 'a' (listaAmc "ababc")
--    fromList [('a',1),('b',2),('c',1)]
--    ghci> borra 'a' it
--    fromList [('b',2),('c',1)]
--    ghci> borra 'a' it
--    fromList [('b',2),('c',1)]
-- ---------------------------------------------------------------------

borra :: Ord a => a -> MultiConj a -> MultiConj a
borra x map = M.filter (>0) (resta x map)

-- ---------------------------------------------------------------------
-- Ejercicio 7. Definir la funciÃ³n
--    borraVarias :: Ord a => a -> Int -> MultiConj a -> MultiConj a
-- tal que (borraVarias x n m) es el multiconjunto obtenido a partir del
-- m borrando n ocurrencias del elemento x. Por ejemplo,
--    ghci> listaAmc "ababcad"
--    fromList [('a',3),('b',2),('c',1),('d',1)]
--    ghci> borraVarias 'a' 2 (listaAmc "ababcad")
--    fromList [('a',1),('b',2),('c',1),('d',1)]
--    ghci> borraVarias 'a' 5 (listaAmc "ababcad")
--    fromList [('b',2),('c',1),('d',1)]
-- ---------------------------------------------------------------------

borraVarias :: Ord a => a -> Int -> MultiConj a -> MultiConj a
borraVarias x 0 map = map
borraVarias x 1 map = borra x map
borraVarias x n map = borraVarias x (n-1) (borra x map)

-- ---------------------------------------------------------------------
-- Ejercicio 8. Definir la funciÃ³n
--    borraTodas :: Ord a => a -> MultiConj a -> MultiConj a
-- tal que (borraTodas x m) es el multiconjunto obtenido a partir del
-- m borrando todas las ocurrencias del elemento x. Por ejemplo,
--    ghci> borraTodas 'a' (listaAmc "ababcad")
--    fromList [('b',2),('c',1),('d',1)]
-- ---------------------------------------------------------------------

borraTodas :: Ord a => a -> MultiConj a -> MultiConj a
borraTodas x map = M.delete x map

-- ---------------------------------------------------------------------
-- Consultas                                                          --
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 9. Definir la funciÃ³n 
--    esVacio :: MultiConj a -> Bool
-- tal que (esVacio m) se verifica si el multiconjunto m es vacÃ­o. Por
-- ejemplo, 
--    esVacio vacio  ==  True
--    esVacio (inserta 'a' vacio)  ==  False
-- ---------------------------------------------------------------------

esVacio :: MultiConj a -> Bool
esVacio map = M.null map

-- ---------------------------------------------------------------------
-- Ejercicio 10. Definir la funciÃ³n
--    cardinal :: MultiConj a -> Int
-- tal que (cardinal m) es el nÃºmero de elementos (contando las
-- repeticiones) del multiconjunto m. Por ejemplo,
--    cardinal (listaAmc "ababcad")  ==  7
-- ---------------------------------------------------------------------

cardinal :: MultiConj a -> Int
cardinal map = M.foldr (+) 0 map

-- cardinal map = sum (M.elems map)
-- con M.elems map, extraigo los valores de map devolviendo una lista

-- ---------------------------------------------------------------------
-- Ejercicio 11. Definir la funciÃ³n
--    cardDistintos :: MultiConj a -> Int
-- tal que (cardDistintos m) es el nÃºmero de elementos (sin contar las
-- repeticiones) del multiconjunto m. Por ejemplo,
--    cardDistintos (listaAmc "ababcad")  ==  4
-- ---------------------------------------------------------------------

cardDistintos :: MultiConj a -> Int
cardDistintos map = M.size map

-- ---------------------------------------------------------------------
-- Ejercicio 12. Definir la funciÃ³n
--    pertenece :: Ord a => a -> MultiConj a -> Bool
-- tal que (pertenece x m) se verifica si el elemento x pertenece al
-- multiconjunto m. Por ejemplo,
--    pertenece 'b' (listaAmc "ababcad")  ==  True
--    pertenece 'r' (listaAmc "ababcad")  ==  False
-- ---------------------------------------------------------------------

pertenece :: Ord a => a -> MultiConj a -> Bool
pertenece x map = M.member x map

-- ---------------------------------------------------------------------
-- Ejercicio 13. Definir la funciÃ³n
--    noPertenece :: Ord a => a -> MultiConj a -> Bool
-- tal que (noPertenece x m) se verifica si el elemento x no pertenece al
-- multiconjunto m. Por ejemplo,
--    noPertenece 'b' (listaAmc "ababcad")  ==  False
--    noPertenece 'r' (listaAmc "ababcad")  ==  True
-- ---------------------------------------------------------------------

noPertenece :: Ord a => a -> MultiConj a -> Bool
noPertenece x map = pertenece x map == False

-- ---------------------------------------------------------------------
-- Ejercicio 14. Definir la funciÃ³n
--    ocurrencias :: Ord a => a -> MultiConj a -> Int
-- tal que (ocurrencias x m) es el nÃºmero de ocurrencias de x en el
-- multiconjunto m. Por ejemplo,
--    ocurrencias 'a' (listaAmc "ababcad")  ==  3
--    ocurrencias 'r' (listaAmc "ababcad")  ==  0
-- ---------------------------------------------------------------------

ocurrencias :: Ord a => a -> MultiConj a -> Int
ocurrencias x map
                | M.member x map = map M.! x 
                | otherwise = 0

-- ---------------------------------------------------------------------
-- Ejercicio 15: Definir la funciÃ³n 
--    elementos :: Ord a => MultiConj a -> [a]
-- tal que (elementos m) es la lista de los elementos (sin repeticiones)
-- del multiconjunto m. Por ejemplo,
--    elementos (listaAmc "ababcad")  ==  "abcd"
-- ---------------------------------------------------------------------

elementos :: Ord a => MultiConj a -> [a]
elementos map = M.keys map

-- ---------------------------------------------------------------------
-- Ejercicio 16.Definir la funciÃ³n
--    esSubmultiConj :: Ord a => MultiConj a -> MultiConj a -> Bool
-- tal que (esSubmultiConj m1 m2) se verifica si m1 es un
-- submulticonjuto de m2 (es decir; los elementos de m1 pertenecen a m2
-- con un nÃºmro de ocurrencias igual o mayor). Por ejemplo,
--    ghci> let m1 = listaAmc "ababcad"
--    ghci> let m2 = listaAmc "bcbaadaa"
--    ghci> m1
--    fromList [('a',3),('b',2),('c',1),('d',1)]
--    ghci> m2
--    fromList [('a',4),('b',2),('c',1),('d',1)]
--    ghci> esSubmultiConj m1 m2
--    True
--    ghci> esSubmultiConj m2 m1
--    False
-- ---------------------------------------------------------------------

esSubmultiConj :: Ord a => MultiConj a -> MultiConj a -> Bool
esSubmultiConj m1Sub m2Con = contieneTodosM m2Con (elementos m1Sub) && elementosMenores m1Sub m2Con (elementos m1Sub)

contieneTodosM :: Ord a => MultiConj a -> [a] -> Bool
contieneTodosM m2Con [] = True
contieneTodosM m2Con (x:xs) = pertenece x m2Con && contieneTodosM m2Con xs

elementosMenores :: Ord a => MultiConj a -> MultiConj a -> [a] -> Bool
elementosMenores m1Sub m2Con [] = True
elementosMenores m1Sub m2Con (x:xs)= ocurrencias x m1Sub <= ocurrencias x m2Con && elementosMenores m1Sub m2Con xs
-- ---------------------------------------------------------------------
-- Operaciones: uniÃ³n, intersecciÃ³n y diferencia de multiconjuntos    --
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 17. Definir la funciÃ³n
--    union :: Ord a => MultiConj a -> MultiConj a -> MultiConj a
-- tal que (union m1 m2) es la uniÃ³n de los multiconjuntos m1 y m2. Por
-- ejemplo, 
--    ghci> let m1 = listaAmc "cdacba"
--    ghci> let m2 = listaAmc "acec"
--    ghci> m1
--    fromList [('a',2),('b',1),('c',2),('d',1)]
--    ghci> m2
--    fromList [('a',1),('c',2),('e',1)]
--    ghci> union m1 m2
--    fromList [('a',3),('b',1),('c',4),('d',1),('e',1)]
-- ---------------------------------------------------------------------

union :: Ord a => MultiConj a -> MultiConj a -> MultiConj a
union m1 m2 = M.unionWith (+) m1 m2

-- ---------------------------------------------------------------------
-- Ejercicio 18. Definir la funciÃ³n
--    unionG :: Ord a => [MultiConj a] -> MultiConj a
-- tal que (unionG ms) es la uniÃ³n de la lista de multiconjuntos ms. Por
-- ejemplo, 
--    ghci> unionG (map listaAmc ["aba", "cda", "bdb"])
--    fromList [('a',3),('b',3),('c',1),('d',2)]
-- ---------------------------------------------------------------------

unionG :: Ord a => [MultiConj a] -> MultiConj a
unionG [] = vacio
unionG (m:ms) = union m (unionG ms)

-- ---------------------------------------------------------------------
-- Ejercicio 19. Definir la funciÃ³n
--    diferencia :: Ord a => MultiConj a -> MultiConj a -> MultiConj a
-- tal que (diferencia m1 m2) es la diferencia de los multiconjuntos m1
-- y m2. Por ejemplo,
--    ghci> diferencia (listaAmc "abacc") (listaAmc "dcb")
--    fromList [('a',2),('c',1)]
-- ---------------------------------------------------------------------

diferencia :: Ord a => MultiConj a -> MultiConj a -> MultiConj a
diferencia m1 m2 = M.filter (>0) (restaUnion m1 (borraResta (noContiene m1 m2) m2))

borraResta :: Ord a => [a] -> MultiConj a -> M.Map a Int
borraResta [] map = map
borraResta [x] map = borraTodas x map
borraResta (x:xs) map = borraResta xs (borraTodas x map)

noContiene :: Ord a => MultiConj a -> MultiConj a -> [a]
noContiene m1 m2 = [ x | x <- elementos m2 , elem x (elementos m1) == False]

restaUnion :: Ord a => MultiConj a -> MultiConj a -> MultiConj a
restaUnion m1 m2 = M.unionWith (-) m1 m2

-- ---------------------------------------------------------------------
-- Ejercicio 20. Definir la funciÃ³n
--    interseccion :: Ord a => MultiConj a -> MultiConj a -> MultiConj a
-- tal que (interseccion m1 m2) es la intersecciÃ³n de los multiconjuntos
-- m1 y m2. Por ejemplo,
--    ghci> interseccion (listaAmc "abcacc") (listaAmc "bdcbc")
--    fromList [('b',1),('c',2)]
-- ---------------------------------------------------------------------

interseccion :: Ord a => MultiConj a -> MultiConj a -> MultiConj a
interseccion m1 m2 = auxInterseccion m1 m2 (contienen m1 m2)

contienen :: Ord a => MultiConj a -> MultiConj a -> [a]
contienen m1 m2 = [ x | x <- elementos m2 , elem x (elementos m1)]

auxInterseccion :: Ord a => MultiConj a -> MultiConj a -> [a] -> MultiConj a
auxInterseccion m1 m2 [] = vacio
auxInterseccion m1 m2 (x:xs) = M.insert x (min (m1 M.! x) (m2 M.! x)) (auxInterseccion m1 m2 xs)
-- ---------------------------------------------------------------------
-- Filtrado y particiÃ³n                                               --
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 21. Definir la funciÃ³n
--    filtra :: Ord a => (a -> Bool) -> MultiConj a -> MultiConj a
-- tal que (filtra p m) es el multiconjunto de los elementos de m que
-- verifican la propiedad p. Por ejemplo,
--    ghci> filtra (>'b') (listaAmc "abaccaded") 
--    fromList [('c',2),('d',2),('e',1)]
-- ---------------------------------------------------------------------

filtra :: Ord a => (a -> Bool) -> MultiConj a -> MultiConj a
filtra p map = auxFiltra p map (elementos map)

auxFiltra :: Ord a => (a -> Bool) -> MultiConj a -> [a] -> MultiConj a
auxFiltra p map [] = vacio
auxFiltra p map (x:xs)
                    | p x = M.insert x (map M.! x) (auxFiltra p map xs)
                    | otherwise = (auxFiltra p map xs)

-- ---------------------------------------------------------------------
-- FunciÃ³n aplicativa                                                 --
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 22. Definir la funciÃ³n
--    mapMC :: Ord b => (a -> b) -> MultiConj a -> MultiConj b
-- tal que (mapMC f m) es el multiconjunto obtenido aplicando la funciÃ³n
-- f a todos los  elementos de m. Por ejemplo,
--    ghci> mapMC (:"N") (listaAmc "abaccaded") 
--    fromList [("aN",3),("bN",1),("cN",2),("dN",2),("eN",1)]
-- ---------------------------------------------------------------------

mapMC :: (Ord a, Ord b) => (a -> b) -> MultiConj a -> MultiConj b
mapMC f map= auxMapMC f map (elementos map)

auxMapMC :: (Ord a, Ord b) => (a -> b) -> MultiConj a -> [a] -> MultiConj b
auxMapMC f map [] = vacio
auxMapMC f map (x:xs) = M.insert (f x) (map M.! x) (auxMapMC f map xs)

-- ---------------------------------------------------------------------
-- CreaciÃ³n del mÃ³dulo
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Ejercicio 23. Redefine la forma en que se imprime una expresiÃ³n de
-- tipo multiconjunto para que, por ejemplo, el multiconjunto:
-- [("a",3),("b",1)] se escriba como "a*3,b*1"
-- ---------------------------------------------------------------------


-- ---------------------------------------------------------------------
-- Ejercicio 24. Incluye el cÃ³digo necesario en este fichero para que sea
-- un mÃ³dulo donde solo se permita el uso de las funciones definidas,
-- ocultando los detalles de implementaciÃ³n, definiendo de tal forma el 
-- TAD de los multiconjuntos.
-- ---------------------------------------------------------------------


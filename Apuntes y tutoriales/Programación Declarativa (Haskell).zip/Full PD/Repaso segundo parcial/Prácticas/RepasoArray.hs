import Data.Array
import Data.List

type Vector a = Array Int a
type Matriz a = Array (Int,Int) a

-- ---------------------------------------------------------------------
-- Ejercicio 9. Definir la función 
--    esSimetrica :: Eq a => Matriz a -> Bool
-- tal que (esSimetrica p) se verifica si p es una matriz simétrica.
-- Por ejemplo,
--    ghci> esSimetrica (listArray ((1,1),(3,3)) [1,2,3,2,4,5,3,5,6])
--    True
--    ghci> esSimetrica (listArray ((1,1),(3,3)) [1,2,3,4,5,6,7,8,9])
--    False

-- ---------------------------------------------------------------------

esSimetrica :: (Eq a, Num a) => Matriz a -> Bool
esSimetrica m = and [ x == y| (x,y) <- zip (elementosBajoDiagonal m) (elementosSobreDiagonal m)]

elementosBajoDiagonal :: (Eq a, Num a) => Matriz a -> [a]
elementosBajoDiagonal m = concat[[(filaMatriz m x)!x' | x' <- range(bounds(filaMatriz m x)), x'< x ]
    | x <- range(1,f1)]
    where (ini,(f1,f2)) = bounds m

elementosSobreDiagonal :: (Eq a, Num a) => Matriz a -> [a]
elementosSobreDiagonal m = concat[[(filaMatriz m x)!x' | x' <- range(bounds(filaMatriz m x)), x'> x ]
    | x <- range(1,f1)]
    where (ini,(f1,f2)) = bounds m

filaMatriz :: (Eq a, Num a) => Matriz a -> Int -> Vector a
filaMatriz m i = listArray (1,f2) [m!(x,y)| (x,y) <- range(bounds m), x == i]
    where (ini,(f1,f2)) = bounds m

-- ---------------------------------------------------------------------
-- Ejercicio 10. Definir la función 
--    traspuesta :: Ix a => Array (a,a) b -> Array (a,a) b
-- tal que (traspuesta m) es la matriz traspuesta de m. Por ejemplo,
--    ghci> traspuesta (listArray ((1,1),(2,3)) [1,2,3,4,5,6])
--    array ((1,1),(3,2)) [((1,1),1),((1,2),4),((2,1),2),((2,2),5),((3,1),3),((3,2),6)]

-- ---------------------------------------------------------------------

traspuesta m = listArray (ini,(f2,f1)) (concat[[(columnaMatriz m x)!x'|x' <- range(bounds(columnaMatriz m x))]|
    x <- range(1,f2)])
    where (ini,(f1,f2)) = bounds m
    
columnaMatriz m j = listArray (1,f1) [m!(x,y) | (x,y) <- range(bounds m), y == j]
    where (ini,(f1,f2)) = bounds m

traspuesta' m = array (ini,(f2,f1)) [((y,x),m!(x,y))| (x,y) <- range(bounds m)]
    where (ini,(f1,f2)) = bounds m
    
-- ---------------------------------------------------------------------
-- Ejercicio 11. Definir la función 
--    sumaMatrices :: Num a => Matriz a -> Matriz a -> Matriz a
-- tal que (sumaMatrices m1 m2) es la suma de las matrices m1 y m2. Por ejemplo,
--    ghci> sumaMatrices (listArray ((1,1),(2,2)) [1,2,3,4]) (listArray ((1,1),(2,2)) [5,6,7,8])
--    array ((1,1),(2,2)) [((1,1),6),((1,2),8),((2,1),10),((2,2),12)]

-- ---------------------------------------------------------------------

sumaMatrices m1 m2 = listArray (bounds m1) [m1!x + m2!x | x <- range (bounds m1)]

-- ---------------------------------------------------------------------
-- Ejercicio 12. Definir la función 
--    productoMatrices :: Num a => Matriz a -> Matriz a -> Matriz a
-- tal que (productoMatrices m1 m2) es el producto de las matrices m1 y m2. Por ejemplo,
--    ghci> productoMatrices (listArray ((1,1),(2,2)) [1,2,3,4]) (listArray ((1,1),(2,2)) [5,6,7,8])
--    array ((1,1),(2,2)) [((1,1),19),((1,2),22),((2,1),43),((2,2),50)]

-- ---------------------------------------------------------------------

productoMatrices m1 m2 = listArray (ini1,(nfil1,ncol2)) [productVectores (filaMatriz m1 x) (columnaMatriz m2 y) |
    (x,y) <- range(bounds m1)]
    where 
        (ini1,(nfil1,ncol1)) = bounds m1
        (ini2,(nfil2,ncol2)) = bounds m2

productVectores v1 v2 = sum [v1!x * v2!x | x <- range(bounds v1)]
    where (i,f) = bounds v1
-- ---------------------------------------------------------------------
-- Ejercicio 13. Definir la función 
--    diagonalPrincipal :: Matriz a -> [a]
-- tal que (diagonalPrincipal m) es la lista de los elementos de la diagonal principal de m. Por ejemplo,
--    ghci> diagonalPrincipal (listArray ((1,1),(3,3)) [1,2,3,4,5,6,7,8,9])
--    [1,5,9]
-- ---------------------------------------------------------------------

diagonalPrincipal m = [m!(x,y)| (x,y) <- range(bounds m), x == y]
-- ---------------------------------------------------------------------
-- Ejercicio 14. Definir la función 
--    diagonalSecundaria :: Matriz a -> [a]
-- tal que (diagonalSecundaria m) es la lista de los elementos de la diagonal secundaria de m. Por ejemplo,
--    ghci> diagonalSecundaria (listArray ((1,1),(3,3)) [1,2,3,4,5,6,7,8,9])
--    [3,5,7]

-- ---------------------------------------------------------------------
diagonalSecundaria m = [m!x| x <- (indicesDiagonalSec m) ]

indicesDiagonalSec m = [(x,y)| (x,y) <- zip [1..f1] (reverse[1..f1])]
    where (ini,(f1,f2)) = bounds m

-- La diagonal secundaria es relativa, yo voy a tomarla como la inversa de la principal

-- ---------------------------------------------------------------------
-- Ejercicio 15. Definir la función 
--    esIdentidad :: (Num a, Eq a) => Matriz a -> Bool
-- tal que (esIdentidad m) se verifica si m es una matriz identidad. Por ejemplo,
--    ghci> esIdentidad (listArray ((1,1),(3,3)) [1,0,0,0,1,0,0,0,1])
--    True
--    ghci> esIdentidad (listArray ((1,1),(3,3)) [1,0,0,0,2,0,0,0,1])
--    False
-- ---------------------------------------------------------------------

esIdentidad m = and [if x == y then m!(x,y)== 1 else m!(x,y)== 0 | (x,y) <- range(bounds m)]
-- ---------------------------------------------------------------------
-- Ejercicio 16. Definir la función 
--    sumaFilas :: Num a => Matriz a -> Vector a
-- tal que (sumaFilas m) es el vector de las sumas de las filas de m. Por ejemplo,
--    ghci> sumaFilas (listArray ((1,1),(2,3)) [1,2,3,4,5,6])
--    array (1,2) [(1,6),(2,15)]
-- ---------------------------------------------------------------------

sumaFilas m = listArray (1,f1) [sum [ (filaMatriz m x)!x' | x' <- range(bounds(filaMatriz m x))]| x <- range(1,f1)]
    where (ini,(f1,f2)) = bounds m

-- ---------------------------------------------------------------------
-- Ejercicio 17. Definir la función 
--    sumaColumnas :: Num a => Matriz a -> Vector a
-- tal que (sumaColumnas m) es el vector de las sumas de las columnas de m. Por ejemplo,
--    ghci> sumaColumnas (listArray ((1,1),(2,3)) [1,2,3,4,5,6])
--    array (1,3) [(1,5),(2,7),(3,9)]
-- ---------------------------------------------------------------------

sumaColumnas m = listArray (1,f2) [sum [ (columnaMatriz m x)!x' | x' <- range(bounds(columnaMatriz m x))]| x <- range(1,f2)]
    where (ini,(f1,f2)) = bounds m
-- ---------------------------------------------------------------------
-- Ejercicio 18. Definir la función 
--    esCuadrada :: Matriz a -> Bool
-- tal que (esCuadrada m) se verifica si m es una matriz cuadrada. Por ejemplo,
--    ghci> esCuadrada (listArray ((1,1),(2,2)) [1,2,3,4])
--    True
--    ghci> esCuadrada (listArray ((1,1),(2,3)) [1,2,3,4,5,6])
--    False
-- ---------------------------------------------------------------------

esCuadrada m = f1 == f2
        where (ini,(f1,f2)) = bounds m
-- ---------------------------------------------------------------------
-- Ejercicio 19. Definir la función 
--    esDiagonal :: (Num a, Eq a) => Matriz a -> Bool
-- tal que (esDiagonal m) se verifica si m es una matriz diagonal. Por ejemplo,
--    ghci> esDiagonal (listArray ((1,1),(3,3)) [1,0,0,0,2,0,0,0,3])
--    True
--    ghci> esDiagonal (listArray ((1,1),(3,3)) [1,0,0,4,2,0,0,0,3])
--    False
-- ---------------------------------------------------------------------

esDiagonal m = and [if x == y then m!(x,y)/=0 else m!(x,y)==0 | (x,y) <- range(bounds m)]
-- ---------------------------------------------------------------------
-- Ejercicio 20. Definir la función 
--    esNula :: (Num a, Eq a) => Matriz a -> Bool
-- tal que (esNula m) se verifica si todos los elementos de m son nulos. Por ejemplo,
--    ghci> esNula (listArray ((1,1),(2,2)) [0,0,0,0])
--    True
--    ghci> esNula (listArray ((1,1),(2,2)) [0,1,0,0])
--    False
-- ---------------------------------------------------------------------

esNula m = and [m!(x,y) == 0| (x,y) <- range(bounds m)]
-- ---------------------------------------------------------------------
-- Ejercicio 21. Definir la función 
--    esOrtogonal :: (Fractional a, Eq a) => Matriz a -> Bool
-- tal que (esOrtogonal p) se verifica si p es una matriz ortogonal.
-- Por ejemplo,
--    ghci> esOrtogonal (listArray ((1,1),(2,2)) [1,0,0,1])
--    True
--    ghci> esOrtogonal (listArray ((1,1),(2,2)) [1,1,1,1])
--    False
-- ---------------------------------------------------------------------

esOrtogonal m = esIdentidad (productoMatrices m (traspuesta m))

-- Ejercicio 23. Definir la función 
--    determinante :: Num a => Matriz a -> a
-- tal que (determinante p) es el determinante de la matriz p. Por ejemplo,
--    ghci> determinante (listArray ((1,1),(2,2)) [1,2,3,4])
--    -2
-- ---------------------------------------------------------------------
determinante m
            | snd (bounds m) == (1,1) = m!(1,1)
            | otherwise = sum [(-1)^(x-1) * (m!(1,x) * (determinante (submatriz m 1 x))) | x <- range((1,f2))]
                 where (ini,(f1,f2)) = bounds m

submatriz m i j = listArray (ini,(f1-1,f2-1)) [m!(x,y) | (x,y) <- range(bounds m), i /= x && j /= y]
    where (ini,(f1,f2)) = bounds m
-- ---------------------------------------------------------------------
-- Ejercicio 22. Definir la función 
--    inversa :: (Fractional a, Eq a) => Matriz a -> Matriz a
-- tal que (inversa p) es la matriz inversa de p. Por ejemplo,
--    ghci> inversa (listArray ((1,1),(2,2)) [1,0,0,1])
--    array ((1,1),(2,2)) [((1,1),1),((1,2),0),((2,1),0),((2,2),1)]
-- ---------------------------------------------------------------------

inversa m = listArray (bounds m)   [(traspuesta (matrizAdjunta m))!(x,y) / deter| (x,y) <- range(bounds m)]
    where 
        deter = determinante m

matrizAdjunta m = listArray (bounds m) [(-1)^(x+y) * determinante (submatriz m x y) | (x,y) <- range(bounds m)]
             where (ini,(f1,f2)) = bounds m

-- ---------------------------------------------------------------------
-- Ejercicio 24. Definir la función 
--    cofactores :: Num a => Matriz a -> Matriz a
-- tal que (cofactores p) es la matriz de cofactores de p. Por ejemplo,
--    ghci> cofactores (listArray ((1,1),(2,2)) [1,2,3,4])
--    array ((1,1),(2,2)) [((1,1),4),((1,2),-2),((2,1),-3),((2,2),1)]
-- ---------------------------------------------------------------------

cofactores m = traspuesta (matrizAdjunta m)
-- ---------------------------------------------------------------------
-- Ejercicio 25. Definir la función 
--    adjunta :: Num a => Matriz a -> Matriz a
-- tal que (adjunta p) es la matriz adjunta de p. Por ejemplo,
--    ghci> adjunta (listArray ((1,1),(2,2)) [1,2,3,4])
--    array ((1,1),(2,2)) [((1,1),4),((1,2),-3),((2,1),-2),((2,2),1)]
-- ---------------------------------------------------------------------

adjunta m = matrizAdjunta m

-- ---------------------------------------------------------------------
-- Ejercicio 26. Definir la función 
--    esSingular :: (Fractional a, Eq a) => Matriz a -> Bool
-- tal que (esSingular p) se verifica si p es una matriz singular. Por ejemplo,
--    ghci> esSingular (listArray ((1,1),(2,2)) [1,2,3,4])
--    False
--    ghci> esSingular (listArray ((1,1),(2,2)) [1,2,2,4])
--    True
-- ---------------------------------------------------------------------

esSingular m = determinante m == 0
-- ---------------------------------------------------------------------
-- Ejercicio 27. Definir la función 
--    rango :: (Fractional a, Eq a) => Matriz a -> Int
-- tal que (rango p) es el rango de la matriz p. Por ejemplo,
--    ghci> rango (listArray ((1,1),(2,2)) [1,2,3,4])
--    2
--    ghci> rango (listArray ((1,1),(2,2)) [1,2,2,4])
--    1
-- ---------------------------------------------------------------------
rango m
    | determinante m /= 0 = min f1 f2
    | otherwise = maximum [rango (submatriz m x y) | (x, y) <- range (bounds m)]
    where
        (_, (f1, f2)) = bounds m

-- Si el determinante de m es distinto de 0 el rango es el mínimo de los límites, sino hay que probar con las submatrices

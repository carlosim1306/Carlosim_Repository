package io.camunda.getstarted;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import io.camunda.zeebe.client.ZeebeClient;
import io.camunda.zeebe.client.api.response.ProcessInstanceEvent;

public class CallWorker {

  private static final Logger LOG = LogManager.getLogger(CallWorker.class);

  public static void main(String[] args) {
    try (ZeebeClient client = ZeebeClientFactory.getZeebeClient()) {
      client.newWorker().jobType("CandidaturaJuegosOlimpicos").handler((jobClient, job) -> {
        LOG.info("Starting process 'CandidaturaJuegosOlimpicos'");

        jobClient.newCompleteCommand(job.getKey()).send()
          .whenComplete((result, exception) -> {
            if (exception == null) {
              startSecondaryProcess(client, "CandidaturaJuegosOlimpicos");
              LOG.info("Completed job and started 'CandidaturaJuegosOlimpicos' process");
            } else {
              LOG.error("Failed to complete job", exception);
            }
          });
      }).open();

      client.newWorker().jobType("ContinuaFase").handler((jobClient, job) -> {
        LOG.info("Starting process 'ContinuaFase'");

        jobClient.newCompleteCommand(job.getKey()).send()
          .whenComplete((result, exception) -> {
            if (exception == null) {
              startSecondaryProcess(client, "ContinuaFase");
              LOG.info("Completed job and started 'ContinuaFase' process");
            } else {
              LOG.error("Failed to complete job", exception);
            }
          });
      }).open();

      // run until System.in receives exit command
      waitUntilSystemInput("exit");
    }
  }

  private static void startSecondaryProcess(ZeebeClient client, String bpmnProcessId) {
    ProcessInstanceEvent event = client.newCreateInstanceCommand()
      .bpmnProcessId(bpmnProcessId)
      .latestVersion()
      .send()
      .join();

    LOG.info("Started process '{}' with key: {}", bpmnProcessId, event.getProcessInstanceKey());
  }

  private static void waitUntilSystemInput(final String exitCode) {
    try (final Scanner scanner = new Scanner(System.in)) {
      while (scanner.hasNextLine()) {
        final String nextLine = scanner.nextLine();
        if (nextLine.contains(exitCode)) {
          return;
        }
      }
    }
  }
}

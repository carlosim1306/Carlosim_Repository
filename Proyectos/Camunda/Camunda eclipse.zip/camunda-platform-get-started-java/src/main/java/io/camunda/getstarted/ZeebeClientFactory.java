package io.camunda.getstarted;

import io.camunda.zeebe.client.ZeebeClient;

public class ZeebeClientFactory {

  public static ZeebeClient getZeebeClient() {
    return ZeebeClient.newCloudClientBuilder()
        .withClusterId("25083b0f-78e5-4c06-b425-74b0402931c1")
        .withClientId("KXBxY0pnRTaj2_V14PvKTE0KZ2NvYAkP")
        .withClientSecret("OYTejHEOLZXd~sz.KtOE-5OGqxzu3VpEUdsXJGC~_SD4WaAzgXzwgBctwewtqNQq")
        .withRegion("bru-2")
        .build();
  }

}
package io.camunda.getstarted;

import io.camunda.zeebe.client.ZeebeClient;
import io.camunda.zeebe.client.api.response.ProcessInstanceEvent;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DeployAndStartInstance {

  private static final Logger LOG = LogManager.getLogger(DeployAndStartInstance.class);

  public static void main(String[] args) {
    // Primero añadimos todos los procesos que vamos a usar
    try (ZeebeClient client = ZeebeClientFactory.getZeebeClient()) {
      client.newDeployResourceCommand()
        .addResourceFromClasspath("SolicitarCandidatura.bpmn")
        .addResourceFromClasspath("CandidaturaJuegosOlimpicos.bpmn")
        .addResourceFromClasspath("ContinuaFase.bpmn")
        .send()
        .join();

      final ProcessInstanceEvent event = client.newCreateInstanceCommand()
        .bpmnProcessId("SolicitarCandidatura")
        .latestVersion()
        .variables(Map.of("message_content", "Hello from the Java get started"))
        .send()
        .join();

      LOG.info(
        "Started instance for processDefinitionKey='{}', bpmnProcessId='{}', version='{}' with processInstanceKey='{}'",
        event.getProcessDefinitionKey(), event.getBpmnProcessId(), event.getVersion(),
        event.getProcessInstanceKey());
    }
  }
}

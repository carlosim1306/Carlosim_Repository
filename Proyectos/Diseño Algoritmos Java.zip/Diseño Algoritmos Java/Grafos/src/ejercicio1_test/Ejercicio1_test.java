package ejercicio1_test;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.jgrapht.Graph;
import org.jgrapht.alg.connectivity.ConnectivityInspector;
import org.jgrapht.alg.interfaces.VertexCoverAlgorithm.VertexCover;
import org.jgrapht.alg.vertexcover.GreedyVCImpl;

import ejercicio1.Ejercicio1;
import ejercicio1.Interaccion;
import ejercicio1.Usuario;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.Graphs2;
import us.lsi.graphs.GraphsReader;

public class Ejercicio1_test {
	
/*---------------------------------------Lectura de grafos------------------------------------*/
	
	public static Graph<Usuario, Interaccion> leerGrafo(String file){
		Graph<Usuario, Interaccion> g = GraphsReader.newGraph(file,//ruta del fichero
				Usuario::ofFormat, // método de factoría de los vértices
				Interaccion::ofFormat, // método de factoría de las aristas
				Graphs2::simpleDirectedWeightedGraph,
				Interaccion::interaccion);
		return g;
	}
	
	public static Graph<Usuario, Interaccion> leerGrafoNoDirigido(String file){
		Graph<Usuario, Interaccion> g = GraphsReader.newGraph(file,//ruta del fichero
				Usuario::ofFormat, // método de factoría de los vértices
				Interaccion::ofFormat, // método de factoría de las aristas
				Graphs2::simpleGraph);
		return g;
	}
	
	
/*-------------------------------------Código del apartado A-----------------------------------*/
	
	public static void testEjercicio1A(Graph<Usuario, Interaccion> g, String nombre) {
		
		List<Usuario> listaVertices = g.vertexSet().stream()
				.filter(x -> x.actividad()>2.5 && g.outDegreeOf(x)>3)
				.toList();
		
		List<Interaccion> listaAristas = g.edgeSet().stream()
				.filter(x -> g.getEdgeTarget(x).actividad() > 2.5 &&
						g.getEdgeSource(x).actividad() > 2.5 &&
						g.outDegreeOf(g.getEdgeTarget(x))>3 &&
						g.outDegreeOf(g.getEdgeSource(x))>3)
				.toList();
		
		GraphColors.toDot(g, "fichero/" + nombre + ".gv", // ruta al fichero resultado
				v -> v.nombre(),//cómo pinta los vértices
				e -> e.interaccion().toString(),//cómo pinta las aristas
				v -> GraphColors.colorIf(Color.cyan,
						listaVertices.contains(v)),//estilo vértice
				e -> GraphColors.colorIf(Color.cyan,
						listaAristas.contains(e)));//estilo arista
		
		System.out.println("Se ha generado el fichero del grafo del ejemplo1 apartado A");
	}
	
	public static void testEjemplo1(String file) {
		Graph<Usuario, Interaccion> g = leerGrafo(file);
		
		Predicate<Usuario> pv = v -> g.containsVertex(v);
		Predicate<Interaccion> pa = e -> g.containsEdge(e);
		Graph<Usuario, Interaccion> vista = Ejercicio1.vistaEjercicio1(g, pv, pa);
	
		testEjercicio1A(vista, "ejercicio1ApartadoA");
	}
	
/*--------------------------------------------Código apartado B--------------------------------------- */
	
	
	public static void testEjercicio1B(Graph<Usuario, Interaccion> g, String nombre) {
		
		var alg = new ConnectivityInspector<>(g); //algoritmo para componentes conexas
		List<Set<Usuario>> ls = alg.connectedSets();
		Set<String> lsConexa1 = new HashSet<String>();
		Set<String> lsConexa2 = new HashSet<String>();
		
		for (Usuario us : ls.get(0)) {
			lsConexa1.add(us.nombre());
		}
		for (Usuario us : ls.get(1)) {
			lsConexa2.add(us.nombre());
		}
		
		System.out.println("Hay " + ls.size() + " componente (s) conexa (s)." );
		System.out.println("La componente conexa 1, está formada por los usuarios: " +
		lsConexa1);
		System.out.println("La componente conexa 2, está formada por los usuarios: " +
		lsConexa2);
		
		GraphColors.toDot(g, "fichero/" + nombre + ".gv", // ruta al fichero resultado
				v -> v.nombre(),//cómo pinta los vértices
				e -> e.interaccion().toString(),//cómo pinta las aristas
				v->GraphColors.color(asignaColor(v,ls,alg)),
				e->GraphColors.color(asignaColor(g.getEdgeSource(e), ls, alg)));
		
		
		System.out.println("Se ha generado el fichero del grafo del ejemplo1 apartado B");
	}

	private static Color asignaColor(Usuario v, List<Set<Usuario>> ls, 
			ConnectivityInspector<Usuario, Interaccion> alg) {
		Color[] vc = Color.values();
		// Mete todos los colores en un array
		Set<Usuario> s = alg.connectedSetOf(v);
		// Mete el conjunto de vertices de la componente conexa
		return vc[ls.indexOf(s)];
		// Asigno un color a cada componente conexa en función de la posición que ocupa en la lista conexa
	}
	
	public static void testEjemplo2(String file) {
		Graph<Usuario, Interaccion> g = leerGrafoNoDirigido(file);
		
		Predicate<Usuario> pv = v -> g.containsVertex(v);
		Predicate<Interaccion> pa = e -> g.containsEdge(e);
		Graph<Usuario, Interaccion> vista = Ejercicio1.vistaEjercicio1(g, pv, pa);
	
		testEjercicio1B(vista, "ejercicio1ApartadoB");
	}
	
/*--------------------------------------------Código apartado C--------------------------------------- */
	
	public static void testEjercicio1C(Graph<Usuario, Interaccion> g, String nombre) {
		
		var alg = new GreedyVCImpl<Usuario, Interaccion>(g); //algoritmo para tomar el mínimo de vértices para cubrir todas las aristas
		VertexCover<Usuario> verticesCubiertos = alg.getVertexCover();
		System.out.println(verticesCubiertos.stream().map(x->x.nombre()).toList());
		GraphColors.<Usuario,Interaccion>toDot(g,"fichero/" + nombre + ".gv",
				v -> v.nombre(),//cómo pinta los vértices
				e -> e.interaccion().toString(),//cómo pinta las aristas
				v->GraphColors.colorIf(Color.green,Color.black,verticesCubiertos.contains(v)),
				e->GraphColors.color(Color.black));
		
		System.out.println("Se ha generado el fichero del grafo del ejemplo1 apartado C");

	}	
	public static void testEjemplo3(String file) {
		Graph<Usuario, Interaccion> g = leerGrafoNoDirigido(file);
		
		Predicate<Usuario> pv = v -> g.containsVertex(v);
		Predicate<Interaccion> pa = e -> g.containsEdge(e);
		Graph<Usuario, Interaccion> vista = Ejercicio1.vistaEjercicio1(g, pv, pa);
	
		testEjercicio1C(vista, "ejercicio1ApartadoC");
	}

 /*--------------------------------------------Código apartado D--------------------------------------- */
	
	public static void testEjercicio1D(Graph<Usuario, Interaccion> g, String nombre) {

		List<String> filtroVertices = g.vertexSet().stream()
				.filter(x -> x.actividad()>4 && x.aficiones().size()>3 && g.inDegreeOf(x)>=5)
				.map(x -> x.nombre())
				.toList();
		//filtramos los vértices que cumplen las condiciones dadas
		Map<String, Double> filtroInteracciones = g.edgeSet().stream()
				.filter(x -> filtroVertices.contains(x.nombre2()))
				.collect(Collectors.groupingBy(Interaccion::nombre2,
						Collectors.averagingDouble(x -> x.interaccion())));
		//Tomamos las aristas cuyo vértice destino está en la lista de vértices filtrados y hacemos un map con 
		//el nombre del vértice y la media de la interacción de todas las aristas(podría haberlo hecho con un Pair)
		
		List<String> mayorInteraccion = Ejercicio1.auxInteraccion(g, filtroVertices, filtroInteracciones);
		
		System.out.println(mayorInteraccion);
		
		GraphColors.toDot(g, "fichero/" + nombre + ".gv", // ruta al fichero resultado
				v -> v.nombre(),//cómo pinta los vértices
				e -> e.interaccion().toString(),//cómo pinta las aristas
				v -> GraphColors.colorIf(Color.cyan,
						mayorInteraccion.contains(v.nombre()) == true),
				e -> GraphColors.color(Color.black));//estilo arista
		
		System.out.println("Se ha generado el fichero del grafo del ejemplo1 apartado D");
	}
	
	public static void testEjemplo4(String file) {
		Graph<Usuario, Interaccion> g = leerGrafo(file);
		
		Predicate<Usuario> pv = v -> g.containsVertex(v);
		Predicate<Interaccion> pa = e -> g.containsEdge(e);
		Graph<Usuario, Interaccion> vista = Ejercicio1.vistaEjercicio1(g, pv, pa);
	
		testEjercicio1D(vista, "ejercicio1ApartadoD");
	}

	public static void main(String[] args) {
		
//		testEjemplo1("fichero/ejercicio1_3.txt");	  
//		testEjemplo2("fichero/ejercicio1_3.txt");
//		testEjemplo3("fichero/ejercicio1_3.txt");
//		testEjemplo4("fichero/ejercicio1_3.txt");      
 

	}
}

package ejercicio2_test;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import org.jgrapht.Graph;
import org.jgrapht.GraphPath;
import org.jgrapht.alg.interfaces.ShortestPathAlgorithm;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.alg.tour.HeldKarpTSP;

import ejercicio2.Atraccion;
import ejercicio2.Ejercicio2;
import ejercicio2.Vecindad;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.Graphs2;
import us.lsi.graphs.GraphsReader;

public class Ejercicio2_test {
	
	public static Graph<Atraccion, Vecindad> leerGrafo(String file){
		Graph<Atraccion, Vecindad> g = GraphsReader.newGraph(file,//ruta del fichero
				Atraccion::ofFormat, // método de factoría de los vértices
				Vecindad::ofFormat, // método de factoría de las aristas
				Graphs2::simpleDirectedWeightedGraph,
				Vecindad::distancia);
		return g;
	}
	
	
	public static Graph<Atraccion, Vecindad> leerGrafo1(String file){
		Graph<Atraccion, Vecindad> g = GraphsReader.newGraph(file,//ruta del fichero
				Atraccion::ofFormat, // método de factoría de los vértices
				Vecindad::ofFormat, // método de factoría de las aristas
				Graphs2::simpleWeightedGraph,
				Vecindad::tiempoMedio);
		
		return g;
	}
	
/*-------------------------------------Código del apartado A-----------------------------------*/

	public static void testEjercicio2A(Graph<Atraccion, Vecindad> g, String nombre,
			String atraccion1, String atraccion2) {
		
		ShortestPathAlgorithm<Atraccion,Vecindad> a = new DijkstraShortestPath<Atraccion,Vecindad>(g);//algoritmo de camino mínimo dados dos vértices
		Atraccion from = Atraccion.atraccion(g,atraccion1);
		Atraccion to = Atraccion.atraccion(g,atraccion2);
		GraphPath<Atraccion,Vecindad> gp =  a.getPath(from,to);
		List<Atraccion> verticesParh = gp.getVertexList();
		List<Vecindad> aristasPath = gp.getEdgeList();
		System.out.println(verticesParh.stream().map(x -> x.nombre()).toList());
		
		GraphColors.toDot(g, "fichero/" + nombre + ".gv", // ruta al fichero resultado
				v -> v.nombre(),//cómo pinta los vértices
				e -> e.distancia().toString(),//cómo pinta las aristas
				v -> GraphColors.colorIf(Color.cyan,
						verticesParh.contains(v)),
				e -> GraphColors.colorIf(Color.cyan,
						aristasPath.contains(e)));//estilo arista
		
		System.out.println("Se ha generado el fichero del grafo del ejercicio 2 apartado A");
	}	
	public static void testEjemplo1(String file, String ciudad1, String ciudad2) {
		Graph<Atraccion, Vecindad> g = leerGrafo(file);
		
		Predicate<Atraccion> pv = v -> g.containsVertex(v);
		Predicate<Vecindad> pa = e -> g.containsEdge(e);
		Graph<Atraccion, Vecindad> vista = Ejercicio2.vistaEjercicio2(g, pv, pa);
	
		testEjercicio2A(vista, "ejercicio2ApartadoA", ciudad1, ciudad2);
	}

/*-------------------------------------Código del apartado B-----------------------------------*/
	
	public static void testEjercicio2B(Graph<Atraccion, Vecindad> g, String nombre) {
		
		var alg = new HeldKarpTSP<Atraccion, Vecindad>(); //algoritmo para el problema del viajante
		GraphPath<Atraccion, Vecindad> a = alg.getTour(g);
		List<Atraccion> verticesPath = a.getVertexList();
		List<Vecindad> aristasPath = a.getEdgeList();
		
		GraphColors.toDot(g, "fichero/" + nombre + ".gv", // ruta al fichero resultado
				v -> v.nombre(),//cómo pinta los vértices
				e -> e.distancia().toString(),//cómo pinta las aristas
				v -> GraphColors.color(asignaColor(v,verticesPath,a.getStartVertex())),
				e -> GraphColors.colorIf(Color.cyan,
						aristasPath.contains(e)));//estilo arista
		
		System.out.println("Se ha generado el fichero del grafo del ejercicio 2 apartado B");

	}
	
	private static Color asignaColor(Atraccion v, 
			List<Atraccion> ls, Atraccion primera) {
		if (v.equals(primera)) {
			return Color.red;
		} else if (ls.contains(v)) {
			return Color.cyan;
		} else {
			return Color.black;
		}
	}
	
	public static void testEjemplo2(String file) {
		Graph<Atraccion, Vecindad> g = leerGrafo1(file);
		
		Predicate<Atraccion> pv = v -> g.containsVertex(v);
		Predicate<Vecindad> pa = e -> g.containsEdge(e);
		Graph<Atraccion, Vecindad> vista = Ejercicio2.vistaEjercicio2(g, pv, pa);
	
		testEjercicio2B(vista, "ejercicio2ApartadoB");
	}
	
/*-------------------------------------Código del apartado C-----------------------------------*/

	public static void testEjercicio2C(Graph<Atraccion, Vecindad> g, String nombre, Double horasDisponibles) {
			
			List<Atraccion> listaVertices = Ejercicio2.recorridoPopular(g, horasDisponibles);
			System.out.println(listaVertices.stream().map(x-> x.nombre()).toList());
			List<Vecindad> listaAristas = new ArrayList<Vecindad>();
			Integer acc = listaVertices.size()-1;
			Integer contador = 0;
			while (acc > 0){
				listaAristas.add(g.getEdge(listaVertices.get(contador), listaVertices.get(contador+1)));
				contador ++;
				acc -=1 ;
			}
			GraphColors.toDot(g, "fichero/" + nombre + ".gv", // ruta al fichero resultado
					v -> v.nombre(),//cómo pinta los vértices
					e -> e.distancia().toString(),//cómo pinta las aristas
					v -> GraphColors.color(asignaColor(v, listaVertices, listaVertices.get(0))),
					e -> GraphColors.colorIf(Color.cyan,
							listaAristas.contains(e)));//estilo arista
			
			System.out.println("Se ha generado el fichero del grafo del ejercicio 2 apartado C");
	
		}	
	
	public static void testEjemplo3(String file, Double horasDisponibles) {
		Graph<Atraccion, Vecindad> g = leerGrafo1(file);
		
		Predicate<Atraccion> pv = v -> g.containsVertex(v);
		Predicate<Vecindad> pa = e -> g.containsEdge(e);
		Graph<Atraccion, Vecindad> vista = Ejercicio2.vistaEjercicio2(g, pv, pa);
	
		testEjercicio2C(vista, "ejercicio2ApartadoC", horasDisponibles);
	}
	
public static void main(String[] args) {
		
//		testEjemplo1("fichero/ejercicio2_3.txt", "Casa del Terror", "Pim pam pum");
//		testEjemplo2("fichero/ejercicio2_3.txt");
//		testEjemplo3("fichero/ejercicio2_3.txt", 180.0);
      
	}
}

package ejercicio2;

import org.jgrapht.Graph;

public record Atraccion(String nombre, Integer tiempoEspera, Double popularidad, Integer duracion) {

	public static Atraccion atraccion(Graph<Atraccion,Vecindad> graph, String nombre) {
		return graph.vertexSet().stream().filter(c->c.nombre().equals(nombre)).findFirst().get();
	}
	
	public static Atraccion ofFormat(String[] formato) {
		String nombre = formato[0];
		Integer tiempoEspera = Integer.parseInt(formato[1]);
		Double popularidad = Double.parseDouble(formato[2]);
		Integer duracion = Integer.parseInt(formato[3]);

		return new Atraccion(nombre,tiempoEspera, popularidad, duracion);
	}
	
	public static Atraccion of(String nombre, Integer tiempoEspera, Double popularidad, Integer duracion) {
		return new Atraccion(nombre,tiempoEspera,popularidad,duracion);
	}
}

package ejercicio2;

public record Vecindad(String nombre1, String nombre2, Double distancia, Double tiempoMedio) {
	
	public static Vecindad ofFormat(String[] formato) {
		String nombre1 = formato[0];
		String nombre2 = formato[1];
		Double distancia = Double.parseDouble(formato[2]);
		Double tiempoMedio = Double.parseDouble(formato[3]);
		return new Vecindad(nombre1,nombre2, distancia, tiempoMedio);
	}
	
	public static Vecindad of(String nombre1, String nombre2, Double distancia, Double tiempoMedio) {
		return new Vecindad(nombre1,nombre2,distancia,tiempoMedio);
	}

}

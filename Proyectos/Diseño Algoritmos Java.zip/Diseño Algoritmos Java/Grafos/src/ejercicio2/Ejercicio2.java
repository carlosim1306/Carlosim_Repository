package ejercicio2;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.jgrapht.Graph;

import us.lsi.graphs.views.SubGraphView;

public class Ejercicio2 {
	
	private record Pair<A,B> (A a, B b){}
	
	public static Graph<Atraccion, Vecindad> vistaEjercicio2(Graph<Atraccion, Vecindad> g,
			Predicate<Atraccion> pv, Predicate<Vecindad> pa) {
		
		Graph<Atraccion, Vecindad> vista = SubGraphView.of(g, //grafo
				v -> pv.test(v),//predicado sobre los vértices
				e -> pa.test(e)//predicado sobre las aristas
				);
		return vista;
	}

	public static List<Atraccion> recorridoPopular(Graph<Atraccion,Vecindad> g,
			Double horasDisponibles){
		
		List<Atraccion> res = new ArrayList<Atraccion>();
		
		Atraccion puntoPartida = g.vertexSet().stream().max(Comparator.comparing(Atraccion::popularidad)).get();
		//Tomamos la atracción con mayor popularidad, que será el punto de partida
		res.add(puntoPartida);
		
		return auxrecorridoPopular(g, horasDisponibles-puntoPartida.duracion()-puntoPartida.tiempoEspera(), puntoPartida, res);
		//hacemos la llamada recursiva teniendo en cuenta el tiempo que nos toma la primera atracción
	}
	
	private static List<Atraccion> auxrecorridoPopular(Graph<Atraccion, Vecindad> g, Double horasDisponibles,
			Atraccion nodoActual, List<Atraccion> res){

		Set<Vecindad> vecinos = g.edgesOf(nodoActual);
		//tomamos todas las aristas desde el punto actual
		
		Set<String> posiblesSiguientes= new HashSet<String>();
		for (Vecindad v : vecinos) {
			posiblesSiguientes.add(v.nombre1());
			posiblesSiguientes.add(v.nombre2());
		}
		//tomamos todos los vértices de las aristas para saber a cuales pueden ser las siguientes
		
		Set<Pair<Atraccion, Double>> siguientesAtraccionesPopularidad = g.vertexSet().stream()
				.filter(x -> posiblesSiguientes.contains(x.nombre()) && !x.nombre().equals(nodoActual) && !res.contains(x))
				.map(x -> new Pair<Atraccion,Double>(x,x.popularidad()))
				.collect(Collectors.toSet());
		//creamos un conjunto con todos los pares de atracciones y su popularidad, filtrando por las atracciones que
		//están en el conjunto de posiblesSiguientes, quitando el nodo actual y comprobando que no estén en la lista res
		
		Pair<Atraccion, Double> siguienteAtraccion = siguientesAtraccionesPopularidad.stream()
				.max(Comparator.comparing(Pair::b))
				.orElse(null);	
		//Tomamos el par con mayor popularidad del conjunto siguientesAtraccionesPopularidad, si está vacío devolvemos null
		
		if (Objects.isNull(siguienteAtraccion)) {
			return res;
			//si no hay siguienteAtraccion devolvemos la lista de atracciones
		} else {
			horasDisponibles -= (g.getEdge(nodoActual, siguienteAtraccion.a()).tiempoMedio()+siguienteAtraccion.a().duracion()+siguienteAtraccion.a().tiempoEspera());
			if (horasDisponibles < 0) {
				return res;
			//si excedemos las horas disponibles con los tiempos de las atracciones y la arista devolvemos la lista
			} else {
			res.add(siguienteAtraccion.a());
			return auxrecorridoPopular(g, horasDisponibles, siguienteAtraccion.a(), res);
			//si está dentro de tiempo añadimos la atracción y llamamos a la función con el nuevo res y con la atracción
			//siguiente como la actual
			}
		}
		
	}

}

package ejercicio3;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.jgrapht.Graph;

import us.lsi.graphs.views.SubGraphView;

public class Ejercicio3 {

	public static Graph<String, Arista> vistaEjercicio3(Graph<String, Arista> g, Predicate<String> pv,
			Predicate<Arista> pa) {
		
		Graph<String, Arista> vista = SubGraphView.of(g, //grafo
				v -> pv.test(v),//predicado sobre los vértices
				e -> pa.test(e)//predicado sobre las aristas
				);
		return vista;
	}
	
	public static List<String> ejercicio3b(Graph<String, Arista> g, String tareainicial){
		
		List<String> padres= g.incomingEdgesOf(tareainicial).stream().map(x -> g.getEdgeSource(x)).collect(Collectors.toList());
		//tomamos los padres teniendo en cuenta las aristas que le llegan y tomando el vértice de entrada de las aristas
		padres.addAll(padres.stream().map(x -> ejercicio3b(g, x)).flatMap(List::stream).collect(Collectors.toSet()));
		//añadimos a la lista de padres todos los padres pasándole a cada padre la llamada recursiva de la función
		//y aplanando las listas con flatMap
		return padres;
	}
	
	public static Set<String> ejercicio3c(Graph<String, Arista> g){

		Set<String> verticesIniciales = g.vertexSet().stream().filter(x -> g.inDegreeOf(x)==0).collect(Collectors.toSet());
		//creamos un cojunto con todos los vértices iniciales, que son aquellos que no tienen predecesores
		
		Map<String, Set<String>> mem = new HashMap<String, Set<String>>();
		//creamos un Map para usarlo de memoria
		
		Set<String> res = new HashSet<String>();
		Integer resTareas = 0;
		//creamos los valores de inicio
		
		for (String actual : verticesIniciales) {
			Integer numCriticasActual = calculaCriticas(g, actual, mem).size();
			//calculamos la ruta crítica para cada vértice inicial
			if(numCriticasActual > resTareas) {
				res = new HashSet<String>();
				res.add(actual);
				resTareas = numCriticasActual;
			//Si la nueva ruta crítica es mayor que el resTarea, se sustituye res por un set con el valor actual
				
			} else if (numCriticasActual == resTareas) {
				res.add(actual);
			//Si la nueva ruta es igual que el resTarea, se añade el nodo actual set res
			}
		}
		return res;
	}
	
	public static Set<String> calculaCriticas(Graph<String, Arista> g, String nodo, Map<String, Set<String>> mem){
			if (mem.containsKey(nodo))
				return mem.get(nodo);
			//caso base
			else {
				Set<String> hijos = g.outgoingEdgesOf(nodo).stream()
						.map(x -> g.getEdgeTarget(x))
						.collect(Collectors.toSet());
				//primero hacemos un conjunto con los hijos
				Set<String> sucesores = new HashSet<String>();
				sucesores.add(nodo);
				//añadimos el nodo al conjunto de sucesores
						
				for (String v: hijos) {
					Set<String> sucesores_v = calculaCriticas(g, v, mem);
					sucesores.addAll(sucesores_v);
					//a cada hijo le pasamos la función para después añadir los sucesores_v a set sucesores
				}				
				mem.put(nodo, sucesores);
				//actualizamos la memoria con el nodo y sus sucesores  
				return sucesores;
				//devolvemos el conjunto de sucesores
			}
	}
}

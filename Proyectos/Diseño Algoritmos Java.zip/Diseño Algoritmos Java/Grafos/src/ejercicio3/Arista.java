package ejercicio3;

public record Arista(String t1, String t2) {
	
	public static Arista ofFormat(String[] formato) {
		String t1 = formato[0];
		String t2 = formato[1];
		return new Arista(t1,t2);
	}
	
	public static Arista of(String t1, String t2) {
		return new Arista(t1,t2);
	}
}

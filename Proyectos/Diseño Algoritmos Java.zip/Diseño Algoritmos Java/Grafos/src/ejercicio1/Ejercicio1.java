package ejercicio1;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Predicate;

import org.jgrapht.Graph;

import us.lsi.graphs.views.SubGraphView;

public class Ejercicio1 {
	
	//control mayusc o -> importa todo

	public static Graph<Usuario, Interaccion> vistaEjercicio1(Graph<Usuario, Interaccion> g, 
			Predicate<Usuario> pv, Predicate<Interaccion> pa) {
		
		Graph<Usuario, Interaccion> vista = SubGraphView.of(g, //grafo
				v -> pv.test(v),//predicado sobre los vértices
				e -> pa.test(e)//predicado sobre las aristas
				);
		return vista;
	}
	
	public static List<String> auxInteraccion(Graph<Usuario, Interaccion> g, List<String> vertices,
			Map<String, Double> interacciones){
		List<String> res = new ArrayList<String>();
		//teniendo la lista de vértices tenemos dos casos, cuando hay más de dos vértices en la lista filtrada
		//y por lo tanto, ordenamos los map por la media de interacciones y tomamos los 2 mayores valores(devolvemos las keys)
		//el otro caso es cuando son menores o iguales a dos vértices por el cual devolvemos las keys directamente
		if (vertices.size()>2) {
			res = interacciones.entrySet().stream()
					.sorted(Comparator.comparing(Entry::getValue))
					.skip(interacciones.size()-2)
					.map(x -> x.getKey())
					.toList();
		} else {
			res = interacciones.entrySet().stream()
					.sorted(Comparator.comparing(Entry::getValue))
					.map(x -> x.getKey())
					.toList();
		}
		return res;
	}
}

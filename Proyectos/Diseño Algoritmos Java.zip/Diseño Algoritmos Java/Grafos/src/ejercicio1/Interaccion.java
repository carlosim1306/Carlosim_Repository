package ejercicio1;

public record Interaccion(String nombre1, String nombre2, Double interaccion) {
	
	public static Interaccion ofFormat(String[] formato) {
		String nombre1 = formato[0];
		String nombre2 = formato[1];
		Double interaccion = Double.parseDouble(formato[2]);
		return new Interaccion(nombre1,nombre2, interaccion);
	}
	
	public static Interaccion of(String nombre1, String nombre2, Double interaccion) {
		return new Interaccion(nombre1,nombre2, interaccion);
	}
	
}

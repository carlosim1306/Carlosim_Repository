package ejercicio1;

import java.util.HashSet;
import java.util.Set;


public record Usuario(String nombre, Double actividad, Set<String> aficiones) {

	public static Usuario ofFormat(String[] formato) {
		String nombre = formato[0];
		Double actividad = Double.parseDouble(formato[1]);
		Set<String> setAficiones = new HashSet<String>();
		String[] aficionesSplit = formato[2].split(";");
		for (String a : aficionesSplit) {
			setAficiones.add(a);
		}
		return new Usuario(nombre,actividad, setAficiones);
	}
	
	public static Usuario of(String nombre, Double actividad, Set<String> aficiones) {
		return new Usuario(nombre,actividad, aficiones);
	}
	
	
}

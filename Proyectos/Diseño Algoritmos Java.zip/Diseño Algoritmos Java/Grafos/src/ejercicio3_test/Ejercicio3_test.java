package ejercicio3_test;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

import org.jgrapht.Graph;
import org.jgrapht.traverse.TopologicalOrderIterator;

import ejercicio3.Arista;
import ejercicio3.Ejercicio3;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.Graphs2;
import us.lsi.graphs.GraphsReader;

public class Ejercicio3_test {

	public static Graph<String, Arista> leerGrafo(String file){
		Graph<String, Arista> g = GraphsReader.newGraph(file,//ruta del fichero
				s -> s[0], // método de factoría de los vértices
				Arista::ofFormat, // método de factoría de las aristas
				Graphs2::simpleDirectedGraph);
		return g;
	}

/*-------------------------------------Código del apartado A-----------------------------------*/
	
	public static void testEjercicio3A(Graph<String, Arista> g, String nombre) {
		
		TopologicalOrderIterator<String, Arista> it = new TopologicalOrderIterator<String,Arista>(g);//algoritmo para saber el orden de precedencia de tareas
		List<String> tareasOrdenTopologico = new ArrayList<String>();
		
		while(it.hasNext()) {
			tareasOrdenTopologico.add(it.next());
		}
		
		System.out.println(tareasOrdenTopologico);
	}
	
	public static void testEjemplo1(String file) {
		Graph<String, Arista> g = leerGrafo(file);
		
		Predicate<String> pv = v -> g.containsVertex(v);
		Predicate<Arista> pa = e -> g.containsEdge(e);
		Graph<String, Arista> vista = Ejercicio3.vistaEjercicio3(g, pv, pa);
	
		testEjercicio3A(vista, "ejercicio3ApartadoA");
	}
	
/*-------------------------------------Código del apartado B-----------------------------------*/
	
	public static void testEjercicio3B(Graph<String, Arista> g, String nombre, String tareaInicial) {
			
			List<String> listaVertices = Ejercicio3.ejercicio3b(g, tareaInicial);
			System.out.println("Las tareas a realizar antes son: "+listaVertices);
			
			GraphColors.toDot(g, "fichero/" + nombre + ".gv", // ruta al fichero resultado
					v -> v.toString(),//cómo pinta los vértices
					e -> "",//cómo pinta las aristas
					v -> GraphColors.color(asignaColor(v, listaVertices, tareaInicial)),
					e -> GraphColors.color(Color.black));//estilo arista
			
			System.out.println("Se ha generado el fichero del grafo del ejercicio 3 apartado B");
	
		}	
	
	public static void testEjemplo2(String file, String tareaInicial) {
		Graph<String, Arista> g = leerGrafo(file);
		
		Predicate<String> pv = v -> g.containsVertex(v);
		Predicate<Arista> pa = e -> g.containsEdge(e);
		Graph<String, Arista> vista = Ejercicio3.vistaEjercicio3(g, pv, pa);
	
		testEjercicio3B(vista, "ejercicio3ApartadoB", tareaInicial);
	}
	
	private static Color asignaColor(String v, 
			List<String> ls, String primera) {
		if (v.equals(primera)) {
			return Color.red;
		} else if (ls.contains(v)) {
			return Color.cyan;
		} else {
			return Color.black;
		}
	}
/*-------------------------------------Código del apartado C-----------------------------------*/
	
	public static void testEjercicio3C(Graph<String, Arista> g, String nombre) {
			
			Set<String> res = Ejercicio3.ejercicio3c(g);
			System.out.println(res);
			GraphColors.toDot(g, "fichero/" + nombre + ".gv", // ruta al fichero resultado
					v -> v.toString(),//cómo pinta los vértices
					e -> "",//cómo pinta las aristas
					v -> GraphColors.colorIf(Color.cyan,
							res.contains(v)),
					e -> GraphColors.color(Color.black));//estilo arista
			
			System.out.println("Se ha generado el fichero del grafo del ejercicio 3 apartado C");
	
		}	
	
	public static void testEjemplo3(String file) {
		Graph<String, Arista> g = leerGrafo(file);
		
		Predicate<String> pv = v -> g.containsVertex(v);
		Predicate<Arista> pa = e -> g.containsEdge(e);
		Graph<String, Arista> vista = Ejercicio3.vistaEjercicio3(g, pv, pa);
	
		testEjercicio3C(vista, "ejercicio3ApartadoC");
	}
	

	public static void main(String[] args) {
//			testEjemplo1("fichero/ejercicio3_3.txt");
//			testEjemplo2("fichero/ejercicio3_3.txt", "Tarea8");
//			testEjemplo3("fichero/ejercicio3_3.txt");
	}
}

package us.lsi.alg.secuencias;

public enum SeqAction{a,e,c,m}

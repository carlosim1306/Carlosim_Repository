package us.lsi.alg.sudoku;

public class Heuristic {
	
	

}

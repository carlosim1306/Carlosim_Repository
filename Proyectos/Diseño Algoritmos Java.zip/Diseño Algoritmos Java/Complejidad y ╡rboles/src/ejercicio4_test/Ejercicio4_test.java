package ejercicio4_test;

import java.util.List;

import ejercicio4.Ejercicio4;
import us.lsi.common.Files2;
import us.lsi.tiposrecursivos.BinaryTree;
import us.lsi.tiposrecursivos.Tree;

public class Ejercicio4_test {

	public static void main(String[] args) {
		String file = "fichero/PI2Ej4DatosEntradaBinary.txt";
		String file1 = "fichero/PI2Ej4DatosEntradaNary.txt";

		
		List<BinaryTree<Integer>> inputs = Files2
				.streamFromFile(file)
				.map(linea -> BinaryTree.parse(linea,s->Integer.parseInt(s)))
				.toList();
		
		List<Tree<Integer>> ninputs = Files2
				.streamFromFile(file1)
				.map(linea -> Tree.parse(linea,s->Integer.parseInt(s)))
				.toList();
			
		for (BinaryTree<Integer> tree : inputs) {
			System.out.println("Arbol de entrada: " + tree);
			System.out.println(Ejercicio4.ejercicio4Binary(tree));
			}
		
		System.out.println("---------------------------");
		System.out.println("---------------------------");
		
		for (Tree<Integer> tree : ninputs) {
			System.out.println("Arbol de entrada: " + tree);
			System.out.println(Ejercicio4.ejercicio4Nanary(tree));
			}
	}

}

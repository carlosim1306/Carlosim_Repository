package ejercicio3;

import us.lsi.tiposrecursivos.BinaryTree;
import us.lsi.tiposrecursivos.BinaryTree.BEmpty;
import us.lsi.tiposrecursivos.BinaryTree.BLeaf;
import us.lsi.tiposrecursivos.BinaryTree.BTree;
import us.lsi.tiposrecursivos.Tree;
import us.lsi.tiposrecursivos.Tree.TEmpty;
import us.lsi.tiposrecursivos.Tree.TLeaf;
import us.lsi.tiposrecursivos.Tree.TNary;

public class Ejercicio3 {

	public static record EQ(Boolean eq, Integer i){
	}
	
	public static EQ ejercicio3Binary(BinaryTree<Character> tree) {
		return switch (tree) {
			case BEmpty<Character> t -> new EQ(true, 0);
			case BLeaf<Character> t -> new EQ(true, 0);
			case BTree<Character> t -> {
				EQ izq = ejercicio3Binary(t.left());
				EQ der = ejercicio3Binary(t.right());

				if (Math.abs(izq.i-der.i)<=1) {
					yield new EQ (true, Math.max(izq.i, der.i)+1);
				} else {
					yield new EQ(false,-1);
				}
			}
		};
	}
	
	public static EQ ejercicio3Nary(Tree<Character> tree) {
		return switch (tree) {
			case TEmpty<Character> t -> new EQ(true, 0);
			case TLeaf<Character> t -> new EQ(true, 0);
			case TNary<Character> t -> {
				Integer maxAlt = 0;
				Integer minAlt = Integer.MAX_VALUE;
				
				for (Tree<Character> ch : t.children()) {
					EQ hijo = ejercicio3Nary(ch);
					Integer alturaHijo = hijo.i();
					
					maxAlt = Math.max(maxAlt, alturaHijo);
					minAlt = Math.min(minAlt, alturaHijo);
				}				
				yield new EQ (maxAlt- minAlt <= 1, maxAlt +1);
			}
		};
	}
	
}

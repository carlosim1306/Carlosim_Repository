package ejercicio1_test;

import java.util.List;
import java.util.function.Function;

import org.apache.commons.math3.fitting.WeightedObservedPoint;

import ejercicio1.Ejercicio1;
import us.lsi.common.Pair;
import us.lsi.curvefitting.DataFile;
import us.lsi.curvefitting.Fit;
import us.lsi.curvefitting.GenData;
import us.lsi.curvefitting.PowerLog;
import us.lsi.graphics.MatPlotLib;

public class Ejercicio1_test {
	private static Integer nMin = 100; // n mínimo para el cálculo de potencia
	private static Integer nMax = 2500; // n máximo para el cálculo de potencia
	private static Integer nIncr = 100; // incremento en los valores de n del cálculo de potencia
	private static Integer nIter = 75; // número de iteraciones para cada medición de tiempo
	private static Integer nIterWarmup = 10000; // número de iteraciones para warmup
	
	public static void genDataPr() {
		String file = "ficheros_generados/pr.txt";
		Function<Integer,Long> f1 = GenData.time(t -> Ejercicio1.ejercicio1RNF(t));
//		Integer tMin,Integer tMax,Integer tInc,Integer numIter,Integer numIterWarmup
		GenData.tiemposEjecucionAritmetica(f1,file,nMin,nMax,nIncr,nIter,nIterWarmup);
	}
	
	public static void genDataLin() {
		String file = "ficheros_generados/lin.txt";
		Function<Integer,Long> f1 = GenData.time(t -> Ejercicio1.ejercicio1Iterativo(t));
//		Integer tMin,Integer tMax,Integer tInc,Integer numIter,Integer numIterWarmup
		GenData.tiemposEjecucionAritmetica(f1,file,nMin,nMax,nIncr,nIter,nIterWarmup);
	}

	public static void genDataPrBig() {
		String file = "ficheros_generados/prbig.txt";
		Function<Integer,Long> f1 = GenData.time(t -> Ejercicio1.ejercicio1BigRNF(t));
//		Integer tMin,Integer tMax,Integer tInc,Integer numIter,Integer numIterWarmup
		GenData.tiemposEjecucionAritmetica(f1,file,nMin,nMax,nIncr,nIter,nIterWarmup);
	}
	
	public static void genDataLinBig() {
		String file = "ficheros_generados/linbig.txt";
		Function<Integer,Long> f1 = GenData.time(t -> Ejercicio1.ejercicio1IBigterativo(t));
//		Integer tMin,Integer tMax,Integer tInc,Integer numIter,Integer numIterWarmup
		GenData.tiemposEjecucionAritmetica(f1,file,nMin,nMax,nIncr,nIter,nIterWarmup);
	}

	
	public static void showPr() {
		String file = "ficheros_generados/pr.txt";
		List<WeightedObservedPoint> data = DataFile.points(file);
		Fit pl = PowerLog.of(List.of(Pair.of(1, 1.),Pair.of(2, 0.),Pair.of(3, 0.)));
		pl.fit(data);
		System.out.println(pl.getExpression());
		System.out.println(pl.getEvaluation().getRMS());
		MatPlotLib.show(file, pl.getFunction(), pl.getExpression());
	}
	
	public static void showLin() {
		String file = "ficheros_generados/lin.txt";
		List<WeightedObservedPoint> data = DataFile.points(file);
		Fit pl = PowerLog.of(List.of(Pair.of(1, 1.),Pair.of(2, 0.),Pair.of(3, 0.)));
		pl.fit(data);
		System.out.println(pl.getExpression());
		System.out.println(pl.getEvaluation().getRMS());
		MatPlotLib.show(file, pl.getFunction(), pl.getExpression());
	}
	
	
	public static void showPrBig() {
		String file = "ficheros_generados/prbig.txt";
		List<WeightedObservedPoint> data = DataFile.points(file);
		Fit pl = PowerLog.of(List.of(Pair.of(1, 2.),Pair.of(2, 0.),Pair.of(3, 0.)));
		pl.fit(data);
		System.out.println(pl.getExpression());
		System.out.println(pl.getEvaluation().getRMS());
		MatPlotLib.show(file, pl.getFunction(), pl.getExpression());
	}
	
	public static void showLinBig() {
		String file = "ficheros_generados/linbig.txt";
		List<WeightedObservedPoint> data = DataFile.points(file);
		Fit pl = PowerLog.of(List.of(Pair.of(1, 2.),Pair.of(2, 0.),Pair.of(3, 0.)));
		pl.fit(data);
		System.out.println(pl.getExpression());
		System.out.println(pl.getEvaluation().getRMS());
		MatPlotLib.show(file, pl.getFunction(), pl.getExpression());
	}
	
	public static void showCombined() {
		MatPlotLib.showCombined("Tiempos",
		List.of("ficheros_generados/pr.txt", "ficheros_generados/lin.txt",
		"ficheros_generados/prbig.txt", "ficheros_generados/linbig.txt"),
		List.of("Double-recursiva", "Double-iterativa", "BigInteger-recursiva", "BigInteger-iterativa"));

}
		

	public static void main(String[] args) {
		genDataPr();
		genDataLin();
		genDataPrBig();
		genDataLinBig();
		
		showPr();
		showLin();
		showPrBig();
		showLinBig();
		showCombined();
	}
}

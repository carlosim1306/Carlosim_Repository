package ejercicio1;

import java.math.BigInteger;

public class Ejercicio1 {
	public static Double ejercicio1RNF(Integer a) {
		Double res = 1.;
		if (a >= 6) {
			res *= Math.pow(a, 3)*ejercicio1RNF(a-1);
		} else {
			res = (double) 10;
		}
		return res;
	}
	
	public static Double ejercicio1Iterativo(Integer a) {
		Double res = 1.;
		while(a>=6){
			res = res * Math.pow(a, 3);
			a = a-1;
		}
		res = (double) 10;
		return res;
	}
	
	public static BigInteger ejercicio1BigRNF(Integer a) {
		BigInteger res = BigInteger.ONE;
		if (a >= 6) {
			res = res.multiply(BigInteger.valueOf(a).pow(3));
			res = res.multiply(ejercicio1BigRNF(a-1));
		} else {
			res =  BigInteger.TEN;
		}
		return res;
	}
	
	public static BigInteger ejercicio1IBigterativo(Integer a) {
		BigInteger res = BigInteger.ONE;
		while(a>=6){
			res = res.multiply(BigInteger.valueOf(a).pow(3));
			a = a-1;
		}
		res = BigInteger.TEN;
		return res;
	}
}

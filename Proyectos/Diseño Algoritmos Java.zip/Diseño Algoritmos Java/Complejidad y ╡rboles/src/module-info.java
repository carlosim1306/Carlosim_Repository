/**
 * 
 */
/**
 * 
 */
module PI2 {
	
	requires partecomun;
	requires datos_compartidos;
	requires ejemplos_parte_comun;
}
package ejercicio2_test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Function;

import org.apache.commons.math3.fitting.WeightedObservedPoint;

import us.lsi.common.Pair;
import us.lsi.curvefitting.DataFile;
import us.lsi.curvefitting.Fit;
import us.lsi.curvefitting.GenData;
import us.lsi.curvefitting.PowerLog;
import us.lsi.graphics.MatPlotLib;
import us.lsi.recursivos.problemasdelistas.ProblemasDeListas;

public class Ejercicio2_test {
		private static Integer nMin = 100; // n mínimo para el cálculo de potencia
		private static Integer nMax = 13000; // n máximo para el cálculo de potencia
		private static Integer nIncr = 3000; // incremento en los valores de n del cálculo de potencia
		private static Integer nIter = 20; // número de iteraciones para cada medición de tiempo
		private static Integer nIterWarmup = 6001; // número de iteraciones para warmup
		private static List<Integer> list = new ArrayList<Integer>();
		private static Random r = new Random(System.nanoTime());
	
		private static void generaListaEnteros(Integer t) {
		List<Integer> ls = new ArrayList<Integer>();
		for (int i = 0; i < t; i++) {
		ls.add(r.nextInt(t + 25000));
		}
		list = ls; 
		}
		
		private static void genDataMergeSortUmbral1() {
		String file = String.format("ficheros_generados/1.txt");
		Consumer<Integer> cons = t -> generaListaEnteros(t);
		Function<Integer, Long> f1 = GenData.time(cons, t ->   ProblemasDeListas.mergeSort(list,
		1));
		GenData.tiemposEjecucionAritmetica(f1, file, nMin, nMax, nIncr, nIter, nIterWarmup);
		}
		private static void genDataMergeSortUmbral4() {
		String file = String.format("ficheros_generados/4.txt");
		Consumer<Integer> cons = t -> generaListaEnteros(t);
		Function<Integer, Long> f1 = GenData.time(cons, t -> ProblemasDeListas.mergeSort(list,
		4));
		GenData.tiemposEjecucionAritmetica(f1, file, nMin, nMax, nIncr, nIter, nIterWarmup);
		}
		private static void genDataMergeSortUmbral16() {
		String file = String.format("ficheros_generados/16.txt");
		Consumer<Integer> cons = t -> generaListaEnteros(t);
		Function<Integer, Long> f1 = GenData.time(cons, t -> ProblemasDeListas.mergeSort(list,
		16));
		GenData.tiemposEjecucionAritmetica(f1, file, nMin, nMax, nIncr, nIter, nIterWarmup);
		}
		private static void genDataMergeSortUmbral64() {
		String file = String.format("ficheros_generados/64.txt");
		Consumer<Integer> cons = t -> generaListaEnteros(t);
		Function<Integer, Long> f1 = GenData.time(cons, t -> ProblemasDeListas.mergeSort(list,
		64));
		GenData.tiemposEjecucionAritmetica(f1, file, nMin, nMax, nIncr, nIter, nIterWarmup);
		}
		
		private static void genDataMergeSortUmbral256() {
		String file = String.format("ficheros_generados/256.txt");
		Consumer<Integer> cons = t -> generaListaEnteros(t);
		Function<Integer, Long> f1 = GenData.time(cons, t -> ProblemasDeListas.mergeSort(list,
				256));
				GenData.tiemposEjecucionAritmetica(f1, file, nMin, nMax, nIncr, nIter, nIterWarmup);
				}
		
		public static void show1() {
			String file = "ficheros_generados/1.txt";
			List<WeightedObservedPoint> data = DataFile.points(file);
			Fit pl = PowerLog.of(List.of(Pair.of(1, 1.),Pair.of(3, 0.)));
			pl.fit(data);
			System.out.println(pl.getExpression());
			System.out.println(pl.getEvaluation().getRMS());
			MatPlotLib.show(file, pl.getFunction(), pl.getExpression());
		}
		
		public static void show4() {
			String file = "ficheros_generados/1.txt";
			List<WeightedObservedPoint> data = DataFile.points(file);
			Fit pl = PowerLog.of(List.of(Pair.of(1, 1.),Pair.of(3, 0.)));
			pl.fit(data);
			System.out.println(pl.getExpression());
			System.out.println(pl.getEvaluation().getRMS());
			MatPlotLib.show(file, pl.getFunction(), pl.getExpression());
		}
		
		public static void show16() {
			String file = "ficheros_generados/16.txt";
			List<WeightedObservedPoint> data = DataFile.points(file);
			Fit pl = PowerLog.of(List.of(Pair.of(1, 1.),Pair.of(3, 0.)));
			pl.fit(data);
			System.out.println(pl.getExpression());
			System.out.println(pl.getEvaluation().getRMS());
			MatPlotLib.show(file, pl.getFunction(), pl.getExpression());
		}
		
		public static void show64() {
			String file = "ficheros_generados/64.txt";
			List<WeightedObservedPoint> data = DataFile.points(file);
			Fit pl = PowerLog.of(List.of(Pair.of(1, 1.),Pair.of(3, 0.)));
			pl.fit(data);
			System.out.println(pl.getExpression());
			System.out.println(pl.getEvaluation().getRMS());
			MatPlotLib.show(file, pl.getFunction(), pl.getExpression());
		}
		
		public static void show256() {
			String file = "ficheros_generados/256.txt";
			List<WeightedObservedPoint> data = DataFile.points(file);
			Fit pl = PowerLog.of(List.of(Pair.of(1, 1.),Pair.of(3, 0.)));
			pl.fit(data);
			System.out.println(pl.getExpression());
			System.out.println(pl.getEvaluation().getRMS());
			MatPlotLib.show(file, pl.getFunction(), pl.getExpression());
		}

		public static void showCombined() {
				MatPlotLib.showCombined("Tiempos",
				List.of("ficheros_generados/1.txt", "ficheros_generados/4.txt",
				"ficheros_generados/16.txt", "ficheros_generados/64.txt",
				"ficheros_generados/256.txt"),
				List.of("Umbral 1", "Umbral 4", "Umbral 16", "Umbral 64", "Umbral 256"));

	}

		public static void main(String[] args) {
			genDataMergeSortUmbral1();
			genDataMergeSortUmbral4();
			genDataMergeSortUmbral16();
			genDataMergeSortUmbral64();
			genDataMergeSortUmbral256();
			show1();
			show4();
			show16();
			show64();
			show256();
			showCombined();
			}
}

package ejercicio3_test;

import java.util.List;

import ejercicio3.Ejercicio3;
import us.lsi.common.Files2;
import us.lsi.tiposrecursivos.BinaryTree;
import us.lsi.tiposrecursivos.Tree;

public class Ejercicio3_test {

	public static void main(String[] args) {
		
		String file = "fichero/PI2Ej3DatosEntradaBinary.txt";
		String file1 = "fichero/PI2Ej3DatosEntradaNary.txt";

		List<BinaryTree<Character>> inputs = Files2
				.streamFromFile(file)
				.map(linea -> BinaryTree.parse(linea,s->s.charAt(0)))
				.toList();
		
		List<Tree<Character>> ninputs = Files2
				.streamFromFile(file1)
				.map(linea -> Tree.parse(linea,s->s.charAt(0)))
				.toList();
		
		for (BinaryTree<Character> tree : inputs) {
		System.out.println("Arbol de entrada: " + tree);
		System.out.println("Equilibrado?: " +
		Ejercicio3.ejercicio3Binary(tree).eq());
		}
		
		System.out.println("---------------------------");
		
		for (Tree<Character> tree : ninputs) {
			System.out.println("Arbol de entrada: " + tree);
			System.out.println("Equilibrado?: " +
			Ejercicio3.ejercicio3Nary(tree).eq());
			}
	}
}

package ejercicio4;

import java.util.ArrayList;
import java.util.List;

import ejercicio3.Ejercicio3.EQ;
import us.lsi.tiposrecursivos.BinaryTree;
import us.lsi.tiposrecursivos.BinaryTree.BEmpty;
import us.lsi.tiposrecursivos.BinaryTree.BLeaf;
import us.lsi.tiposrecursivos.BinaryTree.BTree;
import us.lsi.tiposrecursivos.Tree;
import us.lsi.tiposrecursivos.Tree.TEmpty;
import us.lsi.tiposrecursivos.Tree.TLeaf;
import us.lsi.tiposrecursivos.Tree.TNary;

public class Ejercicio4 {
	
	public static List<List<Integer>> ejercicio4Binary(BinaryTree<Integer> tree){
		return auxEjercicio4Binary(tree,new ArrayList<Integer>() , new ArrayList<List<Integer>>());
	}

	private static List<List<Integer>>  auxEjercicio4Binary(BinaryTree<Integer> tree, List<Integer> acum,  List<List<Integer>> caminos) {
		return switch (tree) {
			case BEmpty<Integer> t -> {
				acum.add(0);
				if ((acum.stream().mapToInt(x -> x.intValue()).sum()%(acum.size()-1) == 0)) {
					caminos.add(acum);
				}
				yield caminos;
			}
			case BLeaf<Integer> t -> {
				acum.add(t.label());
				if (acum.stream().mapToInt(x -> x.intValue()).sum()%(acum.size()-1) == 0) {
					caminos.add(new ArrayList<Integer>(acum));
				}
				yield caminos;
			}
			case BTree<Integer> t -> {
				acum.add(t.label());
				
				if(t.left() != null) { 
					auxEjercicio4Binary(t.left(),new ArrayList<Integer>(acum), caminos);
					}
				if(t.right() != null) { 
					auxEjercicio4Binary(t.right(),new ArrayList<Integer>(acum), caminos);
					}
				yield caminos;
			}
		};
	}
	
	public static List<List<Integer>> ejercicio4Nanary(Tree<Integer> tree){
		return auxEjercicio4Nanary(tree,new ArrayList<Integer>() , new ArrayList<List<Integer>>());
	}

	private static List<List<Integer>>  auxEjercicio4Nanary(Tree<Integer> tree, List<Integer> acum,  List<List<Integer>> caminos) {
		return switch (tree) {
			case TEmpty<Integer> t -> {
				acum.add(0);
				if ((acum.stream().mapToInt(x -> x.intValue()).sum()%(acum.size()-1) == 0)) {
					caminos.add(acum);
				}
				yield caminos;
			}
			case TLeaf<Integer> t -> {
				acum.add(t.label());
				if (acum.stream().mapToInt(x -> x.intValue()).sum()%(acum.size()-1) == 0) {
					caminos.add(new ArrayList<Integer>(acum));
				}
				yield caminos;
			}
			case TNary<Integer> t -> {
				acum.add(t.label());	
				
				for (Tree<Integer> ch : t.children()) {
					auxEjercicio4Nanary(ch, new ArrayList<Integer>(acum),caminos);
				}				
				
				yield caminos;
			}
		};
	}
}
